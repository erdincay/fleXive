// UK lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direction left to right',
directionality_rtl_desc : 'Direction right to left'
});

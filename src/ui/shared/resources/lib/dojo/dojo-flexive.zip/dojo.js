/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

/*
	This is a compiled version of Dojo, built for deployment and not for
	development. To get an editable version, please visit:

		http://dojotoolkit.org

	for documentation and information on getting the source.
*/

if(typeof dojo=="undefined"){
var dj_global=this;
var dj_currentContext=this;
function dj_undef(_1,_2){
return (typeof (_2||dj_currentContext)[_1]=="undefined");
}
if(dj_undef("djConfig",this)){
var djConfig={};
}
if(dj_undef("dojo",this)){
var dojo={};
}
dojo.global=function(){
return dj_currentContext;
};
dojo.locale=djConfig.locale;
dojo.version={major:0,minor:4,patch:1,flag:"",revision:Number("$Rev: 6824 $".match(/[0-9]+/)[0]),toString:function(){
with(dojo.version){
return major+"."+minor+"."+patch+flag+" ("+revision+")";
}
}};
dojo.evalProp=function(_3,_4,_5){
if((!_4)||(!_3)){
return undefined;
}
if(!dj_undef(_3,_4)){
return _4[_3];
}
return (_5?(_4[_3]={}):undefined);
};
dojo.parseObjPath=function(_6,_7,_8){
var _9=(_7||dojo.global());
var _a=_6.split(".");
var _b=_a.pop();
for(var i=0,l=_a.length;i<l&&_9;i++){
_9=dojo.evalProp(_a[i],_9,_8);
}
return {obj:_9,prop:_b};
};
dojo.evalObjPath=function(_e,_f){
if(typeof _e!="string"){
return dojo.global();
}
if(_e.indexOf(".")==-1){
return dojo.evalProp(_e,dojo.global(),_f);
}
var ref=dojo.parseObjPath(_e,dojo.global(),_f);
if(ref){
return dojo.evalProp(ref.prop,ref.obj,_f);
}
return null;
};
dojo.errorToString=function(_11){
if(!dj_undef("message",_11)){
return _11.message;
}else{
if(!dj_undef("description",_11)){
return _11.description;
}else{
return _11;
}
}
};
dojo.raise=function(_12,_13){
if(_13){
_12=_12+": "+dojo.errorToString(_13);
}else{
_12=dojo.errorToString(_12);
}
try{
if(djConfig.isDebug){
dojo.hostenv.println("FATAL exception raised: "+_12);
}
}
catch(e){
}
throw _13||Error(_12);
};
dojo.debug=function(){
};
dojo.debugShallow=function(obj){
};
dojo.profile={start:function(){
},end:function(){
},stop:function(){
},dump:function(){
}};
function dj_eval(_15){
return dj_global.eval?dj_global.eval(_15):eval(_15);
}
dojo.unimplemented=function(_16,_17){
var _18="'"+_16+"' not implemented";
if(_17!=null){
_18+=" "+_17;
}
dojo.raise(_18);
};
dojo.deprecated=function(_19,_1a,_1b){
var _1c="DEPRECATED: "+_19;
if(_1a){
_1c+=" "+_1a;
}
if(_1b){
_1c+=" -- will be removed in version: "+_1b;
}
dojo.debug(_1c);
};
dojo.render=(function(){
function vscaffold(_1d,_1e){
var tmp={capable:false,support:{builtin:false,plugin:false},prefixes:_1d};
for(var i=0;i<_1e.length;i++){
tmp[_1e[i]]=false;
}
return tmp;
}
return {name:"",ver:dojo.version,os:{win:false,linux:false,osx:false},html:vscaffold(["html"],["ie","opera","khtml","safari","moz"]),svg:vscaffold(["svg"],["corel","adobe","batik"]),vml:vscaffold(["vml"],["ie"]),swf:vscaffold(["Swf","Flash","Mm"],["mm"]),swt:vscaffold(["Swt"],["ibm"])};
})();
dojo.hostenv=(function(){
var _21={isDebug:false,allowQueryConfig:false,baseScriptUri:"",baseRelativePath:"",libraryScriptUri:"",iePreventClobber:false,ieClobberMinimal:true,preventBackButtonFix:true,delayMozLoadingFix:false,searchIds:[],parseWidgets:true};
if(typeof djConfig=="undefined"){
djConfig=_21;
}else{
for(var _22 in _21){
if(typeof djConfig[_22]=="undefined"){
djConfig[_22]=_21[_22];
}
}
}
return {name_:"(unset)",version_:"(unset)",getName:function(){
return this.name_;
},getVersion:function(){
return this.version_;
},getText:function(uri){
dojo.unimplemented("getText","uri="+uri);
}};
})();
dojo.hostenv.getBaseScriptUri=function(){
if(djConfig.baseScriptUri.length){
return djConfig.baseScriptUri;
}
var uri=new String(djConfig.libraryScriptUri||djConfig.baseRelativePath);
if(!uri){
dojo.raise("Nothing returned by getLibraryScriptUri(): "+uri);
}
var _25=uri.lastIndexOf("/");
djConfig.baseScriptUri=djConfig.baseRelativePath;
return djConfig.baseScriptUri;
};
(function(){
var _26={pkgFileName:"__package__",loading_modules_:{},loaded_modules_:{},addedToLoadingCount:[],removedFromLoadingCount:[],inFlightCount:0,modulePrefixes_:{dojo:{name:"dojo",value:"src"}},setModulePrefix:function(_27,_28){
this.modulePrefixes_[_27]={name:_27,value:_28};
},moduleHasPrefix:function(_29){
var mp=this.modulePrefixes_;
return Boolean(mp[_29]&&mp[_29].value);
},getModulePrefix:function(_2b){
if(this.moduleHasPrefix(_2b)){
return this.modulePrefixes_[_2b].value;
}
return _2b;
},getTextStack:[],loadUriStack:[],loadedUris:[],post_load_:false,modulesLoadedListeners:[],unloadListeners:[],loadNotifying:false};
for(var _2c in _26){
dojo.hostenv[_2c]=_26[_2c];
}
})();
dojo.hostenv.loadPath=function(_2d,_2e,cb){
var uri;
if(_2d.charAt(0)=="/"||_2d.match(/^\w+:/)){
uri=_2d;
}else{
uri=this.getBaseScriptUri()+_2d;
}
if(djConfig.cacheBust&&dojo.render.html.capable){
uri+="?"+String(djConfig.cacheBust).replace(/\W+/g,"");
}
try{
return !_2e?this.loadUri(uri,cb):this.loadUriAndCheck(uri,_2e,cb);
}
catch(e){
dojo.debug(e);
return false;
}
};
dojo.hostenv.loadUri=function(uri,cb){
if(this.loadedUris[uri]){
return true;
}
var _33=this.getText(uri,null,true);
if(!_33){
return false;
}
this.loadedUris[uri]=true;
if(cb){
_33="("+_33+")";
}
var _34=dj_eval(_33);
if(cb){
cb(_34);
}
return true;
};
dojo.hostenv.loadUriAndCheck=function(uri,_36,cb){
var ok=true;
try{
ok=this.loadUri(uri,cb);
}
catch(e){
dojo.debug("failed loading ",uri," with error: ",e);
}
return Boolean(ok&&this.findModule(_36,false));
};
dojo.loaded=function(){
};
dojo.unloaded=function(){
};
dojo.hostenv.loaded=function(){
this.loadNotifying=true;
this.post_load_=true;
var mll=this.modulesLoadedListeners;
for(var x=0;x<mll.length;x++){
mll[x]();
}
this.modulesLoadedListeners=[];
this.loadNotifying=false;
dojo.loaded();
};
dojo.hostenv.unloaded=function(){
var mll=this.unloadListeners;
while(mll.length){
(mll.pop())();
}
dojo.unloaded();
};
dojo.addOnLoad=function(obj,_3d){
var dh=dojo.hostenv;
if(arguments.length==1){
dh.modulesLoadedListeners.push(obj);
}else{
if(arguments.length>1){
dh.modulesLoadedListeners.push(function(){
obj[_3d]();
});
}
}
if(dh.post_load_&&dh.inFlightCount==0&&!dh.loadNotifying){
dh.callLoaded();
}
};
dojo.addOnUnload=function(obj,_40){
var dh=dojo.hostenv;
if(arguments.length==1){
dh.unloadListeners.push(obj);
}else{
if(arguments.length>1){
dh.unloadListeners.push(function(){
obj[_40]();
});
}
}
};
dojo.hostenv.modulesLoaded=function(){
if(this.post_load_){
return;
}
if(this.loadUriStack.length==0&&this.getTextStack.length==0){
if(this.inFlightCount>0){
dojo.debug("files still in flight!");
return;
}
dojo.hostenv.callLoaded();
}
};
dojo.hostenv.callLoaded=function(){
if(typeof setTimeout=="object"){
setTimeout("dojo.hostenv.loaded();",0);
}else{
dojo.hostenv.loaded();
}
};
dojo.hostenv.getModuleSymbols=function(_42){
var _43=_42.split(".");
for(var i=_43.length;i>0;i--){
var _45=_43.slice(0,i).join(".");
if((i==1)&&!this.moduleHasPrefix(_45)){
_43[0]="../"+_43[0];
}else{
var _46=this.getModulePrefix(_45);
if(_46!=_45){
_43.splice(0,i,_46);
break;
}
}
}
return _43;
};
dojo.hostenv._global_omit_module_check=false;
dojo.hostenv.loadModule=function(_47,_48,_49){
if(!_47){
return;
}
_49=this._global_omit_module_check||_49;
var _4a=this.findModule(_47,false);
if(_4a){
return _4a;
}
if(dj_undef(_47,this.loading_modules_)){
this.addedToLoadingCount.push(_47);
}
this.loading_modules_[_47]=1;
var _4b=_47.replace(/\./g,"/")+".js";
var _4c=_47.split(".");
var _4d=this.getModuleSymbols(_47);
var _4e=((_4d[0].charAt(0)!="/")&&!_4d[0].match(/^\w+:/));
var _4f=_4d[_4d.length-1];
var ok;
if(_4f=="*"){
_47=_4c.slice(0,-1).join(".");
while(_4d.length){
_4d.pop();
_4d.push(this.pkgFileName);
_4b=_4d.join("/")+".js";
if(_4e&&_4b.charAt(0)=="/"){
_4b=_4b.slice(1);
}
ok=this.loadPath(_4b,!_49?_47:null);
if(ok){
break;
}
_4d.pop();
}
}else{
_4b=_4d.join("/")+".js";
_47=_4c.join(".");
var _51=!_49?_47:null;
ok=this.loadPath(_4b,_51);
if(!ok&&!_48){
_4d.pop();
while(_4d.length){
_4b=_4d.join("/")+".js";
ok=this.loadPath(_4b,_51);
if(ok){
break;
}
_4d.pop();
_4b=_4d.join("/")+"/"+this.pkgFileName+".js";
if(_4e&&_4b.charAt(0)=="/"){
_4b=_4b.slice(1);
}
ok=this.loadPath(_4b,_51);
if(ok){
break;
}
}
}
if(!ok&&!_49){
dojo.raise("Could not load '"+_47+"'; last tried '"+_4b+"'");
}
}
if(!_49&&!this["isXDomain"]){
_4a=this.findModule(_47,false);
if(!_4a){
dojo.raise("symbol '"+_47+"' is not defined after loading '"+_4b+"'");
}
}
return _4a;
};
dojo.hostenv.startPackage=function(_52){
var _53=String(_52);
var _54=_53;
var _55=_52.split(/\./);
if(_55[_55.length-1]=="*"){
_55.pop();
_54=_55.join(".");
}
var _56=dojo.evalObjPath(_54,true);
this.loaded_modules_[_53]=_56;
this.loaded_modules_[_54]=_56;
return _56;
};
dojo.hostenv.findModule=function(_57,_58){
var lmn=String(_57);
if(this.loaded_modules_[lmn]){
return this.loaded_modules_[lmn];
}
if(_58){
dojo.raise("no loaded module named '"+_57+"'");
}
return null;
};
dojo.kwCompoundRequire=function(_5a){
var _5b=_5a["common"]||[];
var _5c=_5a[dojo.hostenv.name_]?_5b.concat(_5a[dojo.hostenv.name_]||[]):_5b.concat(_5a["default"]||[]);
for(var x=0;x<_5c.length;x++){
var _5e=_5c[x];
if(_5e.constructor==Array){
dojo.hostenv.loadModule.apply(dojo.hostenv,_5e);
}else{
dojo.hostenv.loadModule(_5e);
}
}
};
dojo.require=function(_5f){
dojo.hostenv.loadModule.apply(dojo.hostenv,arguments);
};
dojo.requireIf=function(_60,_61){
var _62=arguments[0];
if((_62===true)||(_62=="common")||(_62&&dojo.render[_62].capable)){
var _63=[];
for(var i=1;i<arguments.length;i++){
_63.push(arguments[i]);
}
dojo.require.apply(dojo,_63);
}
};
dojo.requireAfterIf=dojo.requireIf;
dojo.provide=function(_65){
return dojo.hostenv.startPackage.apply(dojo.hostenv,arguments);
};
dojo.registerModulePath=function(_66,_67){
return dojo.hostenv.setModulePrefix(_66,_67);
};
dojo.setModulePrefix=function(_68,_69){
dojo.deprecated("dojo.setModulePrefix(\""+_68+"\", \""+_69+"\")","replaced by dojo.registerModulePath","0.5");
return dojo.registerModulePath(_68,_69);
};
dojo.exists=function(obj,_6b){
var p=_6b.split(".");
for(var i=0;i<p.length;i++){
if(!obj[p[i]]){
return false;
}
obj=obj[p[i]];
}
return true;
};
dojo.hostenv.normalizeLocale=function(_6e){
var _6f=_6e?_6e.toLowerCase():dojo.locale;
if(_6f=="root"){
_6f="ROOT";
}
return _6f;
};
dojo.hostenv.searchLocalePath=function(_70,_71,_72){
_70=dojo.hostenv.normalizeLocale(_70);
var _73=_70.split("-");
var _74=[];
for(var i=_73.length;i>0;i--){
_74.push(_73.slice(0,i).join("-"));
}
_74.push(false);
if(_71){
_74.reverse();
}
for(var j=_74.length-1;j>=0;j--){
var loc=_74[j]||"ROOT";
var _78=_72(loc);
if(_78){
break;
}
}
};
dojo.hostenv.localesGenerated=["ROOT","es-es","es","it-it","pt-br","de","fr-fr","zh-cn","pt","en-us","zh","fr","zh-tw","it","en-gb","xx","de-de","ko-kr","ja-jp","ko","en","ja"];
dojo.hostenv.registerNlsPrefix=function(){
dojo.registerModulePath("nls","nls");
};
dojo.hostenv.preloadLocalizations=function(){
if(dojo.hostenv.localesGenerated){
dojo.hostenv.registerNlsPrefix();
function preload(_79){
_79=dojo.hostenv.normalizeLocale(_79);
dojo.hostenv.searchLocalePath(_79,true,function(loc){
for(var i=0;i<dojo.hostenv.localesGenerated.length;i++){
if(dojo.hostenv.localesGenerated[i]==loc){
dojo["require"]("nls.dojo_"+loc);
return true;
}
}
return false;
});
}
preload();
var _7c=djConfig.extraLocale||[];
for(var i=0;i<_7c.length;i++){
preload(_7c[i]);
}
}
dojo.hostenv.preloadLocalizations=function(){
};
};
dojo.requireLocalization=function(_7e,_7f,_80,_81){
dojo.hostenv.preloadLocalizations();
var _82=dojo.hostenv.normalizeLocale(_80);
var _83=[_7e,"nls",_7f].join(".");
var _84="";
if(_81){
var _85=_81.split(",");
for(var i=0;i<_85.length;i++){
if(_82.indexOf(_85[i])==0){
if(_85[i].length>_84.length){
_84=_85[i];
}
}
}
if(!_84){
_84="ROOT";
}
}
var _87=_81?_84:_82;
var _88=dojo.hostenv.findModule(_83);
var _89=null;
if(_88){
if(djConfig.localizationComplete&&_88._built){
return;
}
var _8a=_87.replace("-","_");
var _8b=_83+"."+_8a;
_89=dojo.hostenv.findModule(_8b);
}
if(!_89){
_88=dojo.hostenv.startPackage(_83);
var _8c=dojo.hostenv.getModuleSymbols(_7e);
var _8d=_8c.concat("nls").join("/");
var _8e;
dojo.hostenv.searchLocalePath(_87,_81,function(loc){
var _90=loc.replace("-","_");
var _91=_83+"."+_90;
var _92=false;
if(!dojo.hostenv.findModule(_91)){
dojo.hostenv.startPackage(_91);
var _93=[_8d];
if(loc!="ROOT"){
_93.push(loc);
}
_93.push(_7f);
var _94=_93.join("/")+".js";
_92=dojo.hostenv.loadPath(_94,null,function(_95){
var _96=function(){
};
_96.prototype=_8e;
_88[_90]=new _96();
for(var j in _95){
_88[_90][j]=_95[j];
}
});
}else{
_92=true;
}
if(_92&&_88[_90]){
_8e=_88[_90];
}else{
_88[_90]=_8e;
}
if(_81){
return true;
}
});
}
if(_81&&_82!=_84){
_88[_82.replace("-","_")]=_88[_84.replace("-","_")];
}
};
(function(){
var _98=djConfig.extraLocale;
if(_98){
if(!_98 instanceof Array){
_98=[_98];
}
var req=dojo.requireLocalization;
dojo.requireLocalization=function(m,b,_9c,_9d){
req(m,b,_9c,_9d);
if(_9c){
return;
}
for(var i=0;i<_98.length;i++){
req(m,b,_98[i],_9d);
}
};
}
})();
}
if(typeof window!="undefined"){
(function(){
if(djConfig.allowQueryConfig){
var _9f=document.location.toString();
var _a0=_9f.split("?",2);
if(_a0.length>1){
var _a1=_a0[1];
var _a2=_a1.split("&");
for(var x in _a2){
var sp=_a2[x].split("=");
if((sp[0].length>9)&&(sp[0].substr(0,9)=="djConfig.")){
var opt=sp[0].substr(9);
try{
djConfig[opt]=eval(sp[1]);
}
catch(e){
djConfig[opt]=sp[1];
}
}
}
}
}
if(((djConfig["baseScriptUri"]=="")||(djConfig["baseRelativePath"]==""))&&(document&&document.getElementsByTagName)){
var _a6=document.getElementsByTagName("script");
var _a7=/(__package__|dojo|bootstrap1)\.js([\?\.]|$)/i;
for(var i=0;i<_a6.length;i++){
var src=_a6[i].getAttribute("src");
if(!src){
continue;
}
var m=src.match(_a7);
if(m){
var _ab=src.substring(0,m.index);
if(src.indexOf("bootstrap1")>-1){
_ab+="../";
}
if(!this["djConfig"]){
djConfig={};
}
if(djConfig["baseScriptUri"]==""){
djConfig["baseScriptUri"]=_ab;
}
if(djConfig["baseRelativePath"]==""){
djConfig["baseRelativePath"]=_ab;
}
break;
}
}
}
var dr=dojo.render;
var drh=dojo.render.html;
var drs=dojo.render.svg;
var dua=(drh.UA=navigator.userAgent);
var dav=(drh.AV=navigator.appVersion);
var t=true;
var f=false;
drh.capable=t;
drh.support.builtin=t;
dr.ver=parseFloat(drh.AV);
dr.os.mac=dav.indexOf("Macintosh")>=0;
dr.os.win=dav.indexOf("Windows")>=0;
dr.os.linux=dav.indexOf("X11")>=0;
drh.opera=dua.indexOf("Opera")>=0;
drh.khtml=(dav.indexOf("Konqueror")>=0)||(dav.indexOf("Safari")>=0);
drh.safari=dav.indexOf("Safari")>=0;
var _b3=dua.indexOf("Gecko");
drh.mozilla=drh.moz=(_b3>=0)&&(!drh.khtml);
if(drh.mozilla){
drh.geckoVersion=dua.substring(_b3+6,_b3+14);
}
drh.ie=(document.all)&&(!drh.opera);
drh.ie50=drh.ie&&dav.indexOf("MSIE 5.0")>=0;
drh.ie55=drh.ie&&dav.indexOf("MSIE 5.5")>=0;
drh.ie60=drh.ie&&dav.indexOf("MSIE 6.0")>=0;
drh.ie70=drh.ie&&dav.indexOf("MSIE 7.0")>=0;
var cm=document["compatMode"];
drh.quirks=(cm=="BackCompat")||(cm=="QuirksMode")||drh.ie55||drh.ie50;
dojo.locale=dojo.locale||(drh.ie?navigator.userLanguage:navigator.language).toLowerCase();
dr.vml.capable=drh.ie;
drs.capable=f;
drs.support.plugin=f;
drs.support.builtin=f;
var _b5=window["document"];
var tdi=_b5["implementation"];
if((tdi)&&(tdi["hasFeature"])&&(tdi.hasFeature("org.w3c.dom.svg","1.0"))){
drs.capable=t;
drs.support.builtin=t;
drs.support.plugin=f;
}
if(drh.safari){
var tmp=dua.split("AppleWebKit/")[1];
var ver=parseFloat(tmp.split(" ")[0]);
if(ver>=420){
drs.capable=t;
drs.support.builtin=t;
drs.support.plugin=f;
}
}else{
}
})();
dojo.hostenv.startPackage("dojo.hostenv");
dojo.render.name=dojo.hostenv.name_="browser";
dojo.hostenv.searchIds=[];
dojo.hostenv._XMLHTTP_PROGIDS=["Msxml2.XMLHTTP","Microsoft.XMLHTTP","Msxml2.XMLHTTP.4.0"];
dojo.hostenv.getXmlhttpObject=function(){
var _b9=null;
var _ba=null;
try{
_b9=new XMLHttpRequest();
}
catch(e){
}
if(!_b9){
for(var i=0;i<3;++i){
var _bc=dojo.hostenv._XMLHTTP_PROGIDS[i];
try{
_b9=new ActiveXObject(_bc);
}
catch(e){
_ba=e;
}
if(_b9){
dojo.hostenv._XMLHTTP_PROGIDS=[_bc];
break;
}
}
}
if(!_b9){
return dojo.raise("XMLHTTP not available",_ba);
}
return _b9;
};
dojo.hostenv._blockAsync=false;
dojo.hostenv.getText=function(uri,_be,_bf){
if(!_be){
this._blockAsync=true;
}
var _c0=this.getXmlhttpObject();
function isDocumentOk(_c1){
var _c2=_c1["status"];
return Boolean((!_c2)||((200<=_c2)&&(300>_c2))||(_c2==304));
}
if(_be){
var _c3=this,_c4=null,gbl=dojo.global();
var xhr=dojo.evalObjPath("dojo.io.XMLHTTPTransport");
_c0.onreadystatechange=function(){
if(_c4){
gbl.clearTimeout(_c4);
_c4=null;
}
if(_c3._blockAsync||(xhr&&xhr._blockAsync)){
_c4=gbl.setTimeout(function(){
_c0.onreadystatechange.apply(this);
},10);
}else{
if(4==_c0.readyState){
if(isDocumentOk(_c0)){
_be(_c0.responseText);
}
}
}
};
}
_c0.open("GET",uri,_be?true:false);
try{
_c0.send(null);
if(_be){
return null;
}
if(!isDocumentOk(_c0)){
var err=Error("Unable to load "+uri+" status:"+_c0.status);
err.status=_c0.status;
err.responseText=_c0.responseText;
throw err;
}
}
catch(e){
this._blockAsync=false;
if((_bf)&&(!_be)){
return null;
}else{
throw e;
}
}
this._blockAsync=false;
return _c0.responseText;
};
dojo.hostenv.defaultDebugContainerId="dojoDebug";
dojo.hostenv._println_buffer=[];
dojo.hostenv._println_safe=false;
dojo.hostenv.println=function(_c8){
if(!dojo.hostenv._println_safe){
dojo.hostenv._println_buffer.push(_c8);
}else{
try{
var _c9=document.getElementById(djConfig.debugContainerId?djConfig.debugContainerId:dojo.hostenv.defaultDebugContainerId);
if(!_c9){
_c9=dojo.body();
}
var div=document.createElement("div");
div.appendChild(document.createTextNode(_c8));
_c9.appendChild(div);
}
catch(e){
try{
document.write("<div>"+_c8+"</div>");
}
catch(e2){
window.status=_c8;
}
}
}
};
dojo.addOnLoad(function(){
dojo.hostenv._println_safe=true;
while(dojo.hostenv._println_buffer.length>0){
dojo.hostenv.println(dojo.hostenv._println_buffer.shift());
}
});
function dj_addNodeEvtHdlr(_cb,_cc,fp){
var _ce=_cb["on"+_cc]||function(){
};
_cb["on"+_cc]=function(){
fp.apply(_cb,arguments);
_ce.apply(_cb,arguments);
};
return true;
}
function dj_load_init(e){
var _d0=(e&&e.type)?e.type.toLowerCase():"load";
if(arguments.callee.initialized||(_d0!="domcontentloaded"&&_d0!="load")){
return;
}
arguments.callee.initialized=true;
if(typeof (_timer)!="undefined"){
clearInterval(_timer);
delete _timer;
}
var _d1=function(){
if(dojo.render.html.ie){
dojo.hostenv.makeWidgets();
}
};
if(dojo.hostenv.inFlightCount==0){
_d1();
dojo.hostenv.modulesLoaded();
}else{
dojo.hostenv.modulesLoadedListeners.unshift(_d1);
}
}
if(document.addEventListener){
if(dojo.render.html.opera||(dojo.render.html.moz&&!djConfig.delayMozLoadingFix)){
document.addEventListener("DOMContentLoaded",dj_load_init,null);
}
window.addEventListener("load",dj_load_init,null);
}
if(dojo.render.html.ie&&dojo.render.os.win){
document.attachEvent("onreadystatechange",function(e){
if(document.readyState=="complete"){
dj_load_init();
}
});
}
if(/(WebKit|khtml)/i.test(navigator.userAgent)){
var _timer=setInterval(function(){
if(/loaded|complete/.test(document.readyState)){
dj_load_init();
}
},10);
}
if(dojo.render.html.ie){
dj_addNodeEvtHdlr(window,"beforeunload",function(){
dojo.hostenv._unloading=true;
window.setTimeout(function(){
dojo.hostenv._unloading=false;
},0);
});
}
dj_addNodeEvtHdlr(window,"unload",function(){
dojo.hostenv.unloaded();
if((!dojo.render.html.ie)||(dojo.render.html.ie&&dojo.hostenv._unloading)){
dojo.hostenv.unloaded();
}
});
dojo.hostenv.makeWidgets=function(){
var _d3=[];
if(djConfig.searchIds&&djConfig.searchIds.length>0){
_d3=_d3.concat(djConfig.searchIds);
}
if(dojo.hostenv.searchIds&&dojo.hostenv.searchIds.length>0){
_d3=_d3.concat(dojo.hostenv.searchIds);
}
if((djConfig.parseWidgets)||(_d3.length>0)){
if(dojo.evalObjPath("dojo.widget.Parse")){
var _d4=new dojo.xml.Parse();
if(_d3.length>0){
for(var x=0;x<_d3.length;x++){
var _d6=document.getElementById(_d3[x]);
if(!_d6){
continue;
}
var _d7=_d4.parseElement(_d6,null,true);
dojo.widget.getParser().createComponents(_d7);
}
}else{
if(djConfig.parseWidgets){
var _d7=_d4.parseElement(dojo.body(),null,true);
dojo.widget.getParser().createComponents(_d7);
}
}
}
}
};
dojo.addOnLoad(function(){
if(!dojo.render.html.ie){
dojo.hostenv.makeWidgets();
}
});
try{
if(dojo.render.html.ie){
document.namespaces.add("v","urn:schemas-microsoft-com:vml");
document.createStyleSheet().addRule("v\\:*","behavior:url(#default#VML)");
}
}
catch(e){
}
dojo.hostenv.writeIncludes=function(){
};
if(!dj_undef("document",this)){
dj_currentDocument=this.document;
}
dojo.doc=function(){
return dj_currentDocument;
};
dojo.body=function(){
return dojo.doc().body||dojo.doc().getElementsByTagName("body")[0];
};
dojo.byId=function(id,doc){
if((id)&&((typeof id=="string")||(id instanceof String))){
if(!doc){
doc=dj_currentDocument;
}
var ele=doc.getElementById(id);
if(ele&&(ele.id!=id)&&doc.all){
ele=null;
eles=doc.all[id];
if(eles){
if(eles.length){
for(var i=0;i<eles.length;i++){
if(eles[i].id==id){
ele=eles[i];
break;
}
}
}else{
ele=eles;
}
}
}
return ele;
}
return id;
};
dojo.setContext=function(_dc,_dd){
dj_currentContext=_dc;
dj_currentDocument=_dd;
};
dojo._fireCallback=function(_de,_df,_e0){
if((_df)&&((typeof _de=="string")||(_de instanceof String))){
_de=_df[_de];
}
return (_df?_de.apply(_df,_e0||[]):_de());
};
dojo.withGlobal=function(_e1,_e2,_e3,_e4){
var _e5;
var _e6=dj_currentContext;
var _e7=dj_currentDocument;
try{
dojo.setContext(_e1,_e1.document);
_e5=dojo._fireCallback(_e2,_e3,_e4);
}
finally{
dojo.setContext(_e6,_e7);
}
return _e5;
};
dojo.withDoc=function(_e8,_e9,_ea,_eb){
var _ec;
var _ed=dj_currentDocument;
try{
dj_currentDocument=_e8;
_ec=dojo._fireCallback(_e9,_ea,_eb);
}
finally{
dj_currentDocument=_ed;
}
return _ec;
};
}
(function(){
if(typeof dj_usingBootstrap!="undefined"){
return;
}
var _ee=false;
var _ef=false;
var _f0=false;
if((typeof this["load"]=="function")&&((typeof this["Packages"]=="function")||(typeof this["Packages"]=="object"))){
_ee=true;
}else{
if(typeof this["load"]=="function"){
_ef=true;
}else{
if(window.widget){
_f0=true;
}
}
}
var _f1=[];
if((this["djConfig"])&&((djConfig["isDebug"])||(djConfig["debugAtAllCosts"]))){
_f1.push("debug.js");
}
if((this["djConfig"])&&(djConfig["debugAtAllCosts"])&&(!_ee)&&(!_f0)){
_f1.push("browser_debug.js");
}
var _f2=djConfig["baseScriptUri"];
if((this["djConfig"])&&(djConfig["baseLoaderUri"])){
_f2=djConfig["baseLoaderUri"];
}
for(var x=0;x<_f1.length;x++){
var _f4=_f2+"src/"+_f1[x];
if(_ee||_ef){
load(_f4);
}else{
try{
document.write("<scr"+"ipt type='text/javascript' src='"+_f4+"'></scr"+"ipt>");
}
catch(e){
var _f5=document.createElement("script");
_f5.src=_f4;
document.getElementsByTagName("head")[0].appendChild(_f5);
}
}
}
})();
dojo.debug=function(){
if(!djConfig.isDebug){
return;
}
var _f6=arguments;
if(dj_undef("println",dojo.hostenv)){
dojo.raise("dojo.debug not available (yet?)");
}
var _f7=dj_global["jum"]&&!dj_global["jum"].isBrowser;
var s=[(_f7?"":"DEBUG: ")];
for(var i=0;i<_f6.length;++i){
if(!false&&_f6[i]&&_f6[i] instanceof Error){
var msg="["+_f6[i].name+": "+dojo.errorToString(_f6[i])+(_f6[i].fileName?", file: "+_f6[i].fileName:"")+(_f6[i].lineNumber?", line: "+_f6[i].lineNumber:"")+"]";
}else{
try{
var msg=String(_f6[i]);
}
catch(e){
if(dojo.render.html.ie){
var msg="[ActiveXObject]";
}else{
var msg="[unknown]";
}
}
}
s.push(msg);
}
dojo.hostenv.println(s.join(" "));
};
dojo.debugShallow=function(obj){
if(!djConfig.isDebug){
return;
}
dojo.debug("------------------------------------------------------------");
dojo.debug("Object: "+obj);
var _fc=[];
for(var _fd in obj){
try{
_fc.push(_fd+": "+obj[_fd]);
}
catch(E){
_fc.push(_fd+": ERROR - "+E.message);
}
}
_fc.sort();
for(var i=0;i<_fc.length;i++){
dojo.debug(_fc[i]);
}
dojo.debug("------------------------------------------------------------");
};
dojo.debugDeep=function(obj){
if(!djConfig.isDebug){
return;
}
if(!dojo.uri||!dojo.uri.dojoUri){
return dojo.debug("You'll need to load dojo.uri.* for deep debugging - sorry!");
}
if(!window.open){
return dojo.debug("Deep debugging is only supported in host environments with window.open");
}
var idx=dojo.debugDeep.debugVars.length;
dojo.debugDeep.debugVars.push(obj);
var url=new dojo.uri.Uri(location,dojo.uri.dojoUri("src/debug/deep.html?var="+idx)).toString();
var win=window.open(url,"_blank","width=600, height=400, resizable=yes, scrollbars=yes, status=yes");
try{
win.debugVar=obj;
}
catch(e){
}
};
dojo.debugDeep.debugVars=[];
dojo.provide("dojo.lang.common");
dojo.lang.inherits=function(_103,_104){
if(!dojo.lang.isFunction(_104)){
dojo.raise("dojo.inherits: superclass argument ["+_104+"] must be a function (subclass: ["+_103+"']");
}
_103.prototype=new _104();
_103.prototype.constructor=_103;
_103.superclass=_104.prototype;
_103["super"]=_104.prototype;
};
dojo.lang._mixin=function(obj,_106){
var tobj={};
for(var x in _106){
if((typeof tobj[x]=="undefined")||(tobj[x]!=_106[x])){
obj[x]=_106[x];
}
}
if(dojo.render.html.ie&&(typeof (_106["toString"])=="function")&&(_106["toString"]!=obj["toString"])&&(_106["toString"]!=tobj["toString"])){
obj.toString=_106.toString;
}
return obj;
};
dojo.lang.mixin=function(obj,_10a){
for(var i=1,l=arguments.length;i<l;i++){
dojo.lang._mixin(obj,arguments[i]);
}
return obj;
};
dojo.lang.extend=function(_10d,_10e){
for(var i=1,l=arguments.length;i<l;i++){
dojo.lang._mixin(_10d.prototype,arguments[i]);
}
return _10d;
};
dojo.inherits=dojo.lang.inherits;
dojo.mixin=dojo.lang.mixin;
dojo.extend=dojo.lang.extend;
dojo.lang.find=function(_111,_112,_113,_114){
if(!dojo.lang.isArrayLike(_111)&&dojo.lang.isArrayLike(_112)){
dojo.deprecated("dojo.lang.find(value, array)","use dojo.lang.find(array, value) instead","0.5");
var temp=_111;
_111=_112;
_112=temp;
}
var _116=dojo.lang.isString(_111);
if(_116){
_111=_111.split("");
}
if(_114){
var step=-1;
var i=_111.length-1;
var end=-1;
}else{
var step=1;
var i=0;
var end=_111.length;
}
if(_113){
while(i!=end){
if(_111[i]===_112){
return i;
}
i+=step;
}
}else{
while(i!=end){
if(_111[i]==_112){
return i;
}
i+=step;
}
}
return -1;
};
dojo.lang.indexOf=dojo.lang.find;
dojo.lang.findLast=function(_11a,_11b,_11c){
return dojo.lang.find(_11a,_11b,_11c,true);
};
dojo.lang.lastIndexOf=dojo.lang.findLast;
dojo.lang.inArray=function(_11d,_11e){
return dojo.lang.find(_11d,_11e)>-1;
};
dojo.lang.isObject=function(it){
if(typeof it=="undefined"){
return false;
}
return (typeof it=="object"||it===null||dojo.lang.isArray(it)||dojo.lang.isFunction(it));
};
dojo.lang.isArray=function(it){
return (it&&it instanceof Array||typeof it=="array");
};
dojo.lang.isArrayLike=function(it){
if((!it)||(dojo.lang.isUndefined(it))){
return false;
}
if(dojo.lang.isString(it)){
return false;
}
if(dojo.lang.isFunction(it)){
return false;
}
if(dojo.lang.isArray(it)){
return true;
}
if((it.tagName)&&(it.tagName.toLowerCase()=="form")){
return false;
}
if(dojo.lang.isNumber(it.length)&&isFinite(it.length)){
return true;
}
return false;
};
dojo.lang.isFunction=function(it){
return (it instanceof Function||typeof it=="function");
};
(function(){
if((dojo.render.html.capable)&&(dojo.render.html["safari"])){
dojo.lang.isFunction=function(it){
if((typeof (it)=="function")&&(it=="[object NodeList]")){
return false;
}
return (it instanceof Function||typeof it=="function");
};
}
})();
dojo.lang.isString=function(it){
return (typeof it=="string"||it instanceof String);
};
dojo.lang.isAlien=function(it){
if(!it){
return false;
}
return !dojo.lang.isFunction(it)&&/\{\s*\[native code\]\s*\}/.test(String(it));
};
dojo.lang.isBoolean=function(it){
return (it instanceof Boolean||typeof it=="boolean");
};
dojo.lang.isNumber=function(it){
return (it instanceof Number||typeof it=="number");
};
dojo.lang.isUndefined=function(it){
return ((typeof (it)=="undefined")&&(it==undefined));
};
dojo.provide("dojo.lang.extras");
dojo.lang.setTimeout=function(func,_12a){
var _12b=window,_12c=2;
if(!dojo.lang.isFunction(func)){
_12b=func;
func=_12a;
_12a=arguments[2];
_12c++;
}
if(dojo.lang.isString(func)){
func=_12b[func];
}
var args=[];
for(var i=_12c;i<arguments.length;i++){
args.push(arguments[i]);
}
return dojo.global().setTimeout(function(){
func.apply(_12b,args);
},_12a);
};
dojo.lang.clearTimeout=function(_12f){
dojo.global().clearTimeout(_12f);
};
dojo.lang.getNameInObj=function(ns,item){
if(!ns){
ns=dj_global;
}
for(var x in ns){
if(ns[x]===item){
return new String(x);
}
}
return null;
};
dojo.lang.shallowCopy=function(obj,deep){
var i,ret;
if(obj===null){
return null;
}
if(dojo.lang.isObject(obj)){
ret=new obj.constructor();
for(i in obj){
if(dojo.lang.isUndefined(ret[i])){
ret[i]=deep?dojo.lang.shallowCopy(obj[i],deep):obj[i];
}
}
}else{
if(dojo.lang.isArray(obj)){
ret=[];
for(i=0;i<obj.length;i++){
ret[i]=deep?dojo.lang.shallowCopy(obj[i],deep):obj[i];
}
}else{
ret=obj;
}
}
return ret;
};
dojo.lang.firstValued=function(){
for(var i=0;i<arguments.length;i++){
if(typeof arguments[i]!="undefined"){
return arguments[i];
}
}
return undefined;
};
dojo.lang.getObjPathValue=function(_138,_139,_13a){
with(dojo.parseObjPath(_138,_139,_13a)){
return dojo.evalProp(prop,obj,_13a);
}
};
dojo.lang.setObjPathValue=function(_13b,_13c,_13d,_13e){
dojo.deprecated("dojo.lang.setObjPathValue","use dojo.parseObjPath and the '=' operator","0.6");
if(arguments.length<4){
_13e=true;
}
with(dojo.parseObjPath(_13b,_13d,_13e)){
if(obj&&(_13e||(prop in obj))){
obj[prop]=_13c;
}
}
};
dojo.provide("dojo.lang.declare");
dojo.lang.declare=function(_13f,_140,init,_142){
if((dojo.lang.isFunction(_142))||((!_142)&&(!dojo.lang.isFunction(init)))){
var temp=_142;
_142=init;
init=temp;
}
var _144=[];
if(dojo.lang.isArray(_140)){
_144=_140;
_140=_144.shift();
}
if(!init){
init=dojo.evalObjPath(_13f,false);
if((init)&&(!dojo.lang.isFunction(init))){
init=null;
}
}
var ctor=dojo.lang.declare._makeConstructor();
var scp=(_140?_140.prototype:null);
if(scp){
scp.prototyping=true;
ctor.prototype=new _140();
scp.prototyping=false;
}
ctor.superclass=scp;
ctor.mixins=_144;
for(var i=0,l=_144.length;i<l;i++){
dojo.lang.extend(ctor,_144[i].prototype);
}
ctor.prototype.initializer=null;
ctor.prototype.declaredClass=_13f;
if(dojo.lang.isArray(_142)){
dojo.lang.extend.apply(dojo.lang,[ctor].concat(_142));
}else{
dojo.lang.extend(ctor,(_142)||{});
}
dojo.lang.extend(ctor,dojo.lang.declare._common);
ctor.prototype.constructor=ctor;
ctor.prototype.initializer=(ctor.prototype.initializer)||(init)||(function(){
});
var _149=dojo.parseObjPath(_13f,null,true);
_149.obj[_149.prop]=ctor;
return ctor;
};
dojo.lang.declare._makeConstructor=function(){
return function(){
var self=this._getPropContext();
var s=self.constructor.superclass;
if((s)&&(s.constructor)){
if(s.constructor==arguments.callee){
this._inherited("constructor",arguments);
}else{
this._contextMethod(s,"constructor",arguments);
}
}
var ms=(self.constructor.mixins)||([]);
for(var i=0,m;(m=ms[i]);i++){
(((m.prototype)&&(m.prototype.initializer))||(m)).apply(this,arguments);
}
if((!this.prototyping)&&(self.initializer)){
self.initializer.apply(this,arguments);
}
};
};
dojo.lang.declare._common={_getPropContext:function(){
return (this.___proto||this);
},_contextMethod:function(_14f,_150,args){
var _152,_153=this.___proto;
this.___proto=_14f;
try{
_152=_14f[_150].apply(this,(args||[]));
}
catch(e){
throw e;
}
finally{
this.___proto=_153;
}
return _152;
},_inherited:function(prop,args){
var p=this._getPropContext();
do{
if((!p.constructor)||(!p.constructor.superclass)){
return;
}
p=p.constructor.superclass;
}while(!(prop in p));
return (dojo.lang.isFunction(p[prop])?this._contextMethod(p,prop,args):p[prop]);
},inherited:function(prop,args){
dojo.deprecated("'inherited' method is dangerous, do not up-call! 'inherited' is slated for removal in 0.5; name your super class (or use superclass property) instead.","0.5");
this._inherited(prop,args);
}};
dojo.declare=dojo.lang.declare;
dojo.provide("dojo.logging.Logger");
dojo.provide("dojo.logging.LogFilter");
dojo.provide("dojo.logging.Record");
dojo.provide("dojo.log");
dojo.logging.Record=function(_159,_15a){
this.level=_159;
this.message="";
this.msgArgs=[];
this.time=new Date();
if(dojo.lang.isArray(_15a)){
if(_15a.length>0&&dojo.lang.isString(_15a[0])){
this.message=_15a.shift();
}
this.msgArgs=_15a;
}else{
this.message=_15a;
}
};
dojo.logging.LogFilter=function(_15b){
this.passChain=_15b||"";
this.filter=function(_15c){
return true;
};
};
dojo.logging.Logger=function(){
this.cutOffLevel=0;
this.propagate=true;
this.parent=null;
this.data=[];
this.filters=[];
this.handlers=[];
};
dojo.extend(dojo.logging.Logger,{_argsToArr:function(args){
var ret=[];
for(var x=0;x<args.length;x++){
ret.push(args[x]);
}
return ret;
},setLevel:function(lvl){
this.cutOffLevel=parseInt(lvl);
},isEnabledFor:function(lvl){
return parseInt(lvl)>=this.cutOffLevel;
},getEffectiveLevel:function(){
if((this.cutOffLevel==0)&&(this.parent)){
return this.parent.getEffectiveLevel();
}
return this.cutOffLevel;
},addFilter:function(flt){
this.filters.push(flt);
return this.filters.length-1;
},removeFilterByIndex:function(_163){
if(this.filters[_163]){
delete this.filters[_163];
return true;
}
return false;
},removeFilter:function(_164){
for(var x=0;x<this.filters.length;x++){
if(this.filters[x]===_164){
delete this.filters[x];
return true;
}
}
return false;
},removeAllFilters:function(){
this.filters=[];
},filter:function(rec){
for(var x=0;x<this.filters.length;x++){
if((this.filters[x]["filter"])&&(!this.filters[x].filter(rec))||(rec.level<this.cutOffLevel)){
return false;
}
}
return true;
},addHandler:function(hdlr){
this.handlers.push(hdlr);
return this.handlers.length-1;
},handle:function(rec){
if((!this.filter(rec))||(rec.level<this.cutOffLevel)){
return false;
}
for(var x=0;x<this.handlers.length;x++){
if(this.handlers[x]["handle"]){
this.handlers[x].handle(rec);
}
}
return true;
},log:function(lvl,msg){
if((this.propagate)&&(this.parent)&&(this.parent.rec.level>=this.cutOffLevel)){
this.parent.log(lvl,msg);
return false;
}
this.handle(new dojo.logging.Record(lvl,msg));
return true;
},debug:function(msg){
return this.logType("DEBUG",this._argsToArr(arguments));
},info:function(msg){
return this.logType("INFO",this._argsToArr(arguments));
},warning:function(msg){
return this.logType("WARNING",this._argsToArr(arguments));
},error:function(msg){
return this.logType("ERROR",this._argsToArr(arguments));
},critical:function(msg){
return this.logType("CRITICAL",this._argsToArr(arguments));
},exception:function(msg,e,_174){
if(e){
var _175=[e.name,(e.description||e.message)];
if(e.fileName){
_175.push(e.fileName);
_175.push("line "+e.lineNumber);
}
msg+=" "+_175.join(" : ");
}
this.logType("ERROR",msg);
if(!_174){
throw e;
}
},logType:function(type,args){
return this.log.apply(this,[dojo.logging.log.getLevel(type),args]);
},warn:function(){
this.warning.apply(this,arguments);
},err:function(){
this.error.apply(this,arguments);
},crit:function(){
this.critical.apply(this,arguments);
}});
dojo.logging.LogHandler=function(_178){
this.cutOffLevel=(_178)?_178:0;
this.formatter=null;
this.data=[];
this.filters=[];
};
dojo.lang.extend(dojo.logging.LogHandler,{setFormatter:function(_179){
dojo.unimplemented("setFormatter");
},flush:function(){
},close:function(){
},handleError:function(){
dojo.deprecated("dojo.logging.LogHandler.handleError","use handle()","0.6");
},handle:function(_17a){
if((this.filter(_17a))&&(_17a.level>=this.cutOffLevel)){
this.emit(_17a);
}
},emit:function(_17b){
dojo.unimplemented("emit");
}});
void (function(){
var _17c=["setLevel","addFilter","removeFilterByIndex","removeFilter","removeAllFilters","filter"];
var tgt=dojo.logging.LogHandler.prototype;
var src=dojo.logging.Logger.prototype;
for(var x=0;x<_17c.length;x++){
tgt[_17c[x]]=src[_17c[x]];
}
})();
dojo.logging.log=new dojo.logging.Logger();
dojo.logging.log.levels=[{"name":"DEBUG","level":1},{"name":"INFO","level":2},{"name":"WARNING","level":3},{"name":"ERROR","level":4},{"name":"CRITICAL","level":5}];
dojo.logging.log.loggers={};
dojo.logging.log.getLogger=function(name){
if(!this.loggers[name]){
this.loggers[name]=new dojo.logging.Logger();
this.loggers[name].parent=this;
}
return this.loggers[name];
};
dojo.logging.log.getLevelName=function(lvl){
for(var x=0;x<this.levels.length;x++){
if(this.levels[x].level==lvl){
return this.levels[x].name;
}
}
return null;
};
dojo.logging.log.getLevel=function(name){
for(var x=0;x<this.levels.length;x++){
if(this.levels[x].name.toUpperCase()==name.toUpperCase()){
return this.levels[x].level;
}
}
return null;
};
dojo.declare("dojo.logging.MemoryLogHandler",dojo.logging.LogHandler,{initializer:function(_185,_186,_187,_188){
dojo.logging.LogHandler.call(this,_185);
this.numRecords=(typeof djConfig["loggingNumRecords"]!="undefined")?djConfig["loggingNumRecords"]:((_186)?_186:-1);
this.postType=(typeof djConfig["loggingPostType"]!="undefined")?djConfig["loggingPostType"]:(_187||-1);
this.postInterval=(typeof djConfig["loggingPostInterval"]!="undefined")?djConfig["loggingPostInterval"]:(_187||-1);
},emit:function(_189){
if(!djConfig.isDebug){
return;
}
var _18a=String(dojo.log.getLevelName(_189.level)+": "+_189.time.toLocaleTimeString())+": "+_189.message;
if(!dj_undef("println",dojo.hostenv)){
dojo.hostenv.println(_18a,_189.msgArgs);
}
this.data.push(_189);
if(this.numRecords!=-1){
while(this.data.length>this.numRecords){
this.data.shift();
}
}
}});
dojo.logging.logQueueHandler=new dojo.logging.MemoryLogHandler(0,50,0,10000);
dojo.logging.log.addHandler(dojo.logging.logQueueHandler);
dojo.log=dojo.logging.log;
dojo.provide("dojo.logging.ConsoleLogger");
dojo.lang.extend(dojo.logging.MemoryLogHandler,{debug:function(){
dojo.hostenv.println.apply(this,arguments);
},info:function(){
dojo.hostenv.println.apply(this,arguments);
},warn:function(){
dojo.hostenv.println.apply(this,arguments);
},error:function(){
dojo.hostenv.println.apply(this,arguments);
},critical:function(){
dojo.hostenv.println.apply(this,arguments);
},emit:function(_18b){
if(!djConfig.isDebug){
return;
}
var _18c=null;
switch(_18b.level){
case 1:
_18c="debug";
break;
case 2:
_18c="info";
break;
case 3:
_18c="warn";
break;
case 4:
_18c="error";
break;
case 5:
_18c="critical";
break;
default:
_18c="debug";
}
var _18d=String(dojo.log.getLevelName(_18b.level)+": "+_18b.time.toLocaleTimeString())+": "+_18b.message;
if(_18b.msgArgs&&_18b.msgArgs.length>0){
this[_18c].call(this,_18d,_18b.msgArgs);
}else{
this[_18c].call(this,_18d);
}
this.data.push(_18b);
if(this.numRecords!=-1){
while(this.data.length>this.numRecords){
this.data.shift();
}
}
}});
if(!dj_undef("console")&&!dj_undef("info",console)){
dojo.lang.extend(dojo.logging.MemoryLogHandler,{debug:function(){
console.debug.apply(this,arguments);
},info:function(){
console.info.apply(this,arguments);
},warn:function(){
console.warn.apply(this,arguments);
},error:function(){
console.error.apply(this,arguments);
},critical:function(){
console.error.apply(this,arguments);
}});
dojo.lang.extend(dojo.logging.Logger,{exception:function(msg,e,_190){
var args=[msg];
if(e){
msg+=" : "+e.name+" "+(e.description||e.message);
args.push(e);
}
this.logType("ERROR",args);
if(!_190){
throw e;
}
}});
}
dojo.provide("dojo.debug.console");
if(window.console){
if(console.info!=null){
dojo.hostenv.println=function(){
if(!djConfig.isDebug){
return;
}
console.info.apply(console,arguments);
};
dojo.debug=dojo.hostenv.println;
dojo.debugDeep=dojo.debug;
dojo.debugShallow=function(obj,_193,sort){
if(!djConfig.isDebug){
return;
}
_193=(_193!=false);
sort=(sort!=false);
if(obj==null||obj.constructor==null){
return dojo.debug(obj);
}
var type=obj.declaredClass;
if(type==null){
type=obj.constructor.toString().match(/function\s*(.*)\(/);
if(type){
type=type[1];
}
}
if(type){
if(type=="String"||type=="Number"){
return dojo.debug(type+": ",obj);
}
if(_193&&!sort){
var _196=obj;
}else{
var _197=[];
if(_193){
for(var prop in obj){
_197.push(prop);
}
}else{
for(var prop in obj){
if(typeof obj[prop]!="function"){
_197.push(prop);
}else{
dojo.debug(prop);
}
}
}
if(sort){
_197.sort();
}
var _196={};
dojo.lang.forEach(_197,function(prop){
_196[prop]=obj[prop];
});
}
return dojo.debug(type+": %o\n%2.o",obj,_196);
}
return dojo.debug(obj.constructor+": ",obj);
};
}else{
if(console.log!=null){
dojo.hostenv.println=function(){
if(!djConfig.isDebug){
return;
}
var args=dojo.lang.toArray(arguments);
console.log("DEBUG: "+args.join(" "));
};
dojo.debug=dojo.hostenv.println;
}else{
dojo.debug("dojo.debug.console requires Firebug > 0.4");
}
}
}else{
if(dojo.render.html.opera){
if(opera&&opera.postError){
dojo.hostenv.println=opera.postError;
}else{
dojo.debug("dojo.debug.Opera requires Opera > 8.0");
}
}
}
dojo.provide("dojo.dom");
dojo.dom.ELEMENT_NODE=1;
dojo.dom.ATTRIBUTE_NODE=2;
dojo.dom.TEXT_NODE=3;
dojo.dom.CDATA_SECTION_NODE=4;
dojo.dom.ENTITY_REFERENCE_NODE=5;
dojo.dom.ENTITY_NODE=6;
dojo.dom.PROCESSING_INSTRUCTION_NODE=7;
dojo.dom.COMMENT_NODE=8;
dojo.dom.DOCUMENT_NODE=9;
dojo.dom.DOCUMENT_TYPE_NODE=10;
dojo.dom.DOCUMENT_FRAGMENT_NODE=11;
dojo.dom.NOTATION_NODE=12;
dojo.dom.dojoml="http://www.dojotoolkit.org/2004/dojoml";
dojo.dom.xmlns={svg:"http://www.w3.org/2000/svg",smil:"http://www.w3.org/2001/SMIL20/",mml:"http://www.w3.org/1998/Math/MathML",cml:"http://www.xml-cml.org",xlink:"http://www.w3.org/1999/xlink",xhtml:"http://www.w3.org/1999/xhtml",xul:"http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul",xbl:"http://www.mozilla.org/xbl",fo:"http://www.w3.org/1999/XSL/Format",xsl:"http://www.w3.org/1999/XSL/Transform",xslt:"http://www.w3.org/1999/XSL/Transform",xi:"http://www.w3.org/2001/XInclude",xforms:"http://www.w3.org/2002/01/xforms",saxon:"http://icl.com/saxon",xalan:"http://xml.apache.org/xslt",xsd:"http://www.w3.org/2001/XMLSchema",dt:"http://www.w3.org/2001/XMLSchema-datatypes",xsi:"http://www.w3.org/2001/XMLSchema-instance",rdf:"http://www.w3.org/1999/02/22-rdf-syntax-ns#",rdfs:"http://www.w3.org/2000/01/rdf-schema#",dc:"http://purl.org/dc/elements/1.1/",dcq:"http://purl.org/dc/qualifiers/1.0","soap-env":"http://schemas.xmlsoap.org/soap/envelope/",wsdl:"http://schemas.xmlsoap.org/wsdl/",AdobeExtensions:"http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"};
dojo.dom.isNode=function(wh){
if(typeof Element=="function"){
try{
return wh instanceof Element;
}
catch(e){
}
}else{
return wh&&!isNaN(wh.nodeType);
}
};
dojo.dom.getUniqueId=function(){
var _19c=dojo.doc();
do{
var id="dj_unique_"+(++arguments.callee._idIncrement);
}while(_19c.getElementById(id));
return id;
};
dojo.dom.getUniqueId._idIncrement=0;
dojo.dom.firstElement=dojo.dom.getFirstChildElement=function(_19e,_19f){
var node=_19e.firstChild;
while(node&&node.nodeType!=dojo.dom.ELEMENT_NODE){
node=node.nextSibling;
}
if(_19f&&node&&node.tagName&&node.tagName.toLowerCase()!=_19f.toLowerCase()){
node=dojo.dom.nextElement(node,_19f);
}
return node;
};
dojo.dom.lastElement=dojo.dom.getLastChildElement=function(_1a1,_1a2){
var node=_1a1.lastChild;
while(node&&node.nodeType!=dojo.dom.ELEMENT_NODE){
node=node.previousSibling;
}
if(_1a2&&node&&node.tagName&&node.tagName.toLowerCase()!=_1a2.toLowerCase()){
node=dojo.dom.prevElement(node,_1a2);
}
return node;
};
dojo.dom.nextElement=dojo.dom.getNextSiblingElement=function(node,_1a5){
if(!node){
return null;
}
do{
node=node.nextSibling;
}while(node&&node.nodeType!=dojo.dom.ELEMENT_NODE);
if(node&&_1a5&&_1a5.toLowerCase()!=node.tagName.toLowerCase()){
return dojo.dom.nextElement(node,_1a5);
}
return node;
};
dojo.dom.prevElement=dojo.dom.getPreviousSiblingElement=function(node,_1a7){
if(!node){
return null;
}
if(_1a7){
_1a7=_1a7.toLowerCase();
}
do{
node=node.previousSibling;
}while(node&&node.nodeType!=dojo.dom.ELEMENT_NODE);
if(node&&_1a7&&_1a7.toLowerCase()!=node.tagName.toLowerCase()){
return dojo.dom.prevElement(node,_1a7);
}
return node;
};
dojo.dom.moveChildren=function(_1a8,_1a9,trim){
var _1ab=0;
if(trim){
while(_1a8.hasChildNodes()&&_1a8.firstChild.nodeType==dojo.dom.TEXT_NODE){
_1a8.removeChild(_1a8.firstChild);
}
while(_1a8.hasChildNodes()&&_1a8.lastChild.nodeType==dojo.dom.TEXT_NODE){
_1a8.removeChild(_1a8.lastChild);
}
}
while(_1a8.hasChildNodes()){
_1a9.appendChild(_1a8.firstChild);
_1ab++;
}
return _1ab;
};
dojo.dom.copyChildren=function(_1ac,_1ad,trim){
var _1af=_1ac.cloneNode(true);
return this.moveChildren(_1af,_1ad,trim);
};
dojo.dom.replaceChildren=function(node,_1b1){
var _1b2=[];
if(dojo.render.html.ie){
for(var i=0;i<node.childNodes.length;i++){
_1b2.push(node.childNodes[i]);
}
}
dojo.dom.removeChildren(node);
node.appendChild(_1b1);
for(var i=0;i<_1b2.length;i++){
dojo.dom.destroyNode(_1b2[i]);
}
};
dojo.dom.removeChildren=function(node){
var _1b5=node.childNodes.length;
while(node.hasChildNodes()){
dojo.dom.removeNode(node.firstChild);
}
return _1b5;
};
dojo.dom.replaceNode=function(node,_1b7){
return node.parentNode.replaceChild(_1b7,node);
};
dojo.dom.destroyNode=function(node){
if(node.parentNode){
node=dojo.dom.removeNode(node);
}
if(node.nodeType!=3){
if(dojo.evalObjPath("dojo.event.browser.clean",false)){
dojo.event.browser.clean(node);
}
if(dojo.render.html.ie){
node.outerHTML="";
}
}
};
dojo.dom.removeNode=function(node){
if(node&&node.parentNode){
return node.parentNode.removeChild(node);
}
};
dojo.dom.getAncestors=function(node,_1bb,_1bc){
var _1bd=[];
var _1be=(_1bb&&(_1bb instanceof Function||typeof _1bb=="function"));
while(node){
if(!_1be||_1bb(node)){
_1bd.push(node);
}
if(_1bc&&_1bd.length>0){
return _1bd[0];
}
node=node.parentNode;
}
if(_1bc){
return null;
}
return _1bd;
};
dojo.dom.getAncestorsByTag=function(node,tag,_1c1){
tag=tag.toLowerCase();
return dojo.dom.getAncestors(node,function(el){
return ((el.tagName)&&(el.tagName.toLowerCase()==tag));
},_1c1);
};
dojo.dom.getFirstAncestorByTag=function(node,tag){
return dojo.dom.getAncestorsByTag(node,tag,true);
};
dojo.dom.isDescendantOf=function(node,_1c6,_1c7){
if(_1c7&&node){
node=node.parentNode;
}
while(node){
if(node==_1c6){
return true;
}
node=node.parentNode;
}
return false;
};
dojo.dom.innerXML=function(node){
if(node.innerXML){
return node.innerXML;
}else{
if(node.xml){
return node.xml;
}else{
if(typeof XMLSerializer!="undefined"){
return (new XMLSerializer()).serializeToString(node);
}
}
}
};
dojo.dom.createDocument=function(){
var doc=null;
var _1ca=dojo.doc();
if(!dj_undef("ActiveXObject")){
var _1cb=["MSXML2","Microsoft","MSXML","MSXML3"];
for(var i=0;i<_1cb.length;i++){
try{
doc=new ActiveXObject(_1cb[i]+".XMLDOM");
}
catch(e){
}
if(doc){
break;
}
}
}else{
if((_1ca.implementation)&&(_1ca.implementation.createDocument)){
doc=_1ca.implementation.createDocument("","",null);
}
}
return doc;
};
dojo.dom.createDocumentFromText=function(str,_1ce){
if(!_1ce){
_1ce="text/xml";
}
if(!dj_undef("DOMParser")){
var _1cf=new DOMParser();
return _1cf.parseFromString(str,_1ce);
}else{
if(!dj_undef("ActiveXObject")){
var _1d0=dojo.dom.createDocument();
if(_1d0){
_1d0.async=false;
_1d0.loadXML(str);
return _1d0;
}else{
dojo.debug("toXml didn't work?");
}
}else{
var _1d1=dojo.doc();
if(_1d1.createElement){
var tmp=_1d1.createElement("xml");
tmp.innerHTML=str;
if(_1d1.implementation&&_1d1.implementation.createDocument){
var _1d3=_1d1.implementation.createDocument("foo","",null);
for(var i=0;i<tmp.childNodes.length;i++){
_1d3.importNode(tmp.childNodes.item(i),true);
}
return _1d3;
}
return ((tmp.document)&&(tmp.document.firstChild?tmp.document.firstChild:tmp));
}
}
}
return null;
};
dojo.dom.prependChild=function(node,_1d6){
if(_1d6.firstChild){
_1d6.insertBefore(node,_1d6.firstChild);
}else{
_1d6.appendChild(node);
}
return true;
};
dojo.dom.insertBefore=function(node,ref,_1d9){
if((_1d9!=true)&&(node===ref||node.nextSibling===ref)){
return false;
}
var _1da=ref.parentNode;
_1da.insertBefore(node,ref);
return true;
};
dojo.dom.insertAfter=function(node,ref,_1dd){
var pn=ref.parentNode;
if(ref==pn.lastChild){
if((_1dd!=true)&&(node===ref)){
return false;
}
pn.appendChild(node);
}else{
return this.insertBefore(node,ref.nextSibling,_1dd);
}
return true;
};
dojo.dom.insertAtPosition=function(node,ref,_1e1){
if((!node)||(!ref)||(!_1e1)){
return false;
}
switch(_1e1.toLowerCase()){
case "before":
return dojo.dom.insertBefore(node,ref);
case "after":
return dojo.dom.insertAfter(node,ref);
case "first":
if(ref.firstChild){
return dojo.dom.insertBefore(node,ref.firstChild);
}else{
ref.appendChild(node);
return true;
}
break;
default:
ref.appendChild(node);
return true;
}
};
dojo.dom.insertAtIndex=function(node,_1e3,_1e4){
var _1e5=_1e3.childNodes;
if(!_1e5.length||_1e5.length==_1e4){
_1e3.appendChild(node);
return true;
}
if(_1e4==0){
return dojo.dom.prependChild(node,_1e3);
}
return dojo.dom.insertAfter(node,_1e5[_1e4-1]);
};
dojo.dom.textContent=function(node,text){
if(arguments.length>1){
var _1e8=dojo.doc();
dojo.dom.replaceChildren(node,_1e8.createTextNode(text));
return text;
}else{
if(node.textContent!=undefined){
return node.textContent;
}
var _1e9="";
if(node==null){
return _1e9;
}
for(var i=0;i<node.childNodes.length;i++){
switch(node.childNodes[i].nodeType){
case 1:
case 5:
_1e9+=dojo.dom.textContent(node.childNodes[i]);
break;
case 3:
case 2:
case 4:
_1e9+=node.childNodes[i].nodeValue;
break;
default:
break;
}
}
return _1e9;
}
};
dojo.dom.hasParent=function(node){
return Boolean(node&&node.parentNode&&dojo.dom.isNode(node.parentNode));
};
dojo.dom.isTag=function(node){
if(node&&node.tagName){
for(var i=1;i<arguments.length;i++){
if(node.tagName==String(arguments[i])){
return String(arguments[i]);
}
}
}
return "";
};
dojo.dom.setAttributeNS=function(elem,_1ef,_1f0,_1f1){
if(elem==null||((elem==undefined)&&(typeof elem=="undefined"))){
dojo.raise("No element given to dojo.dom.setAttributeNS");
}
if(!((elem.setAttributeNS==undefined)&&(typeof elem.setAttributeNS=="undefined"))){
elem.setAttributeNS(_1ef,_1f0,_1f1);
}else{
var _1f2=elem.ownerDocument;
var _1f3=_1f2.createNode(2,_1f0,_1ef);
_1f3.nodeValue=_1f1;
elem.setAttributeNode(_1f3);
}
};
dojo.provide("dojo.xml.Parse");
dojo.xml.Parse=function(){
var isIE=((dojo.render.html.capable)&&(dojo.render.html.ie));
function getTagName(node){
try{
return node.tagName.toLowerCase();
}
catch(e){
return "";
}
}
function getDojoTagName(node){
var _1f7=getTagName(node);
if(!_1f7){
return "";
}
if((dojo.widget)&&(dojo.widget.tags[_1f7])){
return _1f7;
}
var p=_1f7.indexOf(":");
if(p>=0){
return _1f7;
}
if(_1f7.substr(0,5)=="dojo:"){
return _1f7;
}
if(dojo.render.html.capable&&dojo.render.html.ie&&node.scopeName!="HTML"){
return node.scopeName.toLowerCase()+":"+_1f7;
}
if(_1f7.substr(0,4)=="dojo"){
return "dojo:"+_1f7.substring(4);
}
var djt=node.getAttribute("dojoType")||node.getAttribute("dojotype");
if(djt){
if(djt.indexOf(":")<0){
djt="dojo:"+djt;
}
return djt.toLowerCase();
}
djt=node.getAttributeNS&&node.getAttributeNS(dojo.dom.dojoml,"type");
if(djt){
return "dojo:"+djt.toLowerCase();
}
try{
djt=node.getAttribute("dojo:type");
}
catch(e){
}
if(djt){
return "dojo:"+djt.toLowerCase();
}
if((dj_global["djConfig"])&&(!djConfig["ignoreClassNames"])){
var _1fa=node.className||node.getAttribute("class");
if((_1fa)&&(_1fa.indexOf)&&(_1fa.indexOf("dojo-")!=-1)){
var _1fb=_1fa.split(" ");
for(var x=0,c=_1fb.length;x<c;x++){
if(_1fb[x].slice(0,5)=="dojo-"){
return "dojo:"+_1fb[x].substr(5).toLowerCase();
}
}
}
}
return "";
}
this.parseElement=function(node,_1ff,_200,_201){
var _202=getTagName(node);
if(isIE&&_202.indexOf("/")==0){
return null;
}
try{
var attr=node.getAttribute("parseWidgets");
if(attr&&attr.toLowerCase()=="false"){
return {};
}
}
catch(e){
}
var _204=true;
if(_200){
var _205=getDojoTagName(node);
_202=_205||_202;
_204=Boolean(_205);
}
var _206={};
_206[_202]=[];
var pos=_202.indexOf(":");
if(pos>0){
var ns=_202.substring(0,pos);
_206["ns"]=ns;
if((dojo.ns)&&(!dojo.ns.allow(ns))){
_204=false;
}
}
if(_204){
var _209=this.parseAttributes(node);
for(var attr in _209){
if((!_206[_202][attr])||(typeof _206[_202][attr]!="array")){
_206[_202][attr]=[];
}
_206[_202][attr].push(_209[attr]);
}
_206[_202].nodeRef=node;
_206.tagName=_202;
_206.index=_201||0;
}
var _20a=0;
for(var i=0;i<node.childNodes.length;i++){
var tcn=node.childNodes.item(i);
switch(tcn.nodeType){
case dojo.dom.ELEMENT_NODE:
var ctn=getDojoTagName(tcn)||getTagName(tcn);
if(!_206[ctn]){
_206[ctn]=[];
}
_206[ctn].push(this.parseElement(tcn,true,_200,_20a));
if((tcn.childNodes.length==1)&&(tcn.childNodes.item(0).nodeType==dojo.dom.TEXT_NODE)){
_206[ctn][_206[ctn].length-1].value=tcn.childNodes.item(0).nodeValue;
}
_20a++;
break;
case dojo.dom.TEXT_NODE:
if(node.childNodes.length==1){
_206[_202].push({value:node.childNodes.item(0).nodeValue});
}
break;
default:
break;
}
}
return _206;
};
this.parseAttributes=function(node){
var _20f={};
var atts=node.attributes;
var _211,i=0;
while((_211=atts[i++])){
if(isIE){
if(!_211){
continue;
}
if((typeof _211=="object")&&(typeof _211.nodeValue=="undefined")||(_211.nodeValue==null)||(_211.nodeValue=="")){
continue;
}
}
var nn=_211.nodeName.split(":");
nn=(nn.length==2)?nn[1]:_211.nodeName;
_20f[nn]={value:_211.nodeValue};
}
return _20f;
};
};
dojo.provide("dojo.lang.func");
dojo.lang.hitch=function(_214,_215){
var fcn=(dojo.lang.isString(_215)?_214[_215]:_215)||function(){
};
return function(){
return fcn.apply(_214,arguments);
};
};
dojo.lang.anonCtr=0;
dojo.lang.anon={};
dojo.lang.nameAnonFunc=function(_217,_218,_219){
var nso=(_218||dojo.lang.anon);
if((_219)||((dj_global["djConfig"])&&(djConfig["slowAnonFuncLookups"]==true))){
for(var x in nso){
try{
if(nso[x]===_217){
return x;
}
}
catch(e){
}
}
}
var ret="__"+dojo.lang.anonCtr++;
while(typeof nso[ret]!="undefined"){
ret="__"+dojo.lang.anonCtr++;
}
nso[ret]=_217;
return ret;
};
dojo.lang.forward=function(_21d){
return function(){
return this[_21d].apply(this,arguments);
};
};
dojo.lang.curry=function(_21e,func){
var _220=[];
_21e=_21e||dj_global;
if(dojo.lang.isString(func)){
func=_21e[func];
}
for(var x=2;x<arguments.length;x++){
_220.push(arguments[x]);
}
var _222=(func["__preJoinArity"]||func.length)-_220.length;
function gather(_223,_224,_225){
var _226=_225;
var _227=_224.slice(0);
for(var x=0;x<_223.length;x++){
_227.push(_223[x]);
}
_225=_225-_223.length;
if(_225<=0){
var res=func.apply(_21e,_227);
_225=_226;
return res;
}else{
return function(){
return gather(arguments,_227,_225);
};
}
}
return gather([],_220,_222);
};
dojo.lang.curryArguments=function(_22a,func,args,_22d){
var _22e=[];
var x=_22d||0;
for(x=_22d;x<args.length;x++){
_22e.push(args[x]);
}
return dojo.lang.curry.apply(dojo.lang,[_22a,func].concat(_22e));
};
dojo.lang.tryThese=function(){
for(var x=0;x<arguments.length;x++){
try{
if(typeof arguments[x]=="function"){
var ret=(arguments[x]());
if(ret){
return ret;
}
}
}
catch(e){
dojo.debug(e);
}
}
};
dojo.lang.delayThese=function(farr,cb,_234,_235){
if(!farr.length){
if(typeof _235=="function"){
_235();
}
return;
}
if((typeof _234=="undefined")&&(typeof cb=="number")){
_234=cb;
cb=function(){
};
}else{
if(!cb){
cb=function(){
};
if(!_234){
_234=0;
}
}
}
setTimeout(function(){
(farr.shift())();
cb();
dojo.lang.delayThese(farr,cb,_234,_235);
},_234);
};
dojo.provide("dojo.lang.array");
dojo.lang.mixin(dojo.lang,{has:function(obj,name){
try{
return typeof obj[name]!="undefined";
}
catch(e){
return false;
}
},isEmpty:function(obj){
if(dojo.lang.isObject(obj)){
var tmp={};
var _23a=0;
for(var x in obj){
if(obj[x]&&(!tmp[x])){
_23a++;
break;
}
}
return _23a==0;
}else{
if(dojo.lang.isArrayLike(obj)||dojo.lang.isString(obj)){
return obj.length==0;
}
}
},map:function(arr,obj,_23e){
var _23f=dojo.lang.isString(arr);
if(_23f){
arr=arr.split("");
}
if(dojo.lang.isFunction(obj)&&(!_23e)){
_23e=obj;
obj=dj_global;
}else{
if(dojo.lang.isFunction(obj)&&_23e){
var _240=obj;
obj=_23e;
_23e=_240;
}
}
if(Array.map){
var _241=Array.map(arr,_23e,obj);
}else{
var _241=[];
for(var i=0;i<arr.length;++i){
_241.push(_23e.call(obj,arr[i]));
}
}
if(_23f){
return _241.join("");
}else{
return _241;
}
},reduce:function(arr,_244,obj,_246){
var _247=_244;
if(arguments.length==1){
dojo.debug("dojo.lang.reduce called with too few arguments!");
return false;
}else{
if(arguments.length==2){
_246=_244;
_247=arr.shift();
}else{
if(arguments.lenght==3){
if(dojo.lang.isFunction(obj)){
_246=obj;
obj=null;
}
}else{
if(dojo.lang.isFunction(obj)){
var tmp=_246;
_246=obj;
obj=tmp;
}
}
}
}
var ob=obj?obj:dj_global;
dojo.lang.map(arr,function(val){
_247=_246.call(ob,_247,val);
});
return _247;
},forEach:function(_24b,_24c,_24d){
if(dojo.lang.isString(_24b)){
_24b=_24b.split("");
}
if(Array.forEach){
Array.forEach(_24b,_24c,_24d);
}else{
if(!_24d){
_24d=dj_global;
}
for(var i=0,l=_24b.length;i<l;i++){
_24c.call(_24d,_24b[i],i,_24b);
}
}
},_everyOrSome:function(_250,arr,_252,_253){
if(dojo.lang.isString(arr)){
arr=arr.split("");
}
if(Array.every){
return Array[_250?"every":"some"](arr,_252,_253);
}else{
if(!_253){
_253=dj_global;
}
for(var i=0,l=arr.length;i<l;i++){
var _256=_252.call(_253,arr[i],i,arr);
if(_250&&!_256){
return false;
}else{
if((!_250)&&(_256)){
return true;
}
}
}
return Boolean(_250);
}
},every:function(arr,_258,_259){
return this._everyOrSome(true,arr,_258,_259);
},some:function(arr,_25b,_25c){
return this._everyOrSome(false,arr,_25b,_25c);
},filter:function(arr,_25e,_25f){
var _260=dojo.lang.isString(arr);
if(_260){
arr=arr.split("");
}
var _261;
if(Array.filter){
_261=Array.filter(arr,_25e,_25f);
}else{
if(!_25f){
if(arguments.length>=3){
dojo.raise("thisObject doesn't exist!");
}
_25f=dj_global;
}
_261=[];
for(var i=0;i<arr.length;i++){
if(_25e.call(_25f,arr[i],i,arr)){
_261.push(arr[i]);
}
}
}
if(_260){
return _261.join("");
}else{
return _261;
}
},unnest:function(){
var out=[];
for(var i=0;i<arguments.length;i++){
if(dojo.lang.isArrayLike(arguments[i])){
var add=dojo.lang.unnest.apply(this,arguments[i]);
out=out.concat(add);
}else{
out.push(arguments[i]);
}
}
return out;
},toArray:function(_266,_267){
var _268=[];
for(var i=_267||0;i<_266.length;i++){
_268.push(_266[i]);
}
return _268;
}});
dojo.provide("dojo.ns");
dojo.ns={namespaces:{},failed:{},loading:{},loaded:{},register:function(name,_26b,_26c,_26d){
if(!_26d||!this.namespaces[name]){
this.namespaces[name]=new dojo.ns.Ns(name,_26b,_26c);
}
},allow:function(name){
if(this.failed[name]){
return false;
}
if((djConfig.excludeNamespace)&&(dojo.lang.inArray(djConfig.excludeNamespace,name))){
return false;
}
return ((name==this.dojo)||(!djConfig.includeNamespace)||(dojo.lang.inArray(djConfig.includeNamespace,name)));
},get:function(name){
return this.namespaces[name];
},require:function(name){
var ns=this.namespaces[name];
if((ns)&&(this.loaded[name])){
return ns;
}
if(!this.allow(name)){
return false;
}
if(this.loading[name]){
dojo.debug("dojo.namespace.require: re-entrant request to load namespace \""+name+"\" must fail.");
return false;
}
var req=dojo.require;
this.loading[name]=true;
try{
if(name=="dojo"){
req("dojo.namespaces.dojo");
}else{
if(!dojo.hostenv.moduleHasPrefix(name)){
dojo.registerModulePath(name,"../"+name);
}
req([name,"manifest"].join("."),false,true);
}
if(!this.namespaces[name]){
this.failed[name]=true;
}
}
finally{
this.loading[name]=false;
}
return this.namespaces[name];
}};
dojo.ns.Ns=function(name,_274,_275){
this.name=name;
this.module=_274;
this.resolver=_275;
this._loaded=[];
this._failed=[];
};
dojo.ns.Ns.prototype.resolve=function(name,_277,_278){
if(!this.resolver||djConfig["skipAutoRequire"]){
return false;
}
var _279=this.resolver(name,_277);
if((_279)&&(!this._loaded[_279])&&(!this._failed[_279])){
var req=dojo.require;
req(_279,false,true);
if(dojo.hostenv.findModule(_279,false)){
this._loaded[_279]=true;
}else{
if(!_278){
dojo.raise("dojo.ns.Ns.resolve: module '"+_279+"' not found after loading via namespace '"+this.name+"'");
}
this._failed[_279]=true;
}
}
return Boolean(this._loaded[_279]);
};
dojo.registerNamespace=function(name,_27c,_27d){
dojo.ns.register.apply(dojo.ns,arguments);
};
dojo.registerNamespaceResolver=function(name,_27f){
var n=dojo.ns.namespaces[name];
if(n){
n.resolver=_27f;
}
};
dojo.registerNamespaceManifest=function(_281,path,name,_284,_285){
dojo.registerModulePath(name,path);
dojo.registerNamespace(name,_284,_285);
};
dojo.registerNamespace("dojo","dojo.widget");
dojo.provide("dojo.event.common");
dojo.event=new function(){
this._canTimeout=dojo.lang.isFunction(dj_global["setTimeout"])||dojo.lang.isAlien(dj_global["setTimeout"]);
function interpolateArgs(args,_287){
var dl=dojo.lang;
var ao={srcObj:dj_global,srcFunc:null,adviceObj:dj_global,adviceFunc:null,aroundObj:null,aroundFunc:null,adviceType:(args.length>2)?args[0]:"after",precedence:"last",once:false,delay:null,rate:0,adviceMsg:false};
switch(args.length){
case 0:
return;
case 1:
return;
case 2:
ao.srcFunc=args[0];
ao.adviceFunc=args[1];
break;
case 3:
if((dl.isObject(args[0]))&&(dl.isString(args[1]))&&(dl.isString(args[2]))){
ao.adviceType="after";
ao.srcObj=args[0];
ao.srcFunc=args[1];
ao.adviceFunc=args[2];
}else{
if((dl.isString(args[1]))&&(dl.isString(args[2]))){
ao.srcFunc=args[1];
ao.adviceFunc=args[2];
}else{
if((dl.isObject(args[0]))&&(dl.isString(args[1]))&&(dl.isFunction(args[2]))){
ao.adviceType="after";
ao.srcObj=args[0];
ao.srcFunc=args[1];
var _28a=dl.nameAnonFunc(args[2],ao.adviceObj,_287);
ao.adviceFunc=_28a;
}else{
if((dl.isFunction(args[0]))&&(dl.isObject(args[1]))&&(dl.isString(args[2]))){
ao.adviceType="after";
ao.srcObj=dj_global;
var _28a=dl.nameAnonFunc(args[0],ao.srcObj,_287);
ao.srcFunc=_28a;
ao.adviceObj=args[1];
ao.adviceFunc=args[2];
}
}
}
}
break;
case 4:
if((dl.isObject(args[0]))&&(dl.isObject(args[2]))){
ao.adviceType="after";
ao.srcObj=args[0];
ao.srcFunc=args[1];
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
if((dl.isString(args[0]))&&(dl.isString(args[1]))&&(dl.isObject(args[2]))){
ao.adviceType=args[0];
ao.srcObj=dj_global;
ao.srcFunc=args[1];
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
if((dl.isString(args[0]))&&(dl.isFunction(args[1]))&&(dl.isObject(args[2]))){
ao.adviceType=args[0];
ao.srcObj=dj_global;
var _28a=dl.nameAnonFunc(args[1],dj_global,_287);
ao.srcFunc=_28a;
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
if((dl.isString(args[0]))&&(dl.isObject(args[1]))&&(dl.isString(args[2]))&&(dl.isFunction(args[3]))){
ao.srcObj=args[1];
ao.srcFunc=args[2];
var _28a=dl.nameAnonFunc(args[3],dj_global,_287);
ao.adviceObj=dj_global;
ao.adviceFunc=_28a;
}else{
if(dl.isObject(args[1])){
ao.srcObj=args[1];
ao.srcFunc=args[2];
ao.adviceObj=dj_global;
ao.adviceFunc=args[3];
}else{
if(dl.isObject(args[2])){
ao.srcObj=dj_global;
ao.srcFunc=args[1];
ao.adviceObj=args[2];
ao.adviceFunc=args[3];
}else{
ao.srcObj=ao.adviceObj=ao.aroundObj=dj_global;
ao.srcFunc=args[1];
ao.adviceFunc=args[2];
ao.aroundFunc=args[3];
}
}
}
}
}
}
break;
case 6:
ao.srcObj=args[1];
ao.srcFunc=args[2];
ao.adviceObj=args[3];
ao.adviceFunc=args[4];
ao.aroundFunc=args[5];
ao.aroundObj=dj_global;
break;
default:
ao.srcObj=args[1];
ao.srcFunc=args[2];
ao.adviceObj=args[3];
ao.adviceFunc=args[4];
ao.aroundObj=args[5];
ao.aroundFunc=args[6];
ao.once=args[7];
ao.delay=args[8];
ao.rate=args[9];
ao.adviceMsg=args[10];
break;
}
if(dl.isFunction(ao.aroundFunc)){
var _28a=dl.nameAnonFunc(ao.aroundFunc,ao.aroundObj,_287);
ao.aroundFunc=_28a;
}
if(dl.isFunction(ao.srcFunc)){
ao.srcFunc=dl.getNameInObj(ao.srcObj,ao.srcFunc);
}
if(dl.isFunction(ao.adviceFunc)){
ao.adviceFunc=dl.getNameInObj(ao.adviceObj,ao.adviceFunc);
}
if((ao.aroundObj)&&(dl.isFunction(ao.aroundFunc))){
ao.aroundFunc=dl.getNameInObj(ao.aroundObj,ao.aroundFunc);
}
if(!ao.srcObj){
dojo.raise("bad srcObj for srcFunc: "+ao.srcFunc);
}
if(!ao.adviceObj){
dojo.raise("bad adviceObj for adviceFunc: "+ao.adviceFunc);
}
if(!ao.adviceFunc){
dojo.debug("bad adviceFunc for srcFunc: "+ao.srcFunc);
dojo.debugShallow(ao);
}
return ao;
}
this.connect=function(){
if(arguments.length==1){
var ao=arguments[0];
}else{
var ao=interpolateArgs(arguments,true);
}
if(dojo.lang.isString(ao.srcFunc)&&(ao.srcFunc.toLowerCase()=="onkey")){
if(dojo.render.html.ie){
ao.srcFunc="onkeydown";
this.connect(ao);
}
ao.srcFunc="onkeypress";
}
if(dojo.lang.isArray(ao.srcObj)&&ao.srcObj!=""){
var _28c={};
for(var x in ao){
_28c[x]=ao[x];
}
var mjps=[];
dojo.lang.forEach(ao.srcObj,function(src){
if((dojo.render.html.capable)&&(dojo.lang.isString(src))){
src=dojo.byId(src);
}
_28c.srcObj=src;
mjps.push(dojo.event.connect.call(dojo.event,_28c));
});
return mjps;
}
var mjp=dojo.event.MethodJoinPoint.getForMethod(ao.srcObj,ao.srcFunc);
if(ao.adviceFunc){
var mjp2=dojo.event.MethodJoinPoint.getForMethod(ao.adviceObj,ao.adviceFunc);
}
try{
mjp.kwAddAdvice(ao);
}
catch(e){
return null;
}
return mjp;
};
this.log=function(a1,a2){
var _294;
if((arguments.length==1)&&(typeof a1=="object")){
_294=a1;
}else{
_294={srcObj:a1,srcFunc:a2};
}
_294.adviceFunc=function(){
var _295=[];
for(var x=0;x<arguments.length;x++){
_295.push(arguments[x]);
}
dojo.debug("("+_294.srcObj+")."+_294.srcFunc,":",_295.join(", "));
};
this.kwConnect(_294);
};
this.connectBefore=function(){
var args=["before"];
for(var i=0;i<arguments.length;i++){
args.push(arguments[i]);
}
return this.connect.apply(this,args);
};
this.connectAround=function(){
var args=["around"];
for(var i=0;i<arguments.length;i++){
args.push(arguments[i]);
}
return this.connect.apply(this,args);
};
this.connectOnce=function(){
var ao=interpolateArgs(arguments,true);
ao.once=true;
return this.connect(ao);
};
this._kwConnectImpl=function(_29c,_29d){
var fn=(_29d)?"disconnect":"connect";
if(typeof _29c["srcFunc"]=="function"){
_29c.srcObj=_29c["srcObj"]||dj_global;
var _29f=dojo.lang.nameAnonFunc(_29c.srcFunc,_29c.srcObj,true);
_29c.srcFunc=_29f;
}
if(typeof _29c["adviceFunc"]=="function"){
_29c.adviceObj=_29c["adviceObj"]||dj_global;
var _29f=dojo.lang.nameAnonFunc(_29c.adviceFunc,_29c.adviceObj,true);
_29c.adviceFunc=_29f;
}
_29c.srcObj=_29c["srcObj"]||dj_global;
_29c.adviceObj=_29c["adviceObj"]||_29c["targetObj"]||dj_global;
_29c.adviceFunc=_29c["adviceFunc"]||_29c["targetFunc"];
return dojo.event[fn](_29c);
};
this.kwConnect=function(_2a0){
return this._kwConnectImpl(_2a0,false);
};
this.disconnect=function(){
if(arguments.length==1){
var ao=arguments[0];
}else{
var ao=interpolateArgs(arguments,true);
}
if(!ao.adviceFunc){
return;
}
if(dojo.lang.isString(ao.srcFunc)&&(ao.srcFunc.toLowerCase()=="onkey")){
if(dojo.render.html.ie){
ao.srcFunc="onkeydown";
this.disconnect(ao);
}
ao.srcFunc="onkeypress";
}
if(!ao.srcObj[ao.srcFunc]){
return null;
}
var mjp=dojo.event.MethodJoinPoint.getForMethod(ao.srcObj,ao.srcFunc,true);
try{
mjp.removeAdvice(ao.adviceObj,ao.adviceFunc,ao.adviceType,ao.once);
}
catch(e){
return null;
}
return mjp;
};
this.kwDisconnect=function(_2a3){
return this._kwConnectImpl(_2a3,true);
};
};
dojo.event.MethodInvocation=function(_2a4,obj,args){
this.jp_=_2a4;
this.object=obj;
this.args=[];
for(var x=0;x<args.length;x++){
this.args[x]=args[x];
}
this.around_index=-1;
};
dojo.event.MethodInvocation.prototype.proceed=function(){
this.around_index++;
if(this.around_index>=this.jp_.around.length){
return this.jp_.object[this.jp_.methodname].apply(this.jp_.object,this.args);
}else{
var ti=this.jp_.around[this.around_index];
var mobj=ti[0]||dj_global;
var meth=ti[1];
return mobj[meth].call(mobj,this);
}
};
dojo.event.MethodJoinPoint=function(obj,_2ac){
this.object=obj||dj_global;
this.methodname=_2ac;
this.methodfunc=this.object[_2ac];
this.squelch=false;
};
dojo.event.MethodJoinPoint.getForMethod=function(obj,_2ae){
if(!obj){
obj=dj_global;
}
if(!obj[_2ae]){
obj[_2ae]=function(){
};
if(!obj[_2ae]){
dojo.raise("Cannot set do-nothing method on that object "+_2ae);
}
}else{
if((!dojo.lang.isFunction(obj[_2ae]))&&(!dojo.lang.isAlien(obj[_2ae]))){
return null;
}
}
var _2af=_2ae+"$joinpoint";
var _2b0=_2ae+"$joinpoint$method";
var _2b1=obj[_2af];
if(!_2b1){
var _2b2=false;
if(dojo.event["browser"]){
if((obj["attachEvent"])||(obj["nodeType"])||(obj["addEventListener"])){
_2b2=true;
dojo.event.browser.addClobberNodeAttrs(obj,[_2af,_2b0,_2ae]);
}
}
var _2b3=obj[_2ae].length;
obj[_2b0]=obj[_2ae];
_2b1=obj[_2af]=new dojo.event.MethodJoinPoint(obj,_2b0);
obj[_2ae]=function(){
var args=[];
if((_2b2)&&(!arguments.length)){
var evt=null;
try{
if(obj.ownerDocument){
evt=obj.ownerDocument.parentWindow.event;
}else{
if(obj.documentElement){
evt=obj.documentElement.ownerDocument.parentWindow.event;
}else{
if(obj.event){
evt=obj.event;
}else{
evt=window.event;
}
}
}
}
catch(e){
evt=window.event;
}
if(evt){
args.push(dojo.event.browser.fixEvent(evt,this));
}
}else{
for(var x=0;x<arguments.length;x++){
if((x==0)&&(_2b2)&&(dojo.event.browser.isEvent(arguments[x]))){
args.push(dojo.event.browser.fixEvent(arguments[x],this));
}else{
args.push(arguments[x]);
}
}
}
return _2b1.run.apply(_2b1,args);
};
obj[_2ae].__preJoinArity=_2b3;
}
return _2b1;
};
dojo.lang.extend(dojo.event.MethodJoinPoint,{unintercept:function(){
this.object[this.methodname]=this.methodfunc;
this.before=[];
this.after=[];
this.around=[];
},disconnect:dojo.lang.forward("unintercept"),run:function(){
var obj=this.object||dj_global;
var args=arguments;
var _2b9=[];
for(var x=0;x<args.length;x++){
_2b9[x]=args[x];
}
var _2bb=function(marr){
if(!marr){
dojo.debug("Null argument to unrollAdvice()");
return;
}
var _2bd=marr[0]||dj_global;
var _2be=marr[1];
if(!_2bd[_2be]){
dojo.raise("function \""+_2be+"\" does not exist on \""+_2bd+"\"");
}
var _2bf=marr[2]||dj_global;
var _2c0=marr[3];
var msg=marr[6];
var _2c2;
var to={args:[],jp_:this,object:obj,proceed:function(){
return _2bd[_2be].apply(_2bd,to.args);
}};
to.args=_2b9;
var _2c4=parseInt(marr[4]);
var _2c5=((!isNaN(_2c4))&&(marr[4]!==null)&&(typeof marr[4]!="undefined"));
if(marr[5]){
var rate=parseInt(marr[5]);
var cur=new Date();
var _2c8=false;
if((marr["last"])&&((cur-marr.last)<=rate)){
if(dojo.event._canTimeout){
if(marr["delayTimer"]){
clearTimeout(marr.delayTimer);
}
var tod=parseInt(rate*2);
var mcpy=dojo.lang.shallowCopy(marr);
marr.delayTimer=setTimeout(function(){
mcpy[5]=0;
_2bb(mcpy);
},tod);
}
return;
}else{
marr.last=cur;
}
}
if(_2c0){
_2bf[_2c0].call(_2bf,to);
}else{
if((_2c5)&&((dojo.render.html)||(dojo.render.svg))){
dj_global["setTimeout"](function(){
if(msg){
_2bd[_2be].call(_2bd,to);
}else{
_2bd[_2be].apply(_2bd,args);
}
},_2c4);
}else{
if(msg){
_2bd[_2be].call(_2bd,to);
}else{
_2bd[_2be].apply(_2bd,args);
}
}
}
};
var _2cb=function(){
if(this.squelch){
try{
return _2bb.apply(this,arguments);
}
catch(e){
dojo.debug(e);
}
}else{
return _2bb.apply(this,arguments);
}
};
if((this["before"])&&(this.before.length>0)){
dojo.lang.forEach(this.before.concat(new Array()),_2cb);
}
var _2cc;
try{
if((this["around"])&&(this.around.length>0)){
var mi=new dojo.event.MethodInvocation(this,obj,args);
_2cc=mi.proceed();
}else{
if(this.methodfunc){
_2cc=this.object[this.methodname].apply(this.object,args);
}
}
}
catch(e){
if(!this.squelch){
dojo.debug(e,"when calling",this.methodname,"on",this.object,"with arguments",args);
dojo.raise(e);
}
}
if((this["after"])&&(this.after.length>0)){
dojo.lang.forEach(this.after.concat(new Array()),_2cb);
}
return (this.methodfunc)?_2cc:null;
},getArr:function(kind){
var type="after";
if((typeof kind=="string")&&(kind.indexOf("before")!=-1)){
type="before";
}else{
if(kind=="around"){
type="around";
}
}
if(!this[type]){
this[type]=[];
}
return this[type];
},kwAddAdvice:function(args){
this.addAdvice(args["adviceObj"],args["adviceFunc"],args["aroundObj"],args["aroundFunc"],args["adviceType"],args["precedence"],args["once"],args["delay"],args["rate"],args["adviceMsg"]);
},addAdvice:function(_2d1,_2d2,_2d3,_2d4,_2d5,_2d6,once,_2d8,rate,_2da){
var arr=this.getArr(_2d5);
if(!arr){
dojo.raise("bad this: "+this);
}
var ao=[_2d1,_2d2,_2d3,_2d4,_2d8,rate,_2da];
if(once){
if(this.hasAdvice(_2d1,_2d2,_2d5,arr)>=0){
return;
}
}
if(_2d6=="first"){
arr.unshift(ao);
}else{
arr.push(ao);
}
},hasAdvice:function(_2dd,_2de,_2df,arr){
if(!arr){
arr=this.getArr(_2df);
}
var ind=-1;
for(var x=0;x<arr.length;x++){
var aao=(typeof _2de=="object")?(new String(_2de)).toString():_2de;
var a1o=(typeof arr[x][1]=="object")?(new String(arr[x][1])).toString():arr[x][1];
if((arr[x][0]==_2dd)&&(a1o==aao)){
ind=x;
}
}
return ind;
},removeAdvice:function(_2e5,_2e6,_2e7,once){
var arr=this.getArr(_2e7);
var ind=this.hasAdvice(_2e5,_2e6,_2e7,arr);
if(ind==-1){
return false;
}
while(ind!=-1){
arr.splice(ind,1);
if(once){
break;
}
ind=this.hasAdvice(_2e5,_2e6,_2e7,arr);
}
return true;
}});
dojo.provide("dojo.event.topic");
dojo.event.topic=new function(){
this.topics={};
this.getTopic=function(_2eb){
if(!this.topics[_2eb]){
this.topics[_2eb]=new this.TopicImpl(_2eb);
}
return this.topics[_2eb];
};
this.registerPublisher=function(_2ec,obj,_2ee){
var _2ec=this.getTopic(_2ec);
_2ec.registerPublisher(obj,_2ee);
};
this.subscribe=function(_2ef,obj,_2f1){
var _2ef=this.getTopic(_2ef);
_2ef.subscribe(obj,_2f1);
};
this.unsubscribe=function(_2f2,obj,_2f4){
var _2f2=this.getTopic(_2f2);
_2f2.unsubscribe(obj,_2f4);
};
this.destroy=function(_2f5){
this.getTopic(_2f5).destroy();
delete this.topics[_2f5];
};
this.publishApply=function(_2f6,args){
var _2f6=this.getTopic(_2f6);
_2f6.sendMessage.apply(_2f6,args);
};
this.publish=function(_2f8,_2f9){
var _2f8=this.getTopic(_2f8);
var args=[];
for(var x=1;x<arguments.length;x++){
args.push(arguments[x]);
}
_2f8.sendMessage.apply(_2f8,args);
};
};
dojo.event.topic.TopicImpl=function(_2fc){
this.topicName=_2fc;
this.subscribe=function(_2fd,_2fe){
var tf=_2fe||_2fd;
var to=(!_2fe)?dj_global:_2fd;
return dojo.event.kwConnect({srcObj:this,srcFunc:"sendMessage",adviceObj:to,adviceFunc:tf});
};
this.unsubscribe=function(_301,_302){
var tf=(!_302)?_301:_302;
var to=(!_302)?null:_301;
return dojo.event.kwDisconnect({srcObj:this,srcFunc:"sendMessage",adviceObj:to,adviceFunc:tf});
};
this._getJoinPoint=function(){
return dojo.event.MethodJoinPoint.getForMethod(this,"sendMessage");
};
this.setSquelch=function(_305){
this._getJoinPoint().squelch=_305;
};
this.destroy=function(){
this._getJoinPoint().disconnect();
};
this.registerPublisher=function(_306,_307){
dojo.event.connect(_306,_307,this,"sendMessage");
};
this.sendMessage=function(_308){
};
};
dojo.provide("dojo.event.browser");
dojo._ie_clobber=new function(){
this.clobberNodes=[];
function nukeProp(node,prop){
try{
node[prop]=null;
}
catch(e){
}
try{
delete node[prop];
}
catch(e){
}
try{
node.removeAttribute(prop);
}
catch(e){
}
}
this.clobber=function(_30b){
var na;
var tna;
if(_30b){
tna=_30b.all||_30b.getElementsByTagName("*");
na=[_30b];
for(var x=0;x<tna.length;x++){
if(tna[x]["__doClobber__"]){
na.push(tna[x]);
}
}
}else{
try{
window.onload=null;
}
catch(e){
}
na=(this.clobberNodes.length)?this.clobberNodes:document.all;
}
tna=null;
var _30f={};
for(var i=na.length-1;i>=0;i=i-1){
var el=na[i];
try{
if(el&&el["__clobberAttrs__"]){
for(var j=0;j<el.__clobberAttrs__.length;j++){
nukeProp(el,el.__clobberAttrs__[j]);
}
nukeProp(el,"__clobberAttrs__");
nukeProp(el,"__doClobber__");
}
}
catch(e){
}
}
na=null;
};
};
if(dojo.render.html.ie){
dojo.addOnUnload(function(){
dojo._ie_clobber.clobber();
try{
if((dojo["widget"])&&(dojo.widget["manager"])){
dojo.widget.manager.destroyAll();
}
}
catch(e){
}
if(dojo.widget){
for(var name in dojo.widget._templateCache){
if(dojo.widget._templateCache[name].node){
dojo.dom.destroyNode(dojo.widget._templateCache[name].node);
dojo.widget._templateCache[name].node=null;
delete dojo.widget._templateCache[name].node;
}
}
}
try{
window.onload=null;
}
catch(e){
}
try{
window.onunload=null;
}
catch(e){
}
dojo._ie_clobber.clobberNodes=[];
});
}
dojo.event.browser=new function(){
var _314=0;
this.normalizedEventName=function(_315){
switch(_315){
case "CheckboxStateChange":
case "DOMAttrModified":
case "DOMMenuItemActive":
case "DOMMenuItemInactive":
case "DOMMouseScroll":
case "DOMNodeInserted":
case "DOMNodeRemoved":
case "RadioStateChange":
return _315;
break;
default:
return _315.toLowerCase();
break;
}
};
this.clean=function(node){
if(dojo.render.html.ie){
dojo._ie_clobber.clobber(node);
}
};
this.addClobberNode=function(node){
if(!dojo.render.html.ie){
return;
}
if(!node["__doClobber__"]){
node.__doClobber__=true;
dojo._ie_clobber.clobberNodes.push(node);
node.__clobberAttrs__=[];
}
};
this.addClobberNodeAttrs=function(node,_319){
if(!dojo.render.html.ie){
return;
}
this.addClobberNode(node);
for(var x=0;x<_319.length;x++){
node.__clobberAttrs__.push(_319[x]);
}
};
this.removeListener=function(node,_31c,fp,_31e){
if(!_31e){
var _31e=false;
}
_31c=dojo.event.browser.normalizedEventName(_31c);
if((_31c=="onkey")||(_31c=="key")){
if(dojo.render.html.ie){
this.removeListener(node,"onkeydown",fp,_31e);
}
_31c="onkeypress";
}
if(_31c.substr(0,2)=="on"){
_31c=_31c.substr(2);
}
if(node.removeEventListener){
node.removeEventListener(_31c,fp,_31e);
}
};
this.addListener=function(node,_320,fp,_322,_323){
if(!node){
return;
}
if(!_322){
var _322=false;
}
_320=dojo.event.browser.normalizedEventName(_320);
if((_320=="onkey")||(_320=="key")){
if(dojo.render.html.ie){
this.addListener(node,"onkeydown",fp,_322,_323);
}
_320="onkeypress";
}
if(_320.substr(0,2)!="on"){
_320="on"+_320;
}
if(!_323){
var _324=function(evt){
if(!evt){
evt=window.event;
}
var ret=fp(dojo.event.browser.fixEvent(evt,this));
if(_322){
dojo.event.browser.stopEvent(evt);
}
return ret;
};
}else{
_324=fp;
}
if(node.addEventListener){
node.addEventListener(_320.substr(2),_324,_322);
return _324;
}else{
if(typeof node[_320]=="function"){
var _327=node[_320];
node[_320]=function(e){
_327(e);
return _324(e);
};
}else{
node[_320]=_324;
}
if(dojo.render.html.ie){
this.addClobberNodeAttrs(node,[_320]);
}
return _324;
}
};
this.isEvent=function(obj){
return (typeof obj!="undefined")&&(obj)&&(typeof Event!="undefined")&&(obj.eventPhase);
};
this.currentEvent=null;
this.callListener=function(_32a,_32b){
if(typeof _32a!="function"){
dojo.raise("listener not a function: "+_32a);
}
dojo.event.browser.currentEvent.currentTarget=_32b;
return _32a.call(_32b,dojo.event.browser.currentEvent);
};
this._stopPropagation=function(){
dojo.event.browser.currentEvent.cancelBubble=true;
};
this._preventDefault=function(){
dojo.event.browser.currentEvent.returnValue=false;
};
this.keys={KEY_BACKSPACE:8,KEY_TAB:9,KEY_CLEAR:12,KEY_ENTER:13,KEY_SHIFT:16,KEY_CTRL:17,KEY_ALT:18,KEY_PAUSE:19,KEY_CAPS_LOCK:20,KEY_ESCAPE:27,KEY_SPACE:32,KEY_PAGE_UP:33,KEY_PAGE_DOWN:34,KEY_END:35,KEY_HOME:36,KEY_LEFT_ARROW:37,KEY_UP_ARROW:38,KEY_RIGHT_ARROW:39,KEY_DOWN_ARROW:40,KEY_INSERT:45,KEY_DELETE:46,KEY_HELP:47,KEY_LEFT_WINDOW:91,KEY_RIGHT_WINDOW:92,KEY_SELECT:93,KEY_NUMPAD_0:96,KEY_NUMPAD_1:97,KEY_NUMPAD_2:98,KEY_NUMPAD_3:99,KEY_NUMPAD_4:100,KEY_NUMPAD_5:101,KEY_NUMPAD_6:102,KEY_NUMPAD_7:103,KEY_NUMPAD_8:104,KEY_NUMPAD_9:105,KEY_NUMPAD_MULTIPLY:106,KEY_NUMPAD_PLUS:107,KEY_NUMPAD_ENTER:108,KEY_NUMPAD_MINUS:109,KEY_NUMPAD_PERIOD:110,KEY_NUMPAD_DIVIDE:111,KEY_F1:112,KEY_F2:113,KEY_F3:114,KEY_F4:115,KEY_F5:116,KEY_F6:117,KEY_F7:118,KEY_F8:119,KEY_F9:120,KEY_F10:121,KEY_F11:122,KEY_F12:123,KEY_F13:124,KEY_F14:125,KEY_F15:126,KEY_NUM_LOCK:144,KEY_SCROLL_LOCK:145};
this.revKeys=[];
for(var key in this.keys){
this.revKeys[this.keys[key]]=key;
}
this.fixEvent=function(evt,_32e){
if(!evt){
if(window["event"]){
evt=window.event;
}
}
if((evt["type"])&&(evt["type"].indexOf("key")==0)){
evt.keys=this.revKeys;
for(var key in this.keys){
evt[key]=this.keys[key];
}
if(evt["type"]=="keydown"&&dojo.render.html.ie){
switch(evt.keyCode){
case evt.KEY_SHIFT:
case evt.KEY_CTRL:
case evt.KEY_ALT:
case evt.KEY_CAPS_LOCK:
case evt.KEY_LEFT_WINDOW:
case evt.KEY_RIGHT_WINDOW:
case evt.KEY_SELECT:
case evt.KEY_NUM_LOCK:
case evt.KEY_SCROLL_LOCK:
case evt.KEY_NUMPAD_0:
case evt.KEY_NUMPAD_1:
case evt.KEY_NUMPAD_2:
case evt.KEY_NUMPAD_3:
case evt.KEY_NUMPAD_4:
case evt.KEY_NUMPAD_5:
case evt.KEY_NUMPAD_6:
case evt.KEY_NUMPAD_7:
case evt.KEY_NUMPAD_8:
case evt.KEY_NUMPAD_9:
case evt.KEY_NUMPAD_PERIOD:
break;
case evt.KEY_NUMPAD_MULTIPLY:
case evt.KEY_NUMPAD_PLUS:
case evt.KEY_NUMPAD_ENTER:
case evt.KEY_NUMPAD_MINUS:
case evt.KEY_NUMPAD_DIVIDE:
break;
case evt.KEY_PAUSE:
case evt.KEY_TAB:
case evt.KEY_BACKSPACE:
case evt.KEY_ENTER:
case evt.KEY_ESCAPE:
case evt.KEY_PAGE_UP:
case evt.KEY_PAGE_DOWN:
case evt.KEY_END:
case evt.KEY_HOME:
case evt.KEY_LEFT_ARROW:
case evt.KEY_UP_ARROW:
case evt.KEY_RIGHT_ARROW:
case evt.KEY_DOWN_ARROW:
case evt.KEY_INSERT:
case evt.KEY_DELETE:
case evt.KEY_F1:
case evt.KEY_F2:
case evt.KEY_F3:
case evt.KEY_F4:
case evt.KEY_F5:
case evt.KEY_F6:
case evt.KEY_F7:
case evt.KEY_F8:
case evt.KEY_F9:
case evt.KEY_F10:
case evt.KEY_F11:
case evt.KEY_F12:
case evt.KEY_F12:
case evt.KEY_F13:
case evt.KEY_F14:
case evt.KEY_F15:
case evt.KEY_CLEAR:
case evt.KEY_HELP:
evt.key=evt.keyCode;
break;
default:
if(evt.ctrlKey||evt.altKey){
var _330=evt.keyCode;
if(_330>=65&&_330<=90&&evt.shiftKey==false){
_330+=32;
}
if(_330>=1&&_330<=26&&evt.ctrlKey){
_330+=96;
}
evt.key=String.fromCharCode(_330);
}
}
}else{
if(evt["type"]=="keypress"){
if(dojo.render.html.opera){
if(evt.which==0){
evt.key=evt.keyCode;
}else{
if(evt.which>0){
switch(evt.which){
case evt.KEY_SHIFT:
case evt.KEY_CTRL:
case evt.KEY_ALT:
case evt.KEY_CAPS_LOCK:
case evt.KEY_NUM_LOCK:
case evt.KEY_SCROLL_LOCK:
break;
case evt.KEY_PAUSE:
case evt.KEY_TAB:
case evt.KEY_BACKSPACE:
case evt.KEY_ENTER:
case evt.KEY_ESCAPE:
evt.key=evt.which;
break;
default:
var _330=evt.which;
if((evt.ctrlKey||evt.altKey||evt.metaKey)&&(evt.which>=65&&evt.which<=90&&evt.shiftKey==false)){
_330+=32;
}
evt.key=String.fromCharCode(_330);
}
}
}
}else{
if(dojo.render.html.ie){
if(!evt.ctrlKey&&!evt.altKey&&evt.keyCode>=evt.KEY_SPACE){
evt.key=String.fromCharCode(evt.keyCode);
}
}else{
if(dojo.render.html.safari){
switch(evt.keyCode){
case 25:
evt.key=evt.KEY_TAB;
evt.shift=true;
break;
case 63232:
evt.key=evt.KEY_UP_ARROW;
break;
case 63233:
evt.key=evt.KEY_DOWN_ARROW;
break;
case 63234:
evt.key=evt.KEY_LEFT_ARROW;
break;
case 63235:
evt.key=evt.KEY_RIGHT_ARROW;
break;
case 63236:
evt.key=evt.KEY_F1;
break;
case 63237:
evt.key=evt.KEY_F2;
break;
case 63238:
evt.key=evt.KEY_F3;
break;
case 63239:
evt.key=evt.KEY_F4;
break;
case 63240:
evt.key=evt.KEY_F5;
break;
case 63241:
evt.key=evt.KEY_F6;
break;
case 63242:
evt.key=evt.KEY_F7;
break;
case 63243:
evt.key=evt.KEY_F8;
break;
case 63244:
evt.key=evt.KEY_F9;
break;
case 63245:
evt.key=evt.KEY_F10;
break;
case 63246:
evt.key=evt.KEY_F11;
break;
case 63247:
evt.key=evt.KEY_F12;
break;
case 63250:
evt.key=evt.KEY_PAUSE;
break;
case 63272:
evt.key=evt.KEY_DELETE;
break;
case 63273:
evt.key=evt.KEY_HOME;
break;
case 63275:
evt.key=evt.KEY_END;
break;
case 63276:
evt.key=evt.KEY_PAGE_UP;
break;
case 63277:
evt.key=evt.KEY_PAGE_DOWN;
break;
case 63302:
evt.key=evt.KEY_INSERT;
break;
case 63248:
case 63249:
case 63289:
break;
default:
evt.key=evt.charCode>=evt.KEY_SPACE?String.fromCharCode(evt.charCode):evt.keyCode;
}
}else{
evt.key=evt.charCode>0?String.fromCharCode(evt.charCode):evt.keyCode;
}
}
}
}
}
}
if(dojo.render.html.ie){
if(!evt.target){
evt.target=evt.srcElement;
}
if(!evt.currentTarget){
evt.currentTarget=(_32e?_32e:evt.srcElement);
}
if(!evt.layerX){
evt.layerX=evt.offsetX;
}
if(!evt.layerY){
evt.layerY=evt.offsetY;
}
var doc=(evt.srcElement&&evt.srcElement.ownerDocument)?evt.srcElement.ownerDocument:document;
var _332=((dojo.render.html.ie55)||(doc["compatMode"]=="BackCompat"))?doc.body:doc.documentElement;
if(!evt.pageX){
evt.pageX=evt.clientX+(_332.scrollLeft||0);
}
if(!evt.pageY){
evt.pageY=evt.clientY+(_332.scrollTop||0);
}
if(evt.type=="mouseover"){
evt.relatedTarget=evt.fromElement;
}
if(evt.type=="mouseout"){
evt.relatedTarget=evt.toElement;
}
this.currentEvent=evt;
evt.callListener=this.callListener;
evt.stopPropagation=this._stopPropagation;
evt.preventDefault=this._preventDefault;
}
return evt;
};
this.stopEvent=function(evt){
if(window.event){
evt.cancelBubble=true;
evt.returnValue=false;
}else{
evt.preventDefault();
evt.stopPropagation();
}
};
};
dojo.provide("dojo.event.*");
dojo.provide("dojo.widget.Manager");
dojo.widget.manager=new function(){
this.widgets=[];
this.widgetIds=[];
this.topWidgets={};
var _334={};
var _335=[];
this.getUniqueId=function(_336){
var _337;
do{
_337=_336+"_"+(_334[_336]!=undefined?++_334[_336]:_334[_336]=0);
}while(this.getWidgetById(_337));
return _337;
};
this.add=function(_338){
this.widgets.push(_338);
if(!_338.extraArgs["id"]){
_338.extraArgs["id"]=_338.extraArgs["ID"];
}
if(_338.widgetId==""){
if(_338["id"]){
_338.widgetId=_338["id"];
}else{
if(_338.extraArgs["id"]){
_338.widgetId=_338.extraArgs["id"];
}else{
_338.widgetId=this.getUniqueId(_338.ns+"_"+_338.widgetType);
}
}
}
if(this.widgetIds[_338.widgetId]){
dojo.debug("widget ID collision on ID: "+_338.widgetId);
}
this.widgetIds[_338.widgetId]=_338;
};
this.destroyAll=function(){
for(var x=this.widgets.length-1;x>=0;x--){
try{
this.widgets[x].destroy(true);
delete this.widgets[x];
}
catch(e){
}
}
};
this.remove=function(_33a){
if(dojo.lang.isNumber(_33a)){
var tw=this.widgets[_33a].widgetId;
delete this.widgetIds[tw];
this.widgets.splice(_33a,1);
}else{
this.removeById(_33a);
}
};
this.removeById=function(id){
if(!dojo.lang.isString(id)){
id=id["widgetId"];
if(!id){
dojo.debug("invalid widget or id passed to removeById");
return;
}
}
for(var i=0;i<this.widgets.length;i++){
if(this.widgets[i].widgetId==id){
this.remove(i);
break;
}
}
};
this.getWidgetById=function(id){
if(dojo.lang.isString(id)){
return this.widgetIds[id];
}
return id;
};
this.getWidgetsByType=function(type){
var lt=type.toLowerCase();
var _341=(type.indexOf(":")<0?function(x){
return x.widgetType.toLowerCase();
}:function(x){
return x.getNamespacedType();
});
var ret=[];
dojo.lang.forEach(this.widgets,function(x){
if(_341(x)==lt){
ret.push(x);
}
});
return ret;
};
this.getWidgetsByFilter=function(_346,_347){
var ret=[];
dojo.lang.every(this.widgets,function(x){
if(_346(x)){
ret.push(x);
if(_347){
return false;
}
}
return true;
});
return (_347?ret[0]:ret);
};
this.getAllWidgets=function(){
return this.widgets.concat();
};
this.getWidgetByNode=function(node){
var w=this.getAllWidgets();
node=dojo.byId(node);
for(var i=0;i<w.length;i++){
if(w[i].domNode==node){
return w[i];
}
}
return null;
};
this.byId=this.getWidgetById;
this.byType=this.getWidgetsByType;
this.byFilter=this.getWidgetsByFilter;
this.byNode=this.getWidgetByNode;
var _34d={};
var _34e=["dojo.widget"];
for(var i=0;i<_34e.length;i++){
_34e[_34e[i]]=true;
}
this.registerWidgetPackage=function(_350){
if(!_34e[_350]){
_34e[_350]=true;
_34e.push(_350);
}
};
this.getWidgetPackageList=function(){
return dojo.lang.map(_34e,function(elt){
return (elt!==true?elt:undefined);
});
};
this.getImplementation=function(_352,_353,_354,ns){
var impl=this.getImplementationName(_352,ns);
if(impl){
var ret=_353?new impl(_353):new impl();
return ret;
}
};
function buildPrefixCache(){
for(var _358 in dojo.render){
if(dojo.render[_358]["capable"]===true){
var _359=dojo.render[_358].prefixes;
for(var i=0;i<_359.length;i++){
_335.push(_359[i].toLowerCase());
}
}
}
}
var _35b=function(_35c,_35d){
if(!_35d){
return null;
}
for(var i=0,l=_335.length,_360;i<=l;i++){
_360=(i<l?_35d[_335[i]]:_35d);
if(!_360){
continue;
}
for(var name in _360){
if(name.toLowerCase()==_35c){
return _360[name];
}
}
}
return null;
};
var _362=function(_363,_364){
var _365=dojo.evalObjPath(_364,false);
return (_365?_35b(_363,_365):null);
};
this.getImplementationName=function(_366,ns){
var _368=_366.toLowerCase();
ns=ns||"dojo";
var imps=_34d[ns]||(_34d[ns]={});
var impl=imps[_368];
if(impl){
return impl;
}
if(!_335.length){
buildPrefixCache();
}
var _36b=dojo.ns.get(ns);
if(!_36b){
dojo.ns.register(ns,ns+".widget");
_36b=dojo.ns.get(ns);
}
if(_36b){
_36b.resolve(_366);
}
impl=_362(_368,_36b.module);
if(impl){
return (imps[_368]=impl);
}
_36b=dojo.ns.require(ns);
if((_36b)&&(_36b.resolver)){
_36b.resolve(_366);
impl=_362(_368,_36b.module);
if(impl){
return (imps[_368]=impl);
}
}
dojo.deprecated("dojo.widget.Manager.getImplementationName","Could not locate widget implementation for \""+_366+"\" in \""+_36b.module+"\" registered to namespace \""+_36b.name+"\". "+"Developers must specify correct namespaces for all non-Dojo widgets","0.5");
for(var i=0;i<_34e.length;i++){
impl=_362(_368,_34e[i]);
if(impl){
return (imps[_368]=impl);
}
}
throw new Error("Could not locate widget implementation for \""+_366+"\" in \""+_36b.module+"\" registered to namespace \""+_36b.name+"\"");
};
this.resizing=false;
this.onWindowResized=function(){
if(this.resizing){
return;
}
try{
this.resizing=true;
for(var id in this.topWidgets){
var _36e=this.topWidgets[id];
if(_36e.checkSize){
_36e.checkSize();
}
}
}
catch(e){
}
finally{
this.resizing=false;
}
};
if(typeof window!="undefined"){
dojo.addOnLoad(this,"onWindowResized");
dojo.event.connect(window,"onresize",this,"onWindowResized");
}
};
(function(){
var dw=dojo.widget;
var dwm=dw.manager;
var h=dojo.lang.curry(dojo.lang,"hitch",dwm);
var g=function(_373,_374){
dw[(_374||_373)]=h(_373);
};
g("add","addWidget");
g("destroyAll","destroyAllWidgets");
g("remove","removeWidget");
g("removeById","removeWidgetById");
g("getWidgetById");
g("getWidgetById","byId");
g("getWidgetsByType");
g("getWidgetsByFilter");
g("getWidgetsByType","byType");
g("getWidgetsByFilter","byFilter");
g("getWidgetByNode","byNode");
dw.all=function(n){
var _376=dwm.getAllWidgets.apply(dwm,arguments);
if(arguments.length>0){
return _376[n];
}
return _376;
};
g("registerWidgetPackage");
g("getImplementation","getWidgetImplementation");
g("getImplementationName","getWidgetImplementationName");
dw.widgets=dwm.widgets;
dw.widgetIds=dwm.widgetIds;
dw.root=dwm.root;
})();
dojo.provide("dojo.uri.Uri");
dojo.uri=new function(){
this.dojoUri=function(uri){
return new dojo.uri.Uri(dojo.hostenv.getBaseScriptUri(),uri);
};
this.moduleUri=function(_378,uri){
var loc=dojo.hostenv.getModuleSymbols(_378).join("/");
if(!loc){
return null;
}
if(loc.lastIndexOf("/")!=loc.length-1){
loc+="/";
}
return new dojo.uri.Uri(dojo.hostenv.getBaseScriptUri()+loc,uri);
};
this.Uri=function(){
var uri=arguments[0];
for(var i=1;i<arguments.length;i++){
if(!arguments[i]){
continue;
}
var _37d=new dojo.uri.Uri(arguments[i].toString());
var _37e=new dojo.uri.Uri(uri.toString());
if((_37d.path=="")&&(_37d.scheme==null)&&(_37d.authority==null)&&(_37d.query==null)){
if(_37d.fragment!=null){
_37e.fragment=_37d.fragment;
}
_37d=_37e;
}else{
if(_37d.scheme==null){
_37d.scheme=_37e.scheme;
if(_37d.authority==null){
_37d.authority=_37e.authority;
if(_37d.path.charAt(0)!="/"){
var path=_37e.path.substring(0,_37e.path.lastIndexOf("/")+1)+_37d.path;
var segs=path.split("/");
for(var j=0;j<segs.length;j++){
if(segs[j]=="."){
if(j==segs.length-1){
segs[j]="";
}else{
segs.splice(j,1);
j--;
}
}else{
if(j>0&&!(j==1&&segs[0]=="")&&segs[j]==".."&&segs[j-1]!=".."){
if(j==segs.length-1){
segs.splice(j,1);
segs[j-1]="";
}else{
segs.splice(j-1,2);
j-=2;
}
}
}
}
_37d.path=segs.join("/");
}
}
}
}
uri="";
if(_37d.scheme!=null){
uri+=_37d.scheme+":";
}
if(_37d.authority!=null){
uri+="//"+_37d.authority;
}
uri+=_37d.path;
if(_37d.query!=null){
uri+="?"+_37d.query;
}
if(_37d.fragment!=null){
uri+="#"+_37d.fragment;
}
}
this.uri=uri.toString();
var _382="^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?$";
var r=this.uri.match(new RegExp(_382));
this.scheme=r[2]||(r[1]?"":null);
this.authority=r[4]||(r[3]?"":null);
this.path=r[5];
this.query=r[7]||(r[6]?"":null);
this.fragment=r[9]||(r[8]?"":null);
if(this.authority!=null){
_382="^((([^:]+:)?([^@]+))@)?([^:]*)(:([0-9]+))?$";
r=this.authority.match(new RegExp(_382));
this.user=r[3]||null;
this.password=r[4]||null;
this.host=r[5];
this.port=r[7]||null;
}
this.toString=function(){
return this.uri;
};
};
};
dojo.provide("dojo.uri.*");
dojo.provide("dojo.html.common");
dojo.lang.mixin(dojo.html,dojo.dom);
dojo.html.body=function(){
dojo.deprecated("dojo.html.body() moved to dojo.body()","0.5");
return dojo.body();
};
dojo.html.getEventTarget=function(evt){
if(!evt){
evt=dojo.global().event||{};
}
var t=(evt.srcElement?evt.srcElement:(evt.target?evt.target:null));
while((t)&&(t.nodeType!=1)){
t=t.parentNode;
}
return t;
};
dojo.html.getViewport=function(){
var _386=dojo.global();
var _387=dojo.doc();
var w=0;
var h=0;
if(dojo.render.html.mozilla){
w=_387.documentElement.clientWidth;
h=_386.innerHeight;
}else{
if(!dojo.render.html.opera&&_386.innerWidth){
w=_386.innerWidth;
h=_386.innerHeight;
}else{
if(!dojo.render.html.opera&&dojo.exists(_387,"documentElement.clientWidth")){
var w2=_387.documentElement.clientWidth;
if(!w||w2&&w2<w){
w=w2;
}
h=_387.documentElement.clientHeight;
}else{
if(dojo.body().clientWidth){
w=dojo.body().clientWidth;
h=dojo.body().clientHeight;
}
}
}
}
return {width:w,height:h};
};
dojo.html.getScroll=function(){
var _38b=dojo.global();
var _38c=dojo.doc();
var top=_38b.pageYOffset||_38c.documentElement.scrollTop||dojo.body().scrollTop||0;
var left=_38b.pageXOffset||_38c.documentElement.scrollLeft||dojo.body().scrollLeft||0;
return {top:top,left:left,offset:{x:left,y:top}};
};
dojo.html.getParentByType=function(node,type){
var _391=dojo.doc();
var _392=dojo.byId(node);
type=type.toLowerCase();
while((_392)&&(_392.nodeName.toLowerCase()!=type)){
if(_392==(_391["body"]||_391["documentElement"])){
return null;
}
_392=_392.parentNode;
}
return _392;
};
dojo.html.getAttribute=function(node,attr){
node=dojo.byId(node);
if((!node)||(!node.getAttribute)){
return null;
}
var ta=typeof attr=="string"?attr:new String(attr);
var v=node.getAttribute(ta.toUpperCase());
if((v)&&(typeof v=="string")&&(v!="")){
return v;
}
if(v&&v.value){
return v.value;
}
if((node.getAttributeNode)&&(node.getAttributeNode(ta))){
return (node.getAttributeNode(ta)).value;
}else{
if(node.getAttribute(ta)){
return node.getAttribute(ta);
}else{
if(node.getAttribute(ta.toLowerCase())){
return node.getAttribute(ta.toLowerCase());
}
}
}
return null;
};
dojo.html.hasAttribute=function(node,attr){
return dojo.html.getAttribute(dojo.byId(node),attr)?true:false;
};
dojo.html.getCursorPosition=function(e){
e=e||dojo.global().event;
var _39a={x:0,y:0};
if(e.pageX||e.pageY){
_39a.x=e.pageX;
_39a.y=e.pageY;
}else{
var de=dojo.doc().documentElement;
var db=dojo.body();
_39a.x=e.clientX+((de||db)["scrollLeft"])-((de||db)["clientLeft"]);
_39a.y=e.clientY+((de||db)["scrollTop"])-((de||db)["clientTop"]);
}
return _39a;
};
dojo.html.isTag=function(node){
node=dojo.byId(node);
if(node&&node.tagName){
for(var i=1;i<arguments.length;i++){
if(node.tagName.toLowerCase()==String(arguments[i]).toLowerCase()){
return String(arguments[i]).toLowerCase();
}
}
}
return "";
};
if(dojo.render.html.ie&&!dojo.render.html.ie70){
if(window.location.href.substr(0,6).toLowerCase()!="https:"){
(function(){
var _39f=dojo.doc().createElement("script");
_39f.src="javascript:'dojo.html.createExternalElement=function(doc, tag){ return doc.createElement(tag); }'";
dojo.doc().getElementsByTagName("head")[0].appendChild(_39f);
})();
}
}else{
dojo.html.createExternalElement=function(doc,tag){
return doc.createElement(tag);
};
}
dojo.html._callDeprecated=function(_3a2,_3a3,args,_3a5,_3a6){
dojo.deprecated("dojo.html."+_3a2,"replaced by dojo.html."+_3a3+"("+(_3a5?"node, {"+_3a5+": "+_3a5+"}":"")+")"+(_3a6?"."+_3a6:""),"0.5");
var _3a7=[];
if(_3a5){
var _3a8={};
_3a8[_3a5]=args[1];
_3a7.push(args[0]);
_3a7.push(_3a8);
}else{
_3a7=args;
}
var ret=dojo.html[_3a3].apply(dojo.html,args);
if(_3a6){
return ret[_3a6];
}else{
return ret;
}
};
dojo.html.getViewportWidth=function(){
return dojo.html._callDeprecated("getViewportWidth","getViewport",arguments,null,"width");
};
dojo.html.getViewportHeight=function(){
return dojo.html._callDeprecated("getViewportHeight","getViewport",arguments,null,"height");
};
dojo.html.getViewportSize=function(){
return dojo.html._callDeprecated("getViewportSize","getViewport",arguments);
};
dojo.html.getScrollTop=function(){
return dojo.html._callDeprecated("getScrollTop","getScroll",arguments,null,"top");
};
dojo.html.getScrollLeft=function(){
return dojo.html._callDeprecated("getScrollLeft","getScroll",arguments,null,"left");
};
dojo.html.getScrollOffset=function(){
return dojo.html._callDeprecated("getScrollOffset","getScroll",arguments,null,"offset");
};
dojo.provide("dojo.a11y");
dojo.a11y={imgPath:dojo.uri.dojoUri("src/widget/templates/images"),doAccessibleCheck:true,accessible:null,checkAccessible:function(){
if(this.accessible===null){
this.accessible=false;
if(this.doAccessibleCheck==true){
this.accessible=this.testAccessible();
}
}
return this.accessible;
},testAccessible:function(){
this.accessible=false;
if(dojo.render.html.ie||dojo.render.html.mozilla){
var div=document.createElement("div");
div.style.backgroundImage="url(\""+this.imgPath+"/tab_close.gif\")";
dojo.body().appendChild(div);
var _3ab=null;
if(window.getComputedStyle){
var _3ac=getComputedStyle(div,"");
_3ab=_3ac.getPropertyValue("background-image");
}else{
_3ab=div.currentStyle.backgroundImage;
}
var _3ad=false;
if(_3ab!=null&&(_3ab=="none"||_3ab=="url(invalid-url:)")){
this.accessible=true;
}
dojo.body().removeChild(div);
}
return this.accessible;
},setCheckAccessible:function(_3ae){
this.doAccessibleCheck=_3ae;
},setAccessibleMode:function(){
if(this.accessible===null){
if(this.checkAccessible()){
dojo.render.html.prefixes.unshift("a11y");
}
}
return this.accessible;
}};
dojo.provide("dojo.widget.Widget");
dojo.declare("dojo.widget.Widget",null,function(){
this.children=[];
this.extraArgs={};
},{parent:null,isTopLevel:false,disabled:false,isContainer:false,widgetId:"",widgetType:"Widget",ns:"dojo",getNamespacedType:function(){
return (this.ns?this.ns+":"+this.widgetType:this.widgetType).toLowerCase();
},toString:function(){
return "[Widget "+this.getNamespacedType()+", "+(this.widgetId||"NO ID")+"]";
},repr:function(){
return this.toString();
},enable:function(){
this.disabled=false;
},disable:function(){
this.disabled=true;
},onResized:function(){
this.notifyChildrenOfResize();
},notifyChildrenOfResize:function(){
for(var i=0;i<this.children.length;i++){
var _3b0=this.children[i];
if(_3b0.onResized){
_3b0.onResized();
}
}
},create:function(args,_3b2,_3b3,ns){
if(ns){
this.ns=ns;
}
this.satisfyPropertySets(args,_3b2,_3b3);
this.mixInProperties(args,_3b2,_3b3);
this.postMixInProperties(args,_3b2,_3b3);
dojo.widget.manager.add(this);
this.buildRendering(args,_3b2,_3b3);
this.initialize(args,_3b2,_3b3);
this.postInitialize(args,_3b2,_3b3);
this.postCreate(args,_3b2,_3b3);
return this;
},destroy:function(_3b5){
if(this.parent){
this.parent.removeChild(this);
}
this.destroyChildren();
this.uninitialize();
this.destroyRendering(_3b5);
dojo.widget.manager.removeById(this.widgetId);
},destroyChildren:function(){
var _3b6;
var i=0;
while(this.children.length>i){
_3b6=this.children[i];
if(_3b6 instanceof dojo.widget.Widget){
this.removeChild(_3b6);
_3b6.destroy();
continue;
}
i++;
}
},getChildrenOfType:function(type,_3b9){
var ret=[];
var _3bb=dojo.lang.isFunction(type);
if(!_3bb){
type=type.toLowerCase();
}
for(var x=0;x<this.children.length;x++){
if(_3bb){
if(this.children[x] instanceof type){
ret.push(this.children[x]);
}
}else{
if(this.children[x].widgetType.toLowerCase()==type){
ret.push(this.children[x]);
}
}
if(_3b9){
ret=ret.concat(this.children[x].getChildrenOfType(type,_3b9));
}
}
return ret;
},getDescendants:function(){
var _3bd=[];
var _3be=[this];
var elem;
while((elem=_3be.pop())){
_3bd.push(elem);
if(elem.children){
dojo.lang.forEach(elem.children,function(elem){
_3be.push(elem);
});
}
}
return _3bd;
},isFirstChild:function(){
return this===this.parent.children[0];
},isLastChild:function(){
return this===this.parent.children[this.parent.children.length-1];
},satisfyPropertySets:function(args){
return args;
},mixInProperties:function(args,frag){
if((args["fastMixIn"])||(frag["fastMixIn"])){
for(var x in args){
this[x]=args[x];
}
return;
}
var _3c5;
var _3c6=dojo.widget.lcArgsCache[this.widgetType];
if(_3c6==null){
_3c6={};
for(var y in this){
_3c6[((new String(y)).toLowerCase())]=y;
}
dojo.widget.lcArgsCache[this.widgetType]=_3c6;
}
var _3c8={};
for(var x in args){
if(!this[x]){
var y=_3c6[(new String(x)).toLowerCase()];
if(y){
args[y]=args[x];
x=y;
}
}
if(_3c8[x]){
continue;
}
_3c8[x]=true;
if((typeof this[x])!=(typeof _3c5)){
if(typeof args[x]!="string"){
this[x]=args[x];
}else{
if(dojo.lang.isString(this[x])){
this[x]=args[x];
}else{
if(dojo.lang.isNumber(this[x])){
this[x]=new Number(args[x]);
}else{
if(dojo.lang.isBoolean(this[x])){
this[x]=(args[x].toLowerCase()=="false")?false:true;
}else{
if(dojo.lang.isFunction(this[x])){
if(args[x].search(/[^\w\.]+/i)==-1){
this[x]=dojo.evalObjPath(args[x],false);
}else{
var tn=dojo.lang.nameAnonFunc(new Function(args[x]),this);
dojo.event.kwConnect({srcObj:this,srcFunc:x,adviceObj:this,adviceFunc:tn});
}
}else{
if(dojo.lang.isArray(this[x])){
this[x]=args[x].split(";");
}else{
if(this[x] instanceof Date){
this[x]=new Date(Number(args[x]));
}else{
if(typeof this[x]=="object"){
if(this[x] instanceof dojo.uri.Uri){
this[x]=dojo.uri.dojoUri(args[x]);
}else{
var _3ca=args[x].split(";");
for(var y=0;y<_3ca.length;y++){
var si=_3ca[y].indexOf(":");
if((si!=-1)&&(_3ca[y].length>si)){
this[x][_3ca[y].substr(0,si).replace(/^\s+|\s+$/g,"")]=_3ca[y].substr(si+1);
}
}
}
}else{
this[x]=args[x];
}
}
}
}
}
}
}
}
}else{
this.extraArgs[x.toLowerCase()]=args[x];
}
}
},postMixInProperties:function(args,frag,_3ce){
},initialize:function(args,frag,_3d1){
return false;
},postInitialize:function(args,frag,_3d4){
return false;
},postCreate:function(args,frag,_3d7){
return false;
},uninitialize:function(){
return false;
},buildRendering:function(args,frag,_3da){
dojo.unimplemented("dojo.widget.Widget.buildRendering, on "+this.toString()+", ");
return false;
},destroyRendering:function(){
dojo.unimplemented("dojo.widget.Widget.destroyRendering");
return false;
},addedTo:function(_3db){
},addChild:function(_3dc){
dojo.unimplemented("dojo.widget.Widget.addChild");
return false;
},removeChild:function(_3dd){
for(var x=0;x<this.children.length;x++){
if(this.children[x]===_3dd){
this.children.splice(x,1);
_3dd.parent=null;
break;
}
}
return _3dd;
},getPreviousSibling:function(){
var idx=this.getParentIndex();
if(idx<=0){
return null;
}
return this.parent.children[idx-1];
},getSiblings:function(){
return this.parent.children;
},getParentIndex:function(){
return dojo.lang.indexOf(this.parent.children,this,true);
},getNextSibling:function(){
var idx=this.getParentIndex();
if(idx==this.parent.children.length-1){
return null;
}
if(idx<0){
return null;
}
return this.parent.children[idx+1];
}});
dojo.widget.lcArgsCache={};
dojo.widget.tags={};
dojo.widget.tags.addParseTreeHandler=function(type){
dojo.deprecated("addParseTreeHandler",". ParseTreeHandlers are now reserved for components. Any unfiltered DojoML tag without a ParseTreeHandler is assumed to be a widget","0.5");
};
dojo.widget.tags["dojo:propertyset"]=function(_3e2,_3e3,_3e4){
var _3e5=_3e3.parseProperties(_3e2["dojo:propertyset"]);
};
dojo.widget.tags["dojo:connect"]=function(_3e6,_3e7,_3e8){
var _3e9=_3e7.parseProperties(_3e6["dojo:connect"]);
};
dojo.widget.buildWidgetFromParseTree=function(type,frag,_3ec,_3ed,_3ee,_3ef){
dojo.a11y.setAccessibleMode();
var _3f0=type.split(":");
_3f0=(_3f0.length==2)?_3f0[1]:type;
var _3f1=_3ef||_3ec.parseProperties(frag[frag["ns"]+":"+_3f0]);
var _3f2=dojo.widget.manager.getImplementation(_3f0,null,null,frag["ns"]);
if(!_3f2){
throw new Error("cannot find \""+type+"\" widget");
}else{
if(!_3f2.create){
throw new Error("\""+type+"\" widget object has no \"create\" method and does not appear to implement *Widget");
}
}
_3f1["dojoinsertionindex"]=_3ee;
var ret=_3f2.create(_3f1,frag,_3ed,frag["ns"]);
return ret;
};
dojo.widget.defineWidget=function(_3f4,_3f5,_3f6,init,_3f8){
if(dojo.lang.isString(arguments[3])){
dojo.widget._defineWidget(arguments[0],arguments[3],arguments[1],arguments[4],arguments[2]);
}else{
var args=[arguments[0]],p=3;
if(dojo.lang.isString(arguments[1])){
args.push(arguments[1],arguments[2]);
}else{
args.push("",arguments[1]);
p=2;
}
if(dojo.lang.isFunction(arguments[p])){
args.push(arguments[p],arguments[p+1]);
}else{
args.push(null,arguments[p]);
}
dojo.widget._defineWidget.apply(this,args);
}
};
dojo.widget.defineWidget.renderers="html|svg|vml";
dojo.widget._defineWidget=function(_3fb,_3fc,_3fd,init,_3ff){
var _400=_3fb.split(".");
var type=_400.pop();
var regx="\\.("+(_3fc?_3fc+"|":"")+dojo.widget.defineWidget.renderers+")\\.";
var r=_3fb.search(new RegExp(regx));
_400=(r<0?_400.join("."):_3fb.substr(0,r));
dojo.widget.manager.registerWidgetPackage(_400);
var pos=_400.indexOf(".");
var _405=(pos>-1)?_400.substring(0,pos):_400;
_3ff=(_3ff)||{};
_3ff.widgetType=type;
if((!init)&&(_3ff["classConstructor"])){
init=_3ff.classConstructor;
delete _3ff.classConstructor;
}
dojo.declare(_3fb,_3fd,init,_3ff);
};
dojo.provide("dojo.widget.Parse");
dojo.widget.Parse=function(_406){
this.propertySetsList=[];
this.fragment=_406;
this.createComponents=function(frag,_408){
var _409=[];
var _40a=false;
try{
if(frag&&frag.tagName&&(frag!=frag.nodeRef)){
var _40b=dojo.widget.tags;
var tna=String(frag.tagName).split(";");
for(var x=0;x<tna.length;x++){
var ltn=tna[x].replace(/^\s+|\s+$/g,"").toLowerCase();
frag.tagName=ltn;
var ret;
if(_40b[ltn]){
_40a=true;
ret=_40b[ltn](frag,this,_408,frag.index);
_409.push(ret);
}else{
if(ltn.indexOf(":")==-1){
ltn="dojo:"+ltn;
}
ret=dojo.widget.buildWidgetFromParseTree(ltn,frag,this,_408,frag.index);
if(ret){
_40a=true;
_409.push(ret);
}
}
}
}
}
catch(e){
dojo.debug("dojo.widget.Parse: error:",e);
}
if(!_40a){
_409=_409.concat(this.createSubComponents(frag,_408));
}
return _409;
};
this.createSubComponents=function(_410,_411){
var frag,_413=[];
for(var item in _410){
frag=_410[item];
if(frag&&typeof frag=="object"&&(frag!=_410.nodeRef)&&(frag!=_410.tagName)&&(!dojo.dom.isNode(frag))){
_413=_413.concat(this.createComponents(frag,_411));
}
}
return _413;
};
this.parsePropertySets=function(_415){
return [];
};
this.parseProperties=function(_416){
var _417={};
for(var item in _416){
if((_416[item]==_416.tagName)||(_416[item]==_416.nodeRef)){
}else{
var frag=_416[item];
if(frag.tagName&&dojo.widget.tags[frag.tagName.toLowerCase()]){
}else{
if(frag[0]&&frag[0].value!=""&&frag[0].value!=null){
try{
if(item.toLowerCase()=="dataprovider"){
var _41a=this;
this.getDataProvider(_41a,frag[0].value);
_417.dataProvider=this.dataProvider;
}
_417[item]=frag[0].value;
var _41b=this.parseProperties(frag);
for(var _41c in _41b){
_417[_41c]=_41b[_41c];
}
}
catch(e){
dojo.debug(e);
}
}
}
switch(item.toLowerCase()){
case "checked":
case "disabled":
if(typeof _417[item]!="boolean"){
_417[item]=true;
}
break;
}
}
}
return _417;
};
this.getDataProvider=function(_41d,_41e){
dojo.io.bind({url:_41e,load:function(type,_420){
if(type=="load"){
_41d.dataProvider=_420;
}
},mimetype:"text/javascript",sync:true});
};
this.getPropertySetById=function(_421){
for(var x=0;x<this.propertySetsList.length;x++){
if(_421==this.propertySetsList[x]["id"][0].value){
return this.propertySetsList[x];
}
}
return "";
};
this.getPropertySetsByType=function(_423){
var _424=[];
for(var x=0;x<this.propertySetsList.length;x++){
var cpl=this.propertySetsList[x];
var cpcc=cpl.componentClass||cpl.componentType||null;
var _428=this.propertySetsList[x]["id"][0].value;
if(cpcc&&(_428==cpcc[0].value)){
_424.push(cpl);
}
}
return _424;
};
this.getPropertySets=function(_429){
var ppl="dojo:propertyproviderlist";
var _42b=[];
var _42c=_429.tagName;
if(_429[ppl]){
var _42d=_429[ppl].value.split(" ");
for(var _42e in _42d){
if((_42e.indexOf("..")==-1)&&(_42e.indexOf("://")==-1)){
var _42f=this.getPropertySetById(_42e);
if(_42f!=""){
_42b.push(_42f);
}
}else{
}
}
}
return this.getPropertySetsByType(_42c).concat(_42b);
};
this.createComponentFromScript=function(_430,_431,_432,ns){
_432.fastMixIn=true;
var ltn=(ns||"dojo")+":"+_431.toLowerCase();
if(dojo.widget.tags[ltn]){
return [dojo.widget.tags[ltn](_432,this,null,null,_432)];
}
return [dojo.widget.buildWidgetFromParseTree(ltn,_432,this,null,null,_432)];
};
};
dojo.widget._parser_collection={"dojo":new dojo.widget.Parse()};
dojo.widget.getParser=function(name){
if(!name){
name="dojo";
}
if(!this._parser_collection[name]){
this._parser_collection[name]=new dojo.widget.Parse();
}
return this._parser_collection[name];
};
dojo.widget.createWidget=function(name,_437,_438,_439){
var _43a=false;
var _43b=(typeof name=="string");
if(_43b){
var pos=name.indexOf(":");
var ns=(pos>-1)?name.substring(0,pos):"dojo";
if(pos>-1){
name=name.substring(pos+1);
}
var _43e=name.toLowerCase();
var _43f=ns+":"+_43e;
_43a=(dojo.byId(name)&&!dojo.widget.tags[_43f]);
}
if((arguments.length==1)&&(_43a||!_43b)){
var xp=new dojo.xml.Parse();
var tn=_43a?dojo.byId(name):name;
return dojo.widget.getParser().createComponents(xp.parseElement(tn,null,true))[0];
}
function fromScript(_442,name,_444,ns){
_444[_43f]={dojotype:[{value:_43e}],nodeRef:_442,fastMixIn:true};
_444.ns=ns;
return dojo.widget.getParser().createComponentFromScript(_442,name,_444,ns);
}
_437=_437||{};
var _446=false;
var tn=null;
var h=dojo.render.html.capable;
if(h){
tn=document.createElement("span");
}
if(!_438){
_446=true;
_438=tn;
if(h){
dojo.body().appendChild(_438);
}
}else{
if(_439){
dojo.dom.insertAtPosition(tn,_438,_439);
}else{
tn=_438;
}
}
var _448=fromScript(tn,name.toLowerCase(),_437,ns);
if((!_448)||(!_448[0])||(typeof _448[0].widgetType=="undefined")){
throw new Error("createWidget: Creation of \""+name+"\" widget failed.");
}
try{
if(_446&&_448[0].domNode.parentNode){
_448[0].domNode.parentNode.removeChild(_448[0].domNode);
}
}
catch(e){
dojo.debug(e);
}
return _448[0];
};
dojo.provide("dojo.html.style");
dojo.html.getClass=function(node){
node=dojo.byId(node);
if(!node){
return "";
}
var cs="";
if(node.className){
cs=node.className;
}else{
if(dojo.html.hasAttribute(node,"class")){
cs=dojo.html.getAttribute(node,"class");
}
}
return cs.replace(/^\s+|\s+$/g,"");
};
dojo.html.getClasses=function(node){
var c=dojo.html.getClass(node);
return (c=="")?[]:c.split(/\s+/g);
};
dojo.html.hasClass=function(node,_44e){
return (new RegExp("(^|\\s+)"+_44e+"(\\s+|$)")).test(dojo.html.getClass(node));
};
dojo.html.prependClass=function(node,_450){
_450+=" "+dojo.html.getClass(node);
return dojo.html.setClass(node,_450);
};
dojo.html.addClass=function(node,_452){
if(dojo.html.hasClass(node,_452)){
return false;
}
_452=(dojo.html.getClass(node)+" "+_452).replace(/^\s+|\s+$/g,"");
return dojo.html.setClass(node,_452);
};
dojo.html.setClass=function(node,_454){
node=dojo.byId(node);
var cs=new String(_454);
try{
if(typeof node.className=="string"){
node.className=cs;
}else{
if(node.setAttribute){
node.setAttribute("class",_454);
node.className=cs;
}else{
return false;
}
}
}
catch(e){
dojo.debug("dojo.html.setClass() failed",e);
}
return true;
};
dojo.html.removeClass=function(node,_457,_458){
try{
if(!_458){
var _459=dojo.html.getClass(node).replace(new RegExp("(^|\\s+)"+_457+"(\\s+|$)"),"$1$2");
}else{
var _459=dojo.html.getClass(node).replace(_457,"");
}
dojo.html.setClass(node,_459);
}
catch(e){
dojo.debug("dojo.html.removeClass() failed",e);
}
return true;
};
dojo.html.replaceClass=function(node,_45b,_45c){
dojo.html.removeClass(node,_45c);
dojo.html.addClass(node,_45b);
};
dojo.html.classMatchType={ContainsAll:0,ContainsAny:1,IsOnly:2};
dojo.html.getElementsByClass=function(_45d,_45e,_45f,_460,_461){
_461=false;
var _462=dojo.doc();
_45e=dojo.byId(_45e)||_462;
var _463=_45d.split(/\s+/g);
var _464=[];
if(_460!=1&&_460!=2){
_460=0;
}
var _465=new RegExp("(\\s|^)(("+_463.join(")|(")+"))(\\s|$)");
var _466=_463.join(" ").length;
var _467=[];
if(!_461&&_462.evaluate){
var _468=".//"+(_45f||"*")+"[contains(";
if(_460!=dojo.html.classMatchType.ContainsAny){
_468+="concat(' ',@class,' '), ' "+_463.join(" ') and contains(concat(' ',@class,' '), ' ")+" ')";
if(_460==2){
_468+=" and string-length(@class)="+_466+"]";
}else{
_468+="]";
}
}else{
_468+="concat(' ',@class,' '), ' "+_463.join(" ') or contains(concat(' ',@class,' '), ' ")+" ')]";
}
var _469=_462.evaluate(_468,_45e,null,XPathResult.ANY_TYPE,null);
var _46a=_469.iterateNext();
while(_46a){
try{
_467.push(_46a);
_46a=_469.iterateNext();
}
catch(e){
break;
}
}
return _467;
}else{
if(!_45f){
_45f="*";
}
_467=_45e.getElementsByTagName(_45f);
var node,i=0;
outer:
while(node=_467[i++]){
var _46d=dojo.html.getClasses(node);
if(_46d.length==0){
continue outer;
}
var _46e=0;
for(var j=0;j<_46d.length;j++){
if(_465.test(_46d[j])){
if(_460==dojo.html.classMatchType.ContainsAny){
_464.push(node);
continue outer;
}else{
_46e++;
}
}else{
if(_460==dojo.html.classMatchType.IsOnly){
continue outer;
}
}
}
if(_46e==_463.length){
if((_460==dojo.html.classMatchType.IsOnly)&&(_46e==_46d.length)){
_464.push(node);
}else{
if(_460==dojo.html.classMatchType.ContainsAll){
_464.push(node);
}
}
}
}
return _464;
}
};
dojo.html.getElementsByClassName=dojo.html.getElementsByClass;
dojo.html.toCamelCase=function(_470){
var arr=_470.split("-"),cc=arr[0];
for(var i=1;i<arr.length;i++){
cc+=arr[i].charAt(0).toUpperCase()+arr[i].substring(1);
}
return cc;
};
dojo.html.toSelectorCase=function(_474){
return _474.replace(/([A-Z])/g,"-$1").toLowerCase();
};
dojo.html.getComputedStyle=function(node,_476,_477){
node=dojo.byId(node);
var _476=dojo.html.toSelectorCase(_476);
var _478=dojo.html.toCamelCase(_476);
if(!node||!node.style){
return _477;
}else{
if(document.defaultView&&dojo.html.isDescendantOf(node,node.ownerDocument)){
try{
var cs=document.defaultView.getComputedStyle(node,"");
if(cs){
return cs.getPropertyValue(_476);
}
}
catch(e){
if(node.style.getPropertyValue){
return node.style.getPropertyValue(_476);
}else{
return _477;
}
}
}else{
if(node.currentStyle){
return node.currentStyle[_478];
}
}
}
if(node.style.getPropertyValue){
return node.style.getPropertyValue(_476);
}else{
return _477;
}
};
dojo.html.getStyleProperty=function(node,_47b){
node=dojo.byId(node);
return (node&&node.style?node.style[dojo.html.toCamelCase(_47b)]:undefined);
};
dojo.html.getStyle=function(node,_47d){
var _47e=dojo.html.getStyleProperty(node,_47d);
return (_47e?_47e:dojo.html.getComputedStyle(node,_47d));
};
dojo.html.setStyle=function(node,_480,_481){
node=dojo.byId(node);
if(node&&node.style){
var _482=dojo.html.toCamelCase(_480);
node.style[_482]=_481;
}
};
dojo.html.setStyleText=function(_483,text){
try{
_483.style.cssText=text;
}
catch(e){
_483.setAttribute("style",text);
}
};
dojo.html.copyStyle=function(_485,_486){
if(!_486.style.cssText){
_485.setAttribute("style",_486.getAttribute("style"));
}else{
_485.style.cssText=_486.style.cssText;
}
dojo.html.addClass(_485,dojo.html.getClass(_486));
};
dojo.html.getUnitValue=function(node,_488,_489){
var s=dojo.html.getComputedStyle(node,_488);
if((!s)||((s=="auto")&&(_489))){
return {value:0,units:"px"};
}
var _48b=s.match(/(\-?[\d.]+)([a-z%]*)/i);
if(!_48b){
return dojo.html.getUnitValue.bad;
}
return {value:Number(_48b[1]),units:_48b[2].toLowerCase()};
};
dojo.html.getUnitValue.bad={value:NaN,units:""};
dojo.html.getPixelValue=function(node,_48d,_48e){
var _48f=dojo.html.getUnitValue(node,_48d,_48e);
if(isNaN(_48f.value)){
return 0;
}
if((_48f.value)&&(_48f.units!="px")){
return NaN;
}
return _48f.value;
};
dojo.html.setPositivePixelValue=function(node,_491,_492){
if(isNaN(_492)){
return false;
}
node.style[_491]=Math.max(0,_492)+"px";
return true;
};
dojo.html.styleSheet=null;
dojo.html.insertCssRule=function(_493,_494,_495){
if(!dojo.html.styleSheet){
if(document.createStyleSheet){
dojo.html.styleSheet=document.createStyleSheet();
}else{
if(document.styleSheets[0]){
dojo.html.styleSheet=document.styleSheets[0];
}else{
return null;
}
}
}
if(arguments.length<3){
if(dojo.html.styleSheet.cssRules){
_495=dojo.html.styleSheet.cssRules.length;
}else{
if(dojo.html.styleSheet.rules){
_495=dojo.html.styleSheet.rules.length;
}else{
return null;
}
}
}
if(dojo.html.styleSheet.insertRule){
var rule=_493+" { "+_494+" }";
return dojo.html.styleSheet.insertRule(rule,_495);
}else{
if(dojo.html.styleSheet.addRule){
return dojo.html.styleSheet.addRule(_493,_494,_495);
}else{
return null;
}
}
};
dojo.html.removeCssRule=function(_497){
if(!dojo.html.styleSheet){
dojo.debug("no stylesheet defined for removing rules");
return false;
}
if(dojo.render.html.ie){
if(!_497){
_497=dojo.html.styleSheet.rules.length;
dojo.html.styleSheet.removeRule(_497);
}
}else{
if(document.styleSheets[0]){
if(!_497){
_497=dojo.html.styleSheet.cssRules.length;
}
dojo.html.styleSheet.deleteRule(_497);
}
}
return true;
};
dojo.html._insertedCssFiles=[];
dojo.html.insertCssFile=function(URI,doc,_49a,_49b){
if(!URI){
return;
}
if(!doc){
doc=document;
}
var _49c=dojo.hostenv.getText(URI,false,_49b);
if(_49c===null){
return;
}
_49c=dojo.html.fixPathsInCssText(_49c,URI);
if(_49a){
var idx=-1,node,ent=dojo.html._insertedCssFiles;
for(var i=0;i<ent.length;i++){
if((ent[i].doc==doc)&&(ent[i].cssText==_49c)){
idx=i;
node=ent[i].nodeRef;
break;
}
}
if(node){
var _4a1=doc.getElementsByTagName("style");
for(var i=0;i<_4a1.length;i++){
if(_4a1[i]==node){
return;
}
}
dojo.html._insertedCssFiles.shift(idx,1);
}
}
var _4a2=dojo.html.insertCssText(_49c,doc);
dojo.html._insertedCssFiles.push({"doc":doc,"cssText":_49c,"nodeRef":_4a2});
if(_4a2&&djConfig.isDebug){
_4a2.setAttribute("dbgHref",URI);
}
return _4a2;
};
dojo.html.insertCssText=function(_4a3,doc,URI){
if(!_4a3){
return;
}
if(!doc){
doc=document;
}
if(URI){
_4a3=dojo.html.fixPathsInCssText(_4a3,URI);
}
var _4a6=doc.createElement("style");
_4a6.setAttribute("type","text/css");
var head=doc.getElementsByTagName("head")[0];
if(!head){
dojo.debug("No head tag in document, aborting styles");
return;
}else{
head.appendChild(_4a6);
}
if(_4a6.styleSheet){
var _4a8=function(){
try{
_4a6.styleSheet.cssText=_4a3;
}
catch(e){
dojo.debug(e);
}
};
if(_4a6.styleSheet.disabled){
setTimeout(_4a8,10);
}else{
_4a8();
}
}else{
var _4a9=doc.createTextNode(_4a3);
_4a6.appendChild(_4a9);
}
return _4a6;
};
dojo.html.fixPathsInCssText=function(_4aa,URI){
if(!_4aa||!URI){
return;
}
var _4ac,str="",url="",_4af="[\\t\\s\\w\\(\\)\\/\\.\\\\'\"-:#=&?~]+";
var _4b0=new RegExp("url\\(\\s*("+_4af+")\\s*\\)");
var _4b1=/(file|https?|ftps?):\/\//;
regexTrim=new RegExp("^[\\s]*(['\"]?)("+_4af+")\\1[\\s]*?$");
if(dojo.render.html.ie55||dojo.render.html.ie60){
var _4b2=new RegExp("AlphaImageLoader\\((.*)src=['\"]("+_4af+")['\"]");
while(_4ac=_4b2.exec(_4aa)){
url=_4ac[2].replace(regexTrim,"$2");
if(!_4b1.exec(url)){
url=(new dojo.uri.Uri(URI,url).toString());
}
str+=_4aa.substring(0,_4ac.index)+"AlphaImageLoader("+_4ac[1]+"src='"+url+"'";
_4aa=_4aa.substr(_4ac.index+_4ac[0].length);
}
_4aa=str+_4aa;
str="";
}
while(_4ac=_4b0.exec(_4aa)){
url=_4ac[1].replace(regexTrim,"$2");
if(!_4b1.exec(url)){
url=(new dojo.uri.Uri(URI,url).toString());
}
str+=_4aa.substring(0,_4ac.index)+"url("+url+")";
_4aa=_4aa.substr(_4ac.index+_4ac[0].length);
}
return str+_4aa;
};
dojo.html.setActiveStyleSheet=function(_4b3){
var i=0,a,els=dojo.doc().getElementsByTagName("link");
while(a=els[i++]){
if(a.getAttribute("rel").indexOf("style")!=-1&&a.getAttribute("title")){
a.disabled=true;
if(a.getAttribute("title")==_4b3){
a.disabled=false;
}
}
}
};
dojo.html.getActiveStyleSheet=function(){
var i=0,a,els=dojo.doc().getElementsByTagName("link");
while(a=els[i++]){
if(a.getAttribute("rel").indexOf("style")!=-1&&a.getAttribute("title")&&!a.disabled){
return a.getAttribute("title");
}
}
return null;
};
dojo.html.getPreferredStyleSheet=function(){
var i=0,a,els=dojo.doc().getElementsByTagName("link");
while(a=els[i++]){
if(a.getAttribute("rel").indexOf("style")!=-1&&a.getAttribute("rel").indexOf("alt")==-1&&a.getAttribute("title")){
return a.getAttribute("title");
}
}
return null;
};
dojo.html.applyBrowserClass=function(node){
var drh=dojo.render.html;
var _4bf={dj_ie:drh.ie,dj_ie55:drh.ie55,dj_ie6:drh.ie60,dj_ie7:drh.ie70,dj_iequirks:drh.ie&&drh.quirks,dj_opera:drh.opera,dj_opera8:drh.opera&&(Math.floor(dojo.render.version)==8),dj_opera9:drh.opera&&(Math.floor(dojo.render.version)==9),dj_khtml:drh.khtml,dj_safari:drh.safari,dj_gecko:drh.mozilla};
for(var p in _4bf){
if(_4bf[p]){
dojo.html.addClass(node,p);
}
}
};
dojo.provide("dojo.widget.DomWidget");
dojo.widget._cssFiles={};
dojo.widget._cssStrings={};
dojo.widget._templateCache={};
dojo.widget.defaultStrings={dojoRoot:dojo.hostenv.getBaseScriptUri(),baseScriptUri:dojo.hostenv.getBaseScriptUri()};
dojo.widget.fillFromTemplateCache=function(obj,_4c2,_4c3,_4c4){
var _4c5=_4c2||obj.templatePath;
var _4c6=dojo.widget._templateCache;
if(!_4c5&&!obj["widgetType"]){
do{
var _4c7="__dummyTemplate__"+dojo.widget._templateCache.dummyCount++;
}while(_4c6[_4c7]);
obj.widgetType=_4c7;
}
var wt=_4c5?_4c5.toString():obj.widgetType;
var ts=_4c6[wt];
if(!ts){
_4c6[wt]={"string":null,"node":null};
if(_4c4){
ts={};
}else{
ts=_4c6[wt];
}
}
if((!obj.templateString)&&(!_4c4)){
obj.templateString=_4c3||ts["string"];
}
if((!obj.templateNode)&&(!_4c4)){
obj.templateNode=ts["node"];
}
if((!obj.templateNode)&&(!obj.templateString)&&(_4c5)){
var _4ca=dojo.hostenv.getText(_4c5);
if(_4ca){
_4ca=_4ca.replace(/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im,"");
var _4cb=_4ca.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_4cb){
_4ca=_4cb[1];
}
}else{
_4ca="";
}
obj.templateString=_4ca;
if(!_4c4){
_4c6[wt]["string"]=_4ca;
}
}
if((!ts["string"])&&(!_4c4)){
ts.string=obj.templateString;
}
};
dojo.widget._templateCache.dummyCount=0;
dojo.widget.attachProperties=["dojoAttachPoint","id"];
dojo.widget.eventAttachProperty="dojoAttachEvent";
dojo.widget.onBuildProperty="dojoOnBuild";
dojo.widget.waiNames=["waiRole","waiState"];
dojo.widget.wai={waiRole:{name:"waiRole","namespace":"http://www.w3.org/TR/xhtml2",alias:"x2",prefix:"wairole:"},waiState:{name:"waiState","namespace":"http://www.w3.org/2005/07/aaa",alias:"aaa",prefix:""},setAttr:function(node,ns,attr,_4cf){
if(dojo.render.html.ie){
node.setAttribute(this[ns].alias+":"+attr,this[ns].prefix+_4cf);
}else{
node.setAttributeNS(this[ns]["namespace"],attr,this[ns].prefix+_4cf);
}
},getAttr:function(node,ns,attr){
if(dojo.render.html.ie){
return node.getAttribute(this[ns].alias+":"+attr);
}else{
return node.getAttributeNS(this[ns]["namespace"],attr);
}
},removeAttr:function(node,ns,attr){
var _4d6=true;
if(dojo.render.html.ie){
_4d6=node.removeAttribute(this[ns].alias+":"+attr);
}else{
node.removeAttributeNS(this[ns]["namespace"],attr);
}
return _4d6;
}};
dojo.widget.attachTemplateNodes=function(_4d7,_4d8,_4d9){
var _4da=dojo.dom.ELEMENT_NODE;
function trim(str){
return str.replace(/^\s+|\s+$/g,"");
}
if(!_4d7){
_4d7=_4d8.domNode;
}
if(_4d7.nodeType!=_4da){
return;
}
var _4dc=_4d7.all||_4d7.getElementsByTagName("*");
var _4dd=_4d8;
for(var x=-1;x<_4dc.length;x++){
var _4df=(x==-1)?_4d7:_4dc[x];
var _4e0=[];
if(!_4d8.widgetsInTemplate||!_4df.getAttribute("dojoType")){
for(var y=0;y<this.attachProperties.length;y++){
var _4e2=_4df.getAttribute(this.attachProperties[y]);
if(_4e2){
_4e0=_4e2.split(";");
for(var z=0;z<_4e0.length;z++){
if(dojo.lang.isArray(_4d8[_4e0[z]])){
_4d8[_4e0[z]].push(_4df);
}else{
_4d8[_4e0[z]]=_4df;
}
}
break;
}
}
var _4e4=_4df.getAttribute(this.eventAttachProperty);
if(_4e4){
var evts=_4e4.split(";");
for(var y=0;y<evts.length;y++){
if((!evts[y])||(!evts[y].length)){
continue;
}
var _4e6=null;
var tevt=trim(evts[y]);
if(evts[y].indexOf(":")>=0){
var _4e8=tevt.split(":");
tevt=trim(_4e8[0]);
_4e6=trim(_4e8[1]);
}
if(!_4e6){
_4e6=tevt;
}
var tf=function(){
var ntf=new String(_4e6);
return function(evt){
if(_4dd[ntf]){
_4dd[ntf](dojo.event.browser.fixEvent(evt,this));
}
};
}();
dojo.event.browser.addListener(_4df,tevt,tf,false,true);
}
}
for(var y=0;y<_4d9.length;y++){
var _4ec=_4df.getAttribute(_4d9[y]);
if((_4ec)&&(_4ec.length)){
var _4e6=null;
var _4ed=_4d9[y].substr(4);
_4e6=trim(_4ec);
var _4ee=[_4e6];
if(_4e6.indexOf(";")>=0){
_4ee=dojo.lang.map(_4e6.split(";"),trim);
}
for(var z=0;z<_4ee.length;z++){
if(!_4ee[z].length){
continue;
}
var tf=function(){
var ntf=new String(_4ee[z]);
return function(evt){
if(_4dd[ntf]){
_4dd[ntf](dojo.event.browser.fixEvent(evt,this));
}
};
}();
dojo.event.browser.addListener(_4df,_4ed,tf,false,true);
}
}
}
}
var _4f1=_4df.getAttribute(this.templateProperty);
if(_4f1){
_4d8[_4f1]=_4df;
}
dojo.lang.forEach(dojo.widget.waiNames,function(name){
var wai=dojo.widget.wai[name];
var val=_4df.getAttribute(wai.name);
if(val){
if(val.indexOf("-")==-1){
dojo.widget.wai.setAttr(_4df,wai.name,"role",val);
}else{
var _4f5=val.split("-");
dojo.widget.wai.setAttr(_4df,wai.name,_4f5[0],_4f5[1]);
}
}
},this);
var _4f6=_4df.getAttribute(this.onBuildProperty);
if(_4f6){
eval("var node = baseNode; var widget = targetObj; "+_4f6);
}
}
};
dojo.widget.getDojoEventsFromStr=function(str){
var re=/(dojoOn([a-z]+)(\s?))=/gi;
var evts=str?str.match(re)||[]:[];
var ret=[];
var lem={};
for(var x=0;x<evts.length;x++){
if(evts[x].length<1){
continue;
}
var cm=evts[x].replace(/\s/,"");
cm=(cm.slice(0,cm.length-1));
if(!lem[cm]){
lem[cm]=true;
ret.push(cm);
}
}
return ret;
};
dojo.declare("dojo.widget.DomWidget",dojo.widget.Widget,function(){
if((arguments.length>0)&&(typeof arguments[0]=="object")){
this.create(arguments[0]);
}
},{templateNode:null,templateString:null,templateCssString:null,preventClobber:false,domNode:null,containerNode:null,widgetsInTemplate:false,addChild:function(_4fe,_4ff,pos,ref,_502){
if(!this.isContainer){
dojo.debug("dojo.widget.DomWidget.addChild() attempted on non-container widget");
return null;
}else{
if(_502==undefined){
_502=this.children.length;
}
this.addWidgetAsDirectChild(_4fe,_4ff,pos,ref,_502);
this.registerChild(_4fe,_502);
}
return _4fe;
},addWidgetAsDirectChild:function(_503,_504,pos,ref,_507){
if((!this.containerNode)&&(!_504)){
this.containerNode=this.domNode;
}
var cn=(_504)?_504:this.containerNode;
if(!pos){
pos="after";
}
if(!ref){
if(!cn){
cn=dojo.body();
}
ref=cn.lastChild;
}
if(!_507){
_507=0;
}
_503.domNode.setAttribute("dojoinsertionindex",_507);
if(!ref){
cn.appendChild(_503.domNode);
}else{
if(pos=="insertAtIndex"){
dojo.dom.insertAtIndex(_503.domNode,ref.parentNode,_507);
}else{
if((pos=="after")&&(ref===cn.lastChild)){
cn.appendChild(_503.domNode);
}else{
dojo.dom.insertAtPosition(_503.domNode,cn,pos);
}
}
}
},registerChild:function(_509,_50a){
_509.dojoInsertionIndex=_50a;
var idx=-1;
for(var i=0;i<this.children.length;i++){
if(this.children[i].dojoInsertionIndex<=_50a){
idx=i;
}
}
this.children.splice(idx+1,0,_509);
_509.parent=this;
_509.addedTo(this,idx+1);
delete dojo.widget.manager.topWidgets[_509.widgetId];
},removeChild:function(_50d){
dojo.dom.removeNode(_50d.domNode);
return dojo.widget.DomWidget.superclass.removeChild.call(this,_50d);
},getFragNodeRef:function(frag){
if(!frag){
return null;
}
if(!frag[this.getNamespacedType()]){
dojo.raise("Error: no frag for widget type "+this.getNamespacedType()+", id "+this.widgetId+" (maybe a widget has set it's type incorrectly)");
}
return frag[this.getNamespacedType()]["nodeRef"];
},postInitialize:function(args,frag,_511){
var _512=this.getFragNodeRef(frag);
if(_511&&(_511.snarfChildDomOutput||!_512)){
_511.addWidgetAsDirectChild(this,"","insertAtIndex","",args["dojoinsertionindex"],_512);
}else{
if(_512){
if(this.domNode&&(this.domNode!==_512)){
this._sourceNodeRef=dojo.dom.replaceNode(_512,this.domNode);
}
}
}
if(_511){
_511.registerChild(this,args.dojoinsertionindex);
}else{
dojo.widget.manager.topWidgets[this.widgetId]=this;
}
if(this.widgetsInTemplate){
var _513=new dojo.xml.Parse();
var _514;
var _515=this.domNode.getElementsByTagName("*");
for(var i=0;i<_515.length;i++){
if(_515[i].getAttribute("dojoAttachPoint")=="subContainerWidget"){
_514=_515[i];
}
if(_515[i].getAttribute("dojoType")){
_515[i].setAttribute("isSubWidget",true);
}
}
if(this.isContainer&&!this.containerNode){
if(_514){
var src=this.getFragNodeRef(frag);
if(src){
dojo.dom.moveChildren(src,_514);
frag["dojoDontFollow"]=true;
}
}else{
dojo.debug("No subContainerWidget node can be found in template file for widget "+this);
}
}
var _518=_513.parseElement(this.domNode,null,true);
dojo.widget.getParser().createSubComponents(_518,this);
var _519=[];
var _51a=[this];
var w;
while((w=_51a.pop())){
for(var i=0;i<w.children.length;i++){
var _51c=w.children[i];
if(_51c._processedSubWidgets||!_51c.extraArgs["issubwidget"]){
continue;
}
_519.push(_51c);
if(_51c.isContainer){
_51a.push(_51c);
}
}
}
for(var i=0;i<_519.length;i++){
var _51d=_519[i];
if(_51d._processedSubWidgets){
dojo.debug("This should not happen: widget._processedSubWidgets is already true!");
return;
}
_51d._processedSubWidgets=true;
if(_51d.extraArgs["dojoattachevent"]){
var evts=_51d.extraArgs["dojoattachevent"].split(";");
for(var j=0;j<evts.length;j++){
var _520=null;
var tevt=dojo.string.trim(evts[j]);
if(tevt.indexOf(":")>=0){
var _522=tevt.split(":");
tevt=dojo.string.trim(_522[0]);
_520=dojo.string.trim(_522[1]);
}
if(!_520){
_520=tevt;
}
if(dojo.lang.isFunction(_51d[tevt])){
dojo.event.kwConnect({srcObj:_51d,srcFunc:tevt,targetObj:this,targetFunc:_520});
}else{
alert(tevt+" is not a function in widget "+_51d);
}
}
}
if(_51d.extraArgs["dojoattachpoint"]){
this[_51d.extraArgs["dojoattachpoint"]]=_51d;
}
}
}
if(this.isContainer&&!frag["dojoDontFollow"]){
dojo.widget.getParser().createSubComponents(frag,this);
}
},buildRendering:function(args,frag){
var ts=dojo.widget._templateCache[this.widgetType];
if(args["templatecsspath"]){
args["templateCssPath"]=args["templatecsspath"];
}
var _526=args["templateCssPath"]||this.templateCssPath;
if(_526&&!dojo.widget._cssFiles[_526.toString()]){
if((!this.templateCssString)&&(_526)){
this.templateCssString=dojo.hostenv.getText(_526);
this.templateCssPath=null;
}
dojo.widget._cssFiles[_526.toString()]=true;
}
if((this["templateCssString"])&&(!dojo.widget._cssStrings[this.templateCssString])){
dojo.html.insertCssText(this.templateCssString,null,_526);
dojo.widget._cssStrings[this.templateCssString]=true;
}
if((!this.preventClobber)&&((this.templatePath)||(this.templateNode)||((this["templateString"])&&(this.templateString.length))||((typeof ts!="undefined")&&((ts["string"])||(ts["node"]))))){
this.buildFromTemplate(args,frag);
}else{
this.domNode=this.getFragNodeRef(frag);
}
this.fillInTemplate(args,frag);
},buildFromTemplate:function(args,frag){
var _529=false;
if(args["templatepath"]){
args["templatePath"]=args["templatepath"];
}
dojo.widget.fillFromTemplateCache(this,args["templatePath"],null,_529);
var ts=dojo.widget._templateCache[this.templatePath?this.templatePath.toString():this.widgetType];
if((ts)&&(!_529)){
if(!this.templateString.length){
this.templateString=ts["string"];
}
if(!this.templateNode){
this.templateNode=ts["node"];
}
}
var _52b=false;
var node=null;
var tstr=this.templateString;
if((!this.templateNode)&&(this.templateString)){
_52b=this.templateString.match(/\$\{([^\}]+)\}/g);
if(_52b){
var hash=this.strings||{};
for(var key in dojo.widget.defaultStrings){
if(dojo.lang.isUndefined(hash[key])){
hash[key]=dojo.widget.defaultStrings[key];
}
}
for(var i=0;i<_52b.length;i++){
var key=_52b[i];
key=key.substring(2,key.length-1);
var kval=(key.substring(0,5)=="this.")?dojo.lang.getObjPathValue(key.substring(5),this):hash[key];
var _532;
if((kval)||(dojo.lang.isString(kval))){
_532=new String((dojo.lang.isFunction(kval))?kval.call(this,key,this.templateString):kval);
while(_532.indexOf("\"")>-1){
_532=_532.replace("\"","&quot;");
}
tstr=tstr.replace(_52b[i],_532);
}
}
}else{
this.templateNode=this.createNodesFromText(this.templateString,true)[0];
if(!_529){
ts.node=this.templateNode;
}
}
}
if((!this.templateNode)&&(!_52b)){
dojo.debug("DomWidget.buildFromTemplate: could not create template");
return false;
}else{
if(!_52b){
node=this.templateNode.cloneNode(true);
if(!node){
return false;
}
}else{
node=this.createNodesFromText(tstr,true)[0];
}
}
this.domNode=node;
this.attachTemplateNodes();
if(this.isContainer&&this.containerNode){
var src=this.getFragNodeRef(frag);
if(src){
dojo.dom.moveChildren(src,this.containerNode);
}
}
},attachTemplateNodes:function(_534,_535){
if(!_534){
_534=this.domNode;
}
if(!_535){
_535=this;
}
return dojo.widget.attachTemplateNodes(_534,_535,dojo.widget.getDojoEventsFromStr(this.templateString));
},fillInTemplate:function(){
},destroyRendering:function(){
try{
dojo.dom.destroyNode(this.domNode);
delete this.domNode;
}
catch(e){
}
if(this._sourceNodeRef){
try{
dojo.dom.destroyNode(this._sourceNodeRef);
}
catch(e){
}
}
},createNodesFromText:function(){
dojo.unimplemented("dojo.widget.DomWidget.createNodesFromText");
}});
dojo.provide("dojo.html.display");
dojo.html._toggle=function(node,_537,_538){
node=dojo.byId(node);
_538(node,!_537(node));
return _537(node);
};
dojo.html.show=function(node){
node=dojo.byId(node);
if(dojo.html.getStyleProperty(node,"display")=="none"){
dojo.html.setStyle(node,"display",(node.dojoDisplayCache||""));
node.dojoDisplayCache=undefined;
}
};
dojo.html.hide=function(node){
node=dojo.byId(node);
if(typeof node["dojoDisplayCache"]=="undefined"){
var d=dojo.html.getStyleProperty(node,"display");
if(d!="none"){
node.dojoDisplayCache=d;
}
}
dojo.html.setStyle(node,"display","none");
};
dojo.html.setShowing=function(node,_53d){
dojo.html[(_53d?"show":"hide")](node);
};
dojo.html.isShowing=function(node){
return (dojo.html.getStyleProperty(node,"display")!="none");
};
dojo.html.toggleShowing=function(node){
return dojo.html._toggle(node,dojo.html.isShowing,dojo.html.setShowing);
};
dojo.html.displayMap={tr:"",td:"",th:"",img:"inline",span:"inline",input:"inline",button:"inline"};
dojo.html.suggestDisplayByTagName=function(node){
node=dojo.byId(node);
if(node&&node.tagName){
var tag=node.tagName.toLowerCase();
return (tag in dojo.html.displayMap?dojo.html.displayMap[tag]:"block");
}
};
dojo.html.setDisplay=function(node,_543){
dojo.html.setStyle(node,"display",((_543 instanceof String||typeof _543=="string")?_543:(_543?dojo.html.suggestDisplayByTagName(node):"none")));
};
dojo.html.isDisplayed=function(node){
return (dojo.html.getComputedStyle(node,"display")!="none");
};
dojo.html.toggleDisplay=function(node){
return dojo.html._toggle(node,dojo.html.isDisplayed,dojo.html.setDisplay);
};
dojo.html.setVisibility=function(node,_547){
dojo.html.setStyle(node,"visibility",((_547 instanceof String||typeof _547=="string")?_547:(_547?"visible":"hidden")));
};
dojo.html.isVisible=function(node){
return (dojo.html.getComputedStyle(node,"visibility")!="hidden");
};
dojo.html.toggleVisibility=function(node){
return dojo.html._toggle(node,dojo.html.isVisible,dojo.html.setVisibility);
};
dojo.html.setOpacity=function(node,_54b,_54c){
node=dojo.byId(node);
var h=dojo.render.html;
if(!_54c){
if(_54b>=1){
if(h.ie){
dojo.html.clearOpacity(node);
return;
}else{
_54b=0.999999;
}
}else{
if(_54b<0){
_54b=0;
}
}
}
if(h.ie){
if(node.nodeName.toLowerCase()=="tr"){
var tds=node.getElementsByTagName("td");
for(var x=0;x<tds.length;x++){
tds[x].style.filter="Alpha(Opacity="+_54b*100+")";
}
}
node.style.filter="Alpha(Opacity="+_54b*100+")";
}else{
if(h.moz){
node.style.opacity=_54b;
node.style.MozOpacity=_54b;
}else{
if(h.safari){
node.style.opacity=_54b;
node.style.KhtmlOpacity=_54b;
}else{
node.style.opacity=_54b;
}
}
}
};
dojo.html.clearOpacity=function(node){
node=dojo.byId(node);
var ns=node.style;
var h=dojo.render.html;
if(h.ie){
try{
if(node.filters&&node.filters.alpha){
ns.filter="";
}
}
catch(e){
}
}else{
if(h.moz){
ns.opacity=1;
ns.MozOpacity=1;
}else{
if(h.safari){
ns.opacity=1;
ns.KhtmlOpacity=1;
}else{
ns.opacity=1;
}
}
}
};
dojo.html.getOpacity=function(node){
node=dojo.byId(node);
var h=dojo.render.html;
if(h.ie){
var opac=(node.filters&&node.filters.alpha&&typeof node.filters.alpha.opacity=="number"?node.filters.alpha.opacity:100)/100;
}else{
var opac=node.style.opacity||node.style.MozOpacity||node.style.KhtmlOpacity||1;
}
return opac>=0.999999?1:Number(opac);
};
dojo.provide("dojo.html.layout");
dojo.html.sumAncestorProperties=function(node,prop){
node=dojo.byId(node);
if(!node){
return 0;
}
var _558=0;
while(node){
if(dojo.html.getComputedStyle(node,"position")=="fixed"){
return 0;
}
var val=node[prop];
if(val){
_558+=val-0;
if(node==dojo.body()){
break;
}
}
node=node.parentNode;
}
return _558;
};
dojo.html.setStyleAttributes=function(node,_55b){
node=dojo.byId(node);
var _55c=_55b.replace(/(;)?\s*$/,"").split(";");
for(var i=0;i<_55c.length;i++){
var _55e=_55c[i].split(":");
var name=_55e[0].replace(/\s*$/,"").replace(/^\s*/,"").toLowerCase();
var _560=_55e[1].replace(/\s*$/,"").replace(/^\s*/,"");
switch(name){
case "opacity":
dojo.html.setOpacity(node,_560);
break;
case "content-height":
dojo.html.setContentBox(node,{height:_560});
break;
case "content-width":
dojo.html.setContentBox(node,{width:_560});
break;
case "outer-height":
dojo.html.setMarginBox(node,{height:_560});
break;
case "outer-width":
dojo.html.setMarginBox(node,{width:_560});
break;
default:
node.style[dojo.html.toCamelCase(name)]=_560;
}
}
};
dojo.html.boxSizing={MARGIN_BOX:"margin-box",BORDER_BOX:"border-box",PADDING_BOX:"padding-box",CONTENT_BOX:"content-box"};
dojo.html.getAbsolutePosition=dojo.html.abs=function(node,_562,_563){
node=dojo.byId(node,node.ownerDocument);
var ret={x:0,y:0};
var bs=dojo.html.boxSizing;
if(!_563){
_563=bs.CONTENT_BOX;
}
var _566=2;
var _567;
switch(_563){
case bs.MARGIN_BOX:
_567=3;
break;
case bs.BORDER_BOX:
_567=2;
break;
case bs.PADDING_BOX:
default:
_567=1;
break;
case bs.CONTENT_BOX:
_567=0;
break;
}
var h=dojo.render.html;
var db=document["body"]||document["documentElement"];
if(h.ie){
with(node.getBoundingClientRect()){
ret.x=left-2;
ret.y=top-2;
}
}else{
if(document.getBoxObjectFor){
_566=1;
try{
var bo=document.getBoxObjectFor(node);
ret.x=bo.x-dojo.html.sumAncestorProperties(node,"scrollLeft");
ret.y=bo.y-dojo.html.sumAncestorProperties(node,"scrollTop");
}
catch(e){
}
}else{
if(node["offsetParent"]){
var _56b;
if((h.safari)&&(node.style.getPropertyValue("position")=="absolute")&&(node.parentNode==db)){
_56b=db;
}else{
_56b=db.parentNode;
}
if(node.parentNode!=db){
var nd=node;
if(dojo.render.html.opera){
nd=db;
}
ret.x-=dojo.html.sumAncestorProperties(nd,"scrollLeft");
ret.y-=dojo.html.sumAncestorProperties(nd,"scrollTop");
}
var _56d=node;
do{
var n=_56d["offsetLeft"];
if(!h.opera||n>0){
ret.x+=isNaN(n)?0:n;
}
var m=_56d["offsetTop"];
ret.y+=isNaN(m)?0:m;
_56d=_56d.offsetParent;
}while((_56d!=_56b)&&(_56d!=null));
}else{
if(node["x"]&&node["y"]){
ret.x+=isNaN(node.x)?0:node.x;
ret.y+=isNaN(node.y)?0:node.y;
}
}
}
}
if(_562){
var _570=dojo.html.getScroll();
ret.y+=_570.top;
ret.x+=_570.left;
}
var _571=[dojo.html.getPaddingExtent,dojo.html.getBorderExtent,dojo.html.getMarginExtent];
if(_566>_567){
for(var i=_567;i<_566;++i){
ret.y+=_571[i](node,"top");
ret.x+=_571[i](node,"left");
}
}else{
if(_566<_567){
for(var i=_567;i>_566;--i){
ret.y-=_571[i-1](node,"top");
ret.x-=_571[i-1](node,"left");
}
}
}
ret.top=ret.y;
ret.left=ret.x;
return ret;
};
dojo.html.isPositionAbsolute=function(node){
return (dojo.html.getComputedStyle(node,"position")=="absolute");
};
dojo.html._sumPixelValues=function(node,_575,_576){
var _577=0;
for(var x=0;x<_575.length;x++){
_577+=dojo.html.getPixelValue(node,_575[x],_576);
}
return _577;
};
dojo.html.getMargin=function(node){
return {width:dojo.html._sumPixelValues(node,["margin-left","margin-right"],(dojo.html.getComputedStyle(node,"position")=="absolute")),height:dojo.html._sumPixelValues(node,["margin-top","margin-bottom"],(dojo.html.getComputedStyle(node,"position")=="absolute"))};
};
dojo.html.getBorder=function(node){
return {width:dojo.html.getBorderExtent(node,"left")+dojo.html.getBorderExtent(node,"right"),height:dojo.html.getBorderExtent(node,"top")+dojo.html.getBorderExtent(node,"bottom")};
};
dojo.html.getBorderExtent=function(node,side){
return (dojo.html.getStyle(node,"border-"+side+"-style")=="none"?0:dojo.html.getPixelValue(node,"border-"+side+"-width"));
};
dojo.html.getMarginExtent=function(node,side){
return dojo.html._sumPixelValues(node,["margin-"+side],dojo.html.isPositionAbsolute(node));
};
dojo.html.getPaddingExtent=function(node,side){
return dojo.html._sumPixelValues(node,["padding-"+side],true);
};
dojo.html.getPadding=function(node){
return {width:dojo.html._sumPixelValues(node,["padding-left","padding-right"],true),height:dojo.html._sumPixelValues(node,["padding-top","padding-bottom"],true)};
};
dojo.html.getPadBorder=function(node){
var pad=dojo.html.getPadding(node);
var _584=dojo.html.getBorder(node);
return {width:pad.width+_584.width,height:pad.height+_584.height};
};
dojo.html.getBoxSizing=function(node){
var h=dojo.render.html;
var bs=dojo.html.boxSizing;
if(((h.ie)||(h.opera))&&node.nodeName!="IMG"){
var cm=document["compatMode"];
if((cm=="BackCompat")||(cm=="QuirksMode")){
return bs.BORDER_BOX;
}else{
return bs.CONTENT_BOX;
}
}else{
if(arguments.length==0){
node=document.documentElement;
}
var _589=dojo.html.getStyle(node,"-moz-box-sizing");
if(!_589){
_589=dojo.html.getStyle(node,"box-sizing");
}
return (_589?_589:bs.CONTENT_BOX);
}
};
dojo.html.isBorderBox=function(node){
return (dojo.html.getBoxSizing(node)==dojo.html.boxSizing.BORDER_BOX);
};
dojo.html.getBorderBox=function(node){
node=dojo.byId(node);
return {width:node.offsetWidth,height:node.offsetHeight};
};
dojo.html.getPaddingBox=function(node){
var box=dojo.html.getBorderBox(node);
var _58e=dojo.html.getBorder(node);
return {width:box.width-_58e.width,height:box.height-_58e.height};
};
dojo.html.getContentBox=function(node){
node=dojo.byId(node);
var _590=dojo.html.getPadBorder(node);
return {width:node.offsetWidth-_590.width,height:node.offsetHeight-_590.height};
};
dojo.html.setContentBox=function(node,args){
node=dojo.byId(node);
var _593=0;
var _594=0;
var isbb=dojo.html.isBorderBox(node);
var _596=(isbb?dojo.html.getPadBorder(node):{width:0,height:0});
var ret={};
if(typeof args.width!="undefined"){
_593=args.width+_596.width;
ret.width=dojo.html.setPositivePixelValue(node,"width",_593);
}
if(typeof args.height!="undefined"){
_594=args.height+_596.height;
ret.height=dojo.html.setPositivePixelValue(node,"height",_594);
}
return ret;
};
dojo.html.getMarginBox=function(node){
var _599=dojo.html.getBorderBox(node);
var _59a=dojo.html.getMargin(node);
return {width:_599.width+_59a.width,height:_599.height+_59a.height};
};
dojo.html.setMarginBox=function(node,args){
node=dojo.byId(node);
var _59d=0;
var _59e=0;
var isbb=dojo.html.isBorderBox(node);
var _5a0=(!isbb?dojo.html.getPadBorder(node):{width:0,height:0});
var _5a1=dojo.html.getMargin(node);
var ret={};
if(typeof args.width!="undefined"){
_59d=args.width-_5a0.width;
_59d-=_5a1.width;
ret.width=dojo.html.setPositivePixelValue(node,"width",_59d);
}
if(typeof args.height!="undefined"){
_59e=args.height-_5a0.height;
_59e-=_5a1.height;
ret.height=dojo.html.setPositivePixelValue(node,"height",_59e);
}
return ret;
};
dojo.html.getElementBox=function(node,type){
var bs=dojo.html.boxSizing;
switch(type){
case bs.MARGIN_BOX:
return dojo.html.getMarginBox(node);
case bs.BORDER_BOX:
return dojo.html.getBorderBox(node);
case bs.PADDING_BOX:
return dojo.html.getPaddingBox(node);
case bs.CONTENT_BOX:
default:
return dojo.html.getContentBox(node);
}
};
dojo.html.toCoordinateObject=dojo.html.toCoordinateArray=function(_5a6,_5a7,_5a8){
if(_5a6 instanceof Array||typeof _5a6=="array"){
dojo.deprecated("dojo.html.toCoordinateArray","use dojo.html.toCoordinateObject({left: , top: , width: , height: }) instead","0.5");
while(_5a6.length<4){
_5a6.push(0);
}
while(_5a6.length>4){
_5a6.pop();
}
var ret={left:_5a6[0],top:_5a6[1],width:_5a6[2],height:_5a6[3]};
}else{
if(!_5a6.nodeType&&!(_5a6 instanceof String||typeof _5a6=="string")&&("width" in _5a6||"height" in _5a6||"left" in _5a6||"x" in _5a6||"top" in _5a6||"y" in _5a6)){
var ret={left:_5a6.left||_5a6.x||0,top:_5a6.top||_5a6.y||0,width:_5a6.width||0,height:_5a6.height||0};
}else{
var node=dojo.byId(_5a6);
var pos=dojo.html.abs(node,_5a7,_5a8);
var _5ac=dojo.html.getMarginBox(node);
var ret={left:pos.left,top:pos.top,width:_5ac.width,height:_5ac.height};
}
}
ret.x=ret.left;
ret.y=ret.top;
return ret;
};
dojo.html.setMarginBoxWidth=dojo.html.setOuterWidth=function(node,_5ae){
return dojo.html._callDeprecated("setMarginBoxWidth","setMarginBox",arguments,"width");
};
dojo.html.setMarginBoxHeight=dojo.html.setOuterHeight=function(){
return dojo.html._callDeprecated("setMarginBoxHeight","setMarginBox",arguments,"height");
};
dojo.html.getMarginBoxWidth=dojo.html.getOuterWidth=function(){
return dojo.html._callDeprecated("getMarginBoxWidth","getMarginBox",arguments,null,"width");
};
dojo.html.getMarginBoxHeight=dojo.html.getOuterHeight=function(){
return dojo.html._callDeprecated("getMarginBoxHeight","getMarginBox",arguments,null,"height");
};
dojo.html.getTotalOffset=function(node,type,_5b1){
return dojo.html._callDeprecated("getTotalOffset","getAbsolutePosition",arguments,null,type);
};
dojo.html.getAbsoluteX=function(node,_5b3){
return dojo.html._callDeprecated("getAbsoluteX","getAbsolutePosition",arguments,null,"x");
};
dojo.html.getAbsoluteY=function(node,_5b5){
return dojo.html._callDeprecated("getAbsoluteY","getAbsolutePosition",arguments,null,"y");
};
dojo.html.totalOffsetLeft=function(node,_5b7){
return dojo.html._callDeprecated("totalOffsetLeft","getAbsolutePosition",arguments,null,"left");
};
dojo.html.totalOffsetTop=function(node,_5b9){
return dojo.html._callDeprecated("totalOffsetTop","getAbsolutePosition",arguments,null,"top");
};
dojo.html.getMarginWidth=function(node){
return dojo.html._callDeprecated("getMarginWidth","getMargin",arguments,null,"width");
};
dojo.html.getMarginHeight=function(node){
return dojo.html._callDeprecated("getMarginHeight","getMargin",arguments,null,"height");
};
dojo.html.getBorderWidth=function(node){
return dojo.html._callDeprecated("getBorderWidth","getBorder",arguments,null,"width");
};
dojo.html.getBorderHeight=function(node){
return dojo.html._callDeprecated("getBorderHeight","getBorder",arguments,null,"height");
};
dojo.html.getPaddingWidth=function(node){
return dojo.html._callDeprecated("getPaddingWidth","getPadding",arguments,null,"width");
};
dojo.html.getPaddingHeight=function(node){
return dojo.html._callDeprecated("getPaddingHeight","getPadding",arguments,null,"height");
};
dojo.html.getPadBorderWidth=function(node){
return dojo.html._callDeprecated("getPadBorderWidth","getPadBorder",arguments,null,"width");
};
dojo.html.getPadBorderHeight=function(node){
return dojo.html._callDeprecated("getPadBorderHeight","getPadBorder",arguments,null,"height");
};
dojo.html.getBorderBoxWidth=dojo.html.getInnerWidth=function(){
return dojo.html._callDeprecated("getBorderBoxWidth","getBorderBox",arguments,null,"width");
};
dojo.html.getBorderBoxHeight=dojo.html.getInnerHeight=function(){
return dojo.html._callDeprecated("getBorderBoxHeight","getBorderBox",arguments,null,"height");
};
dojo.html.getContentBoxWidth=dojo.html.getContentWidth=function(){
return dojo.html._callDeprecated("getContentBoxWidth","getContentBox",arguments,null,"width");
};
dojo.html.getContentBoxHeight=dojo.html.getContentHeight=function(){
return dojo.html._callDeprecated("getContentBoxHeight","getContentBox",arguments,null,"height");
};
dojo.html.setContentBoxWidth=dojo.html.setContentWidth=function(node,_5c3){
return dojo.html._callDeprecated("setContentBoxWidth","setContentBox",arguments,"width");
};
dojo.html.setContentBoxHeight=dojo.html.setContentHeight=function(node,_5c5){
return dojo.html._callDeprecated("setContentBoxHeight","setContentBox",arguments,"height");
};
dojo.provide("dojo.html.util");
dojo.html.getElementWindow=function(_5c6){
return dojo.html.getDocumentWindow(_5c6.ownerDocument);
};
dojo.html.getDocumentWindow=function(doc){
if(dojo.render.html.safari&&!doc._parentWindow){
var fix=function(win){
win.document._parentWindow=win;
for(var i=0;i<win.frames.length;i++){
fix(win.frames[i]);
}
};
fix(window.top);
}
if(dojo.render.html.ie&&window!==document.parentWindow&&!doc._parentWindow){
doc.parentWindow.execScript("document._parentWindow = window;","Javascript");
var win=doc._parentWindow;
doc._parentWindow=null;
return win;
}
return doc._parentWindow||doc.parentWindow||doc.defaultView;
};
dojo.html.gravity=function(node,e){
node=dojo.byId(node);
var _5ce=dojo.html.getCursorPosition(e);
with(dojo.html){
var _5cf=getAbsolutePosition(node,true);
var bb=getBorderBox(node);
var _5d1=_5cf.x+(bb.width/2);
var _5d2=_5cf.y+(bb.height/2);
}
with(dojo.html.gravity){
return ((_5ce.x<_5d1?WEST:EAST)|(_5ce.y<_5d2?NORTH:SOUTH));
}
};
dojo.html.gravity.NORTH=1;
dojo.html.gravity.SOUTH=1<<1;
dojo.html.gravity.EAST=1<<2;
dojo.html.gravity.WEST=1<<3;
dojo.html.overElement=function(_5d3,e){
_5d3=dojo.byId(_5d3);
var _5d5=dojo.html.getCursorPosition(e);
var bb=dojo.html.getBorderBox(_5d3);
var _5d7=dojo.html.getAbsolutePosition(_5d3,true,dojo.html.boxSizing.BORDER_BOX);
var top=_5d7.y;
var _5d9=top+bb.height;
var left=_5d7.x;
var _5db=left+bb.width;
return (_5d5.x>=left&&_5d5.x<=_5db&&_5d5.y>=top&&_5d5.y<=_5d9);
};
dojo.html.renderedTextContent=function(node){
node=dojo.byId(node);
var _5dd="";
if(node==null){
return _5dd;
}
for(var i=0;i<node.childNodes.length;i++){
switch(node.childNodes[i].nodeType){
case 1:
case 5:
var _5df="unknown";
try{
_5df=dojo.html.getStyle(node.childNodes[i],"display");
}
catch(E){
}
switch(_5df){
case "block":
case "list-item":
case "run-in":
case "table":
case "table-row-group":
case "table-header-group":
case "table-footer-group":
case "table-row":
case "table-column-group":
case "table-column":
case "table-cell":
case "table-caption":
_5dd+="\n";
_5dd+=dojo.html.renderedTextContent(node.childNodes[i]);
_5dd+="\n";
break;
case "none":
break;
default:
if(node.childNodes[i].tagName&&node.childNodes[i].tagName.toLowerCase()=="br"){
_5dd+="\n";
}else{
_5dd+=dojo.html.renderedTextContent(node.childNodes[i]);
}
break;
}
break;
case 3:
case 2:
case 4:
var text=node.childNodes[i].nodeValue;
var _5e1="unknown";
try{
_5e1=dojo.html.getStyle(node,"text-transform");
}
catch(E){
}
switch(_5e1){
case "capitalize":
var _5e2=text.split(" ");
for(var i=0;i<_5e2.length;i++){
_5e2[i]=_5e2[i].charAt(0).toUpperCase()+_5e2[i].substring(1);
}
text=_5e2.join(" ");
break;
case "uppercase":
text=text.toUpperCase();
break;
case "lowercase":
text=text.toLowerCase();
break;
default:
break;
}
switch(_5e1){
case "nowrap":
break;
case "pre-wrap":
break;
case "pre-line":
break;
case "pre":
break;
default:
text=text.replace(/\s+/," ");
if(/\s$/.test(_5dd)){
text.replace(/^\s/,"");
}
break;
}
_5dd+=text;
break;
default:
break;
}
}
return _5dd;
};
dojo.html.createNodesFromText=function(txt,trim){
if(trim){
txt=txt.replace(/^\s+|\s+$/g,"");
}
var tn=dojo.doc().createElement("div");
tn.style.visibility="hidden";
dojo.body().appendChild(tn);
var _5e6="none";
if((/^<t[dh][\s\r\n>]/i).test(txt.replace(/^\s+/))){
txt="<table><tbody><tr>"+txt+"</tr></tbody></table>";
_5e6="cell";
}else{
if((/^<tr[\s\r\n>]/i).test(txt.replace(/^\s+/))){
txt="<table><tbody>"+txt+"</tbody></table>";
_5e6="row";
}else{
if((/^<(thead|tbody|tfoot)[\s\r\n>]/i).test(txt.replace(/^\s+/))){
txt="<table>"+txt+"</table>";
_5e6="section";
}
}
}
tn.innerHTML=txt;
if(tn["normalize"]){
tn.normalize();
}
var _5e7=null;
switch(_5e6){
case "cell":
_5e7=tn.getElementsByTagName("tr")[0];
break;
case "row":
_5e7=tn.getElementsByTagName("tbody")[0];
break;
case "section":
_5e7=tn.getElementsByTagName("table")[0];
break;
default:
_5e7=tn;
break;
}
var _5e8=[];
for(var x=0;x<_5e7.childNodes.length;x++){
_5e8.push(_5e7.childNodes[x].cloneNode(true));
}
tn.style.display="none";
dojo.html.destroyNode(tn);
return _5e8;
};
dojo.html.placeOnScreen=function(node,_5eb,_5ec,_5ed,_5ee,_5ef,_5f0){
if(_5eb instanceof Array||typeof _5eb=="array"){
_5f0=_5ef;
_5ef=_5ee;
_5ee=_5ed;
_5ed=_5ec;
_5ec=_5eb[1];
_5eb=_5eb[0];
}
if(_5ef instanceof String||typeof _5ef=="string"){
_5ef=_5ef.split(",");
}
if(!isNaN(_5ed)){
_5ed=[Number(_5ed),Number(_5ed)];
}else{
if(!(_5ed instanceof Array||typeof _5ed=="array")){
_5ed=[0,0];
}
}
var _5f1=dojo.html.getScroll().offset;
var view=dojo.html.getViewport();
node=dojo.byId(node);
var _5f3=node.style.display;
node.style.display="";
var bb=dojo.html.getBorderBox(node);
var w=bb.width;
var h=bb.height;
node.style.display=_5f3;
if(!(_5ef instanceof Array||typeof _5ef=="array")){
_5ef=["TL"];
}
var _5f7,_5f8,_5f9=Infinity,_5fa;
for(var _5fb=0;_5fb<_5ef.length;++_5fb){
var _5fc=_5ef[_5fb];
var _5fd=true;
var tryX=_5eb-(_5fc.charAt(1)=="L"?0:w)+_5ed[0]*(_5fc.charAt(1)=="L"?1:-1);
var tryY=_5ec-(_5fc.charAt(0)=="T"?0:h)+_5ed[1]*(_5fc.charAt(0)=="T"?1:-1);
if(_5ee){
tryX-=_5f1.x;
tryY-=_5f1.y;
}
if(tryX<0){
tryX=0;
_5fd=false;
}
if(tryY<0){
tryY=0;
_5fd=false;
}
var x=tryX+w;
if(x>view.width){
x=view.width-w;
_5fd=false;
}else{
x=tryX;
}
x=Math.max(_5ed[0],x)+_5f1.x;
var y=tryY+h;
if(y>view.height){
y=view.height-h;
_5fd=false;
}else{
y=tryY;
}
y=Math.max(_5ed[1],y)+_5f1.y;
if(_5fd){
_5f7=x;
_5f8=y;
_5f9=0;
_5fa=_5fc;
break;
}else{
var dist=Math.pow(x-tryX-_5f1.x,2)+Math.pow(y-tryY-_5f1.y,2);
if(_5f9>dist){
_5f9=dist;
_5f7=x;
_5f8=y;
_5fa=_5fc;
}
}
}
if(!_5f0){
node.style.left=_5f7+"px";
node.style.top=_5f8+"px";
}
return {left:_5f7,top:_5f8,x:_5f7,y:_5f8,dist:_5f9,corner:_5fa};
};
dojo.html.placeOnScreenPoint=function(node,_604,_605,_606,_607){
dojo.deprecated("dojo.html.placeOnScreenPoint","use dojo.html.placeOnScreen() instead","0.5");
return dojo.html.placeOnScreen(node,_604,_605,_606,_607,["TL","TR","BL","BR"]);
};
dojo.html.placeOnScreenAroundElement=function(node,_609,_60a,_60b,_60c,_60d){
var best,_60f=Infinity;
_609=dojo.byId(_609);
var _610=_609.style.display;
_609.style.display="";
var mb=dojo.html.getElementBox(_609,_60b);
var _612=mb.width;
var _613=mb.height;
var _614=dojo.html.getAbsolutePosition(_609,true,_60b);
_609.style.display=_610;
for(var _615 in _60c){
var pos,_617,_618;
var _619=_60c[_615];
_617=_614.x+(_615.charAt(1)=="L"?0:_612);
_618=_614.y+(_615.charAt(0)=="T"?0:_613);
pos=dojo.html.placeOnScreen(node,_617,_618,_60a,true,_619,true);
if(pos.dist==0){
best=pos;
break;
}else{
if(_60f>pos.dist){
_60f=pos.dist;
best=pos;
}
}
}
if(!_60d){
node.style.left=best.left+"px";
node.style.top=best.top+"px";
}
return best;
};
dojo.html.scrollIntoView=function(node){
if(!node){
return;
}
if(dojo.render.html.ie){
if(dojo.html.getBorderBox(node.parentNode).height<=node.parentNode.scrollHeight){
node.scrollIntoView(false);
}
}else{
if(dojo.render.html.mozilla){
node.scrollIntoView(false);
}else{
var _61b=node.parentNode;
var _61c=_61b.scrollTop+dojo.html.getBorderBox(_61b).height;
var _61d=node.offsetTop+dojo.html.getMarginBox(node).height;
if(_61c<_61d){
_61b.scrollTop+=(_61d-_61c);
}else{
if(_61b.scrollTop>node.offsetTop){
_61b.scrollTop-=(_61b.scrollTop-node.offsetTop);
}
}
}
}
};
dojo.provide("dojo.gfx.color");
dojo.gfx.color.Color=function(r,g,b,a){
if(dojo.lang.isArray(r)){
this.r=r[0];
this.g=r[1];
this.b=r[2];
this.a=r[3]||1;
}else{
if(dojo.lang.isString(r)){
var rgb=dojo.gfx.color.extractRGB(r);
this.r=rgb[0];
this.g=rgb[1];
this.b=rgb[2];
this.a=g||1;
}else{
if(r instanceof dojo.gfx.color.Color){
this.r=r.r;
this.b=r.b;
this.g=r.g;
this.a=r.a;
}else{
this.r=r;
this.g=g;
this.b=b;
this.a=a;
}
}
}
};
dojo.gfx.color.Color.fromArray=function(arr){
return new dojo.gfx.color.Color(arr[0],arr[1],arr[2],arr[3]);
};
dojo.extend(dojo.gfx.color.Color,{toRgb:function(_624){
if(_624){
return this.toRgba();
}else{
return [this.r,this.g,this.b];
}
},toRgba:function(){
return [this.r,this.g,this.b,this.a];
},toHex:function(){
return dojo.gfx.color.rgb2hex(this.toRgb());
},toCss:function(){
return "rgb("+this.toRgb().join()+")";
},toString:function(){
return this.toHex();
},blend:function(_625,_626){
var rgb=null;
if(dojo.lang.isArray(_625)){
rgb=_625;
}else{
if(_625 instanceof dojo.gfx.color.Color){
rgb=_625.toRgb();
}else{
rgb=new dojo.gfx.color.Color(_625).toRgb();
}
}
return dojo.gfx.color.blend(this.toRgb(),rgb,_626);
}});
dojo.gfx.color.named={white:[255,255,255],black:[0,0,0],red:[255,0,0],green:[0,255,0],lime:[0,255,0],blue:[0,0,255],navy:[0,0,128],gray:[128,128,128],silver:[192,192,192]};
dojo.gfx.color.blend=function(a,b,_62a){
if(typeof a=="string"){
return dojo.gfx.color.blendHex(a,b,_62a);
}
if(!_62a){
_62a=0;
}
_62a=Math.min(Math.max(-1,_62a),1);
_62a=((_62a+1)/2);
var c=[];
for(var x=0;x<3;x++){
c[x]=parseInt(b[x]+((a[x]-b[x])*_62a));
}
return c;
};
dojo.gfx.color.blendHex=function(a,b,_62f){
return dojo.gfx.color.rgb2hex(dojo.gfx.color.blend(dojo.gfx.color.hex2rgb(a),dojo.gfx.color.hex2rgb(b),_62f));
};
dojo.gfx.color.extractRGB=function(_630){
var hex="0123456789abcdef";
_630=_630.toLowerCase();
if(_630.indexOf("rgb")==0){
var _632=_630.match(/rgba*\((\d+), *(\d+), *(\d+)/i);
var ret=_632.splice(1,3);
return ret;
}else{
var _634=dojo.gfx.color.hex2rgb(_630);
if(_634){
return _634;
}else{
return dojo.gfx.color.named[_630]||[255,255,255];
}
}
};
dojo.gfx.color.hex2rgb=function(hex){
var _636="0123456789ABCDEF";
var rgb=new Array(3);
if(hex.indexOf("#")==0){
hex=hex.substring(1);
}
hex=hex.toUpperCase();
if(hex.replace(new RegExp("["+_636+"]","g"),"")!=""){
return null;
}
if(hex.length==3){
rgb[0]=hex.charAt(0)+hex.charAt(0);
rgb[1]=hex.charAt(1)+hex.charAt(1);
rgb[2]=hex.charAt(2)+hex.charAt(2);
}else{
rgb[0]=hex.substring(0,2);
rgb[1]=hex.substring(2,4);
rgb[2]=hex.substring(4);
}
for(var i=0;i<rgb.length;i++){
rgb[i]=_636.indexOf(rgb[i].charAt(0))*16+_636.indexOf(rgb[i].charAt(1));
}
return rgb;
};
dojo.gfx.color.rgb2hex=function(r,g,b){
if(dojo.lang.isArray(r)){
g=r[1]||0;
b=r[2]||0;
r=r[0]||0;
}
var ret=dojo.lang.map([r,g,b],function(x){
x=new Number(x);
var s=x.toString(16);
while(s.length<2){
s="0"+s;
}
return s;
});
ret.unshift("#");
return ret.join("");
};
dojo.provide("dojo.lfx.Animation");
dojo.lfx.Line=function(_63f,end){
this.start=_63f;
this.end=end;
if(dojo.lang.isArray(_63f)){
var diff=[];
dojo.lang.forEach(this.start,function(s,i){
diff[i]=this.end[i]-s;
},this);
this.getValue=function(n){
var res=[];
dojo.lang.forEach(this.start,function(s,i){
res[i]=(diff[i]*n)+s;
},this);
return res;
};
}else{
var diff=end-_63f;
this.getValue=function(n){
return (diff*n)+this.start;
};
}
};
dojo.lfx.easeDefault=function(n){
if(dojo.render.html.khtml){
return (parseFloat("0.5")+((Math.sin((n+parseFloat("1.5"))*Math.PI))/2));
}else{
return (0.5+((Math.sin((n+1.5)*Math.PI))/2));
}
};
dojo.lfx.easeIn=function(n){
return Math.pow(n,3);
};
dojo.lfx.easeOut=function(n){
return (1-Math.pow(1-n,3));
};
dojo.lfx.easeInOut=function(n){
return ((3*Math.pow(n,2))-(2*Math.pow(n,3)));
};
dojo.lfx.IAnimation=function(){
};
dojo.lang.extend(dojo.lfx.IAnimation,{curve:null,duration:1000,easing:null,repeatCount:0,rate:25,handler:null,beforeBegin:null,onBegin:null,onAnimate:null,onEnd:null,onPlay:null,onPause:null,onStop:null,play:null,pause:null,stop:null,connect:function(evt,_64e,_64f){
if(!_64f){
_64f=_64e;
_64e=this;
}
_64f=dojo.lang.hitch(_64e,_64f);
var _650=this[evt]||function(){
};
this[evt]=function(){
var ret=_650.apply(this,arguments);
_64f.apply(this,arguments);
return ret;
};
return this;
},fire:function(evt,args){
if(this[evt]){
this[evt].apply(this,(args||[]));
}
return this;
},repeat:function(_654){
this.repeatCount=_654;
return this;
},_active:false,_paused:false});
dojo.lfx.Animation=function(_655,_656,_657,_658,_659,rate){
dojo.lfx.IAnimation.call(this);
if(dojo.lang.isNumber(_655)||(!_655&&_656.getValue)){
rate=_659;
_659=_658;
_658=_657;
_657=_656;
_656=_655;
_655=null;
}else{
if(_655.getValue||dojo.lang.isArray(_655)){
rate=_658;
_659=_657;
_658=_656;
_657=_655;
_656=null;
_655=null;
}
}
if(dojo.lang.isArray(_657)){
this.curve=new dojo.lfx.Line(_657[0],_657[1]);
}else{
this.curve=_657;
}
if(_656!=null&&_656>0){
this.duration=_656;
}
if(_659){
this.repeatCount=_659;
}
if(rate){
this.rate=rate;
}
if(_655){
dojo.lang.forEach(["handler","beforeBegin","onBegin","onEnd","onPlay","onStop","onAnimate"],function(item){
if(_655[item]){
this.connect(item,_655[item]);
}
},this);
}
if(_658&&dojo.lang.isFunction(_658)){
this.easing=_658;
}
};
dojo.inherits(dojo.lfx.Animation,dojo.lfx.IAnimation);
dojo.lang.extend(dojo.lfx.Animation,{_startTime:null,_endTime:null,_timer:null,_percent:0,_startRepeatCount:0,play:function(_65c,_65d){
if(_65d){
clearTimeout(this._timer);
this._active=false;
this._paused=false;
this._percent=0;
}else{
if(this._active&&!this._paused){
return this;
}
}
this.fire("handler",["beforeBegin"]);
this.fire("beforeBegin");
if(_65c>0){
setTimeout(dojo.lang.hitch(this,function(){
this.play(null,_65d);
}),_65c);
return this;
}
this._startTime=new Date().valueOf();
if(this._paused){
this._startTime-=(this.duration*this._percent/100);
}
this._endTime=this._startTime+this.duration;
this._active=true;
this._paused=false;
var step=this._percent/100;
var _65f=this.curve.getValue(step);
if(this._percent==0){
if(!this._startRepeatCount){
this._startRepeatCount=this.repeatCount;
}
this.fire("handler",["begin",_65f]);
this.fire("onBegin",[_65f]);
}
this.fire("handler",["play",_65f]);
this.fire("onPlay",[_65f]);
this._cycle();
return this;
},pause:function(){
clearTimeout(this._timer);
if(!this._active){
return this;
}
this._paused=true;
var _660=this.curve.getValue(this._percent/100);
this.fire("handler",["pause",_660]);
this.fire("onPause",[_660]);
return this;
},gotoPercent:function(pct,_662){
clearTimeout(this._timer);
this._active=true;
this._paused=true;
this._percent=pct;
if(_662){
this.play();
}
return this;
},stop:function(_663){
clearTimeout(this._timer);
var step=this._percent/100;
if(_663){
step=1;
}
var _665=this.curve.getValue(step);
this.fire("handler",["stop",_665]);
this.fire("onStop",[_665]);
this._active=false;
this._paused=false;
return this;
},status:function(){
if(this._active){
return this._paused?"paused":"playing";
}else{
return "stopped";
}
return this;
},_cycle:function(){
clearTimeout(this._timer);
if(this._active){
var curr=new Date().valueOf();
var step=(curr-this._startTime)/(this._endTime-this._startTime);
if(step>=1){
step=1;
this._percent=100;
}else{
this._percent=step*100;
}
if((this.easing)&&(dojo.lang.isFunction(this.easing))){
step=this.easing(step);
}
var _668=this.curve.getValue(step);
this.fire("handler",["animate",_668]);
this.fire("onAnimate",[_668]);
if(step<1){
this._timer=setTimeout(dojo.lang.hitch(this,"_cycle"),this.rate);
}else{
this._active=false;
this.fire("handler",["end"]);
this.fire("onEnd");
if(this.repeatCount>0){
this.repeatCount--;
this.play(null,true);
}else{
if(this.repeatCount==-1){
this.play(null,true);
}else{
if(this._startRepeatCount){
this.repeatCount=this._startRepeatCount;
this._startRepeatCount=0;
}
}
}
}
}
return this;
}});
dojo.lfx.Combine=function(_669){
dojo.lfx.IAnimation.call(this);
this._anims=[];
this._animsEnded=0;
var _66a=arguments;
if(_66a.length==1&&(dojo.lang.isArray(_66a[0])||dojo.lang.isArrayLike(_66a[0]))){
_66a=_66a[0];
}
dojo.lang.forEach(_66a,function(anim){
this._anims.push(anim);
anim.connect("onEnd",dojo.lang.hitch(this,"_onAnimsEnded"));
},this);
};
dojo.inherits(dojo.lfx.Combine,dojo.lfx.IAnimation);
dojo.lang.extend(dojo.lfx.Combine,{_animsEnded:0,play:function(_66c,_66d){
if(!this._anims.length){
return this;
}
this.fire("beforeBegin");
if(_66c>0){
setTimeout(dojo.lang.hitch(this,function(){
this.play(null,_66d);
}),_66c);
return this;
}
if(_66d||this._anims[0].percent==0){
this.fire("onBegin");
}
this.fire("onPlay");
this._animsCall("play",null,_66d);
return this;
},pause:function(){
this.fire("onPause");
this._animsCall("pause");
return this;
},stop:function(_66e){
this.fire("onStop");
this._animsCall("stop",_66e);
return this;
},_onAnimsEnded:function(){
this._animsEnded++;
if(this._animsEnded>=this._anims.length){
this.fire("onEnd");
}
return this;
},_animsCall:function(_66f){
var args=[];
if(arguments.length>1){
for(var i=1;i<arguments.length;i++){
args.push(arguments[i]);
}
}
var _672=this;
dojo.lang.forEach(this._anims,function(anim){
anim[_66f](args);
},_672);
return this;
}});
dojo.lfx.Chain=function(_674){
dojo.lfx.IAnimation.call(this);
this._anims=[];
this._currAnim=-1;
var _675=arguments;
if(_675.length==1&&(dojo.lang.isArray(_675[0])||dojo.lang.isArrayLike(_675[0]))){
_675=_675[0];
}
var _676=this;
dojo.lang.forEach(_675,function(anim,i,_679){
this._anims.push(anim);
if(i<_679.length-1){
anim.connect("onEnd",dojo.lang.hitch(this,"_playNext"));
}else{
anim.connect("onEnd",dojo.lang.hitch(this,function(){
this.fire("onEnd");
}));
}
},this);
};
dojo.inherits(dojo.lfx.Chain,dojo.lfx.IAnimation);
dojo.lang.extend(dojo.lfx.Chain,{_currAnim:-1,play:function(_67a,_67b){
if(!this._anims.length){
return this;
}
if(_67b||!this._anims[this._currAnim]){
this._currAnim=0;
}
var _67c=this._anims[this._currAnim];
this.fire("beforeBegin");
if(_67a>0){
setTimeout(dojo.lang.hitch(this,function(){
this.play(null,_67b);
}),_67a);
return this;
}
if(_67c){
if(this._currAnim==0){
this.fire("handler",["begin",this._currAnim]);
this.fire("onBegin",[this._currAnim]);
}
this.fire("onPlay",[this._currAnim]);
_67c.play(null,_67b);
}
return this;
},pause:function(){
if(this._anims[this._currAnim]){
this._anims[this._currAnim].pause();
this.fire("onPause",[this._currAnim]);
}
return this;
},playPause:function(){
if(this._anims.length==0){
return this;
}
if(this._currAnim==-1){
this._currAnim=0;
}
var _67d=this._anims[this._currAnim];
if(_67d){
if(!_67d._active||_67d._paused){
this.play();
}else{
this.pause();
}
}
return this;
},stop:function(){
var _67e=this._anims[this._currAnim];
if(_67e){
_67e.stop();
this.fire("onStop",[this._currAnim]);
}
return _67e;
},_playNext:function(){
if(this._currAnim==-1||this._anims.length==0){
return this;
}
this._currAnim++;
if(this._anims[this._currAnim]){
this._anims[this._currAnim].play(null,true);
}
return this;
}});
dojo.lfx.combine=function(_67f){
var _680=arguments;
if(dojo.lang.isArray(arguments[0])){
_680=arguments[0];
}
if(_680.length==1){
return _680[0];
}
return new dojo.lfx.Combine(_680);
};
dojo.lfx.chain=function(_681){
var _682=arguments;
if(dojo.lang.isArray(arguments[0])){
_682=arguments[0];
}
if(_682.length==1){
return _682[0];
}
return new dojo.lfx.Chain(_682);
};
dojo.provide("dojo.html.color");
dojo.html.getBackgroundColor=function(node){
node=dojo.byId(node);
var _684;
do{
_684=dojo.html.getStyle(node,"background-color");
if(_684.toLowerCase()=="rgba(0, 0, 0, 0)"){
_684="transparent";
}
if(node==document.getElementsByTagName("body")[0]){
node=null;
break;
}
node=node.parentNode;
}while(node&&dojo.lang.inArray(["transparent",""],_684));
if(_684=="transparent"){
_684=[255,255,255,0];
}else{
_684=dojo.gfx.color.extractRGB(_684);
}
return _684;
};
dojo.provide("dojo.lfx.html");
dojo.lfx.html._byId=function(_685){
if(!_685){
return [];
}
if(dojo.lang.isArrayLike(_685)){
if(!_685.alreadyChecked){
var n=[];
dojo.lang.forEach(_685,function(node){
n.push(dojo.byId(node));
});
n.alreadyChecked=true;
return n;
}else{
return _685;
}
}else{
var n=[];
n.push(dojo.byId(_685));
n.alreadyChecked=true;
return n;
}
};
dojo.lfx.html.propertyAnimation=function(_688,_689,_68a,_68b,_68c){
_688=dojo.lfx.html._byId(_688);
var _68d={"propertyMap":_689,"nodes":_688,"duration":_68a,"easing":_68b||dojo.lfx.easeDefault};
var _68e=function(args){
if(args.nodes.length==1){
var pm=args.propertyMap;
if(!dojo.lang.isArray(args.propertyMap)){
var parr=[];
for(var _692 in pm){
pm[_692].property=_692;
parr.push(pm[_692]);
}
pm=args.propertyMap=parr;
}
dojo.lang.forEach(pm,function(prop){
if(dj_undef("start",prop)){
if(prop.property!="opacity"){
prop.start=parseInt(dojo.html.getComputedStyle(args.nodes[0],prop.property));
}else{
prop.start=dojo.html.getOpacity(args.nodes[0]);
}
}
});
}
};
var _694=function(_695){
var _696=[];
dojo.lang.forEach(_695,function(c){
_696.push(Math.round(c));
});
return _696;
};
var _698=function(n,_69a){
n=dojo.byId(n);
if(!n||!n.style){
return;
}
for(var s in _69a){
try{
if(s=="opacity"){
dojo.html.setOpacity(n,_69a[s]);
}else{
n.style[s]=_69a[s];
}
}
catch(e){
dojo.debug(e);
}
}
};
var _69c=function(_69d){
this._properties=_69d;
this.diffs=new Array(_69d.length);
dojo.lang.forEach(_69d,function(prop,i){
if(dojo.lang.isFunction(prop.start)){
prop.start=prop.start(prop,i);
}
if(dojo.lang.isFunction(prop.end)){
prop.end=prop.end(prop,i);
}
if(dojo.lang.isArray(prop.start)){
this.diffs[i]=null;
}else{
if(prop.start instanceof dojo.gfx.color.Color){
prop.startRgb=prop.start.toRgb();
prop.endRgb=prop.end.toRgb();
}else{
this.diffs[i]=prop.end-prop.start;
}
}
},this);
this.getValue=function(n){
var ret={};
dojo.lang.forEach(this._properties,function(prop,i){
var _6a4=null;
if(dojo.lang.isArray(prop.start)){
}else{
if(prop.start instanceof dojo.gfx.color.Color){
_6a4=(prop.units||"rgb")+"(";
for(var j=0;j<prop.startRgb.length;j++){
_6a4+=Math.round(((prop.endRgb[j]-prop.startRgb[j])*n)+prop.startRgb[j])+(j<prop.startRgb.length-1?",":"");
}
_6a4+=")";
}else{
_6a4=((this.diffs[i])*n)+prop.start+(prop.property!="opacity"?prop.units||"px":"");
}
}
ret[dojo.html.toCamelCase(prop.property)]=_6a4;
},this);
return ret;
};
};
var anim=new dojo.lfx.Animation({beforeBegin:function(){
_68e(_68d);
anim.curve=new _69c(_68d.propertyMap);
},onAnimate:function(_6a7){
dojo.lang.forEach(_68d.nodes,function(node){
_698(node,_6a7);
});
}},_68d.duration,null,_68d.easing);
if(_68c){
for(var x in _68c){
if(dojo.lang.isFunction(_68c[x])){
anim.connect(x,anim,_68c[x]);
}
}
}
return anim;
};
dojo.lfx.html._makeFadeable=function(_6aa){
var _6ab=function(node){
if(dojo.render.html.ie){
if((node.style.zoom.length==0)&&(dojo.html.getStyle(node,"zoom")=="normal")){
node.style.zoom="1";
}
if((node.style.width.length==0)&&(dojo.html.getStyle(node,"width")=="auto")){
node.style.width="auto";
}
}
};
if(dojo.lang.isArrayLike(_6aa)){
dojo.lang.forEach(_6aa,_6ab);
}else{
_6ab(_6aa);
}
};
dojo.lfx.html.fade=function(_6ad,_6ae,_6af,_6b0,_6b1){
_6ad=dojo.lfx.html._byId(_6ad);
var _6b2={property:"opacity"};
if(!dj_undef("start",_6ae)){
_6b2.start=_6ae.start;
}else{
_6b2.start=function(){
return dojo.html.getOpacity(_6ad[0]);
};
}
if(!dj_undef("end",_6ae)){
_6b2.end=_6ae.end;
}else{
dojo.raise("dojo.lfx.html.fade needs an end value");
}
var anim=dojo.lfx.propertyAnimation(_6ad,[_6b2],_6af,_6b0);
anim.connect("beforeBegin",function(){
dojo.lfx.html._makeFadeable(_6ad);
});
if(_6b1){
anim.connect("onEnd",function(){
_6b1(_6ad,anim);
});
}
return anim;
};
dojo.lfx.html.fadeIn=function(_6b4,_6b5,_6b6,_6b7){
return dojo.lfx.html.fade(_6b4,{end:1},_6b5,_6b6,_6b7);
};
dojo.lfx.html.fadeOut=function(_6b8,_6b9,_6ba,_6bb){
return dojo.lfx.html.fade(_6b8,{end:0},_6b9,_6ba,_6bb);
};
dojo.lfx.html.fadeShow=function(_6bc,_6bd,_6be,_6bf){
_6bc=dojo.lfx.html._byId(_6bc);
dojo.lang.forEach(_6bc,function(node){
dojo.html.setOpacity(node,0);
});
var anim=dojo.lfx.html.fadeIn(_6bc,_6bd,_6be,_6bf);
anim.connect("beforeBegin",function(){
if(dojo.lang.isArrayLike(_6bc)){
dojo.lang.forEach(_6bc,dojo.html.show);
}else{
dojo.html.show(_6bc);
}
});
return anim;
};
dojo.lfx.html.fadeHide=function(_6c2,_6c3,_6c4,_6c5){
var anim=dojo.lfx.html.fadeOut(_6c2,_6c3,_6c4,function(){
if(dojo.lang.isArrayLike(_6c2)){
dojo.lang.forEach(_6c2,dojo.html.hide);
}else{
dojo.html.hide(_6c2);
}
if(_6c5){
_6c5(_6c2,anim);
}
});
return anim;
};
dojo.lfx.html.wipeIn=function(_6c7,_6c8,_6c9,_6ca){
_6c7=dojo.lfx.html._byId(_6c7);
var _6cb=[];
dojo.lang.forEach(_6c7,function(node){
var _6cd={};
var _6ce,_6cf,_6d0;
with(node.style){
_6ce=top;
_6cf=left;
_6d0=position;
top="-9999px";
left="-9999px";
position="absolute";
display="";
}
var _6d1=dojo.html.getBorderBox(node).height;
with(node.style){
top=_6ce;
left=_6cf;
position=_6d0;
display="none";
}
var anim=dojo.lfx.propertyAnimation(node,{"height":{start:1,end:function(){
return _6d1;
}}},_6c8,_6c9);
anim.connect("beforeBegin",function(){
_6cd.overflow=node.style.overflow;
_6cd.height=node.style.height;
with(node.style){
overflow="hidden";
_6d1="1px";
}
dojo.html.show(node);
});
anim.connect("onEnd",function(){
with(node.style){
overflow=_6cd.overflow;
_6d1=_6cd.height;
}
if(_6ca){
_6ca(node,anim);
}
});
_6cb.push(anim);
});
return dojo.lfx.combine(_6cb);
};
dojo.lfx.html.wipeOut=function(_6d3,_6d4,_6d5,_6d6){
_6d3=dojo.lfx.html._byId(_6d3);
var _6d7=[];
dojo.lang.forEach(_6d3,function(node){
var _6d9={};
var anim=dojo.lfx.propertyAnimation(node,{"height":{start:function(){
return dojo.html.getContentBox(node).height;
},end:1}},_6d4,_6d5,{"beforeBegin":function(){
_6d9.overflow=node.style.overflow;
_6d9.height=node.style.height;
with(node.style){
overflow="hidden";
}
dojo.html.show(node);
},"onEnd":function(){
dojo.html.hide(node);
with(node.style){
overflow=_6d9.overflow;
height=_6d9.height;
}
if(_6d6){
_6d6(node,anim);
}
}});
_6d7.push(anim);
});
return dojo.lfx.combine(_6d7);
};
dojo.lfx.html.slideTo=function(_6db,_6dc,_6dd,_6de,_6df){
_6db=dojo.lfx.html._byId(_6db);
var _6e0=[];
var _6e1=dojo.html.getComputedStyle;
if(dojo.lang.isArray(_6dc)){
dojo.deprecated("dojo.lfx.html.slideTo(node, array)","use dojo.lfx.html.slideTo(node, {top: value, left: value});","0.5");
_6dc={top:_6dc[0],left:_6dc[1]};
}
dojo.lang.forEach(_6db,function(node){
var top=null;
var left=null;
var init=(function(){
var _6e6=node;
return function(){
var pos=_6e1(_6e6,"position");
top=(pos=="absolute"?node.offsetTop:parseInt(_6e1(node,"top"))||0);
left=(pos=="absolute"?node.offsetLeft:parseInt(_6e1(node,"left"))||0);
if(!dojo.lang.inArray(["absolute","relative"],pos)){
var ret=dojo.html.abs(_6e6,true);
dojo.html.setStyleAttributes(_6e6,"position:absolute;top:"+ret.y+"px;left:"+ret.x+"px;");
top=ret.y;
left=ret.x;
}
};
})();
init();
var anim=dojo.lfx.propertyAnimation(node,{"top":{start:top,end:(_6dc.top||0)},"left":{start:left,end:(_6dc.left||0)}},_6dd,_6de,{"beforeBegin":init});
if(_6df){
anim.connect("onEnd",function(){
_6df(_6db,anim);
});
}
_6e0.push(anim);
});
return dojo.lfx.combine(_6e0);
};
dojo.lfx.html.slideBy=function(_6ea,_6eb,_6ec,_6ed,_6ee){
_6ea=dojo.lfx.html._byId(_6ea);
var _6ef=[];
var _6f0=dojo.html.getComputedStyle;
if(dojo.lang.isArray(_6eb)){
dojo.deprecated("dojo.lfx.html.slideBy(node, array)","use dojo.lfx.html.slideBy(node, {top: value, left: value});","0.5");
_6eb={top:_6eb[0],left:_6eb[1]};
}
dojo.lang.forEach(_6ea,function(node){
var top=null;
var left=null;
var init=(function(){
var _6f5=node;
return function(){
var pos=_6f0(_6f5,"position");
top=(pos=="absolute"?node.offsetTop:parseInt(_6f0(node,"top"))||0);
left=(pos=="absolute"?node.offsetLeft:parseInt(_6f0(node,"left"))||0);
if(!dojo.lang.inArray(["absolute","relative"],pos)){
var ret=dojo.html.abs(_6f5,true);
dojo.html.setStyleAttributes(_6f5,"position:absolute;top:"+ret.y+"px;left:"+ret.x+"px;");
top=ret.y;
left=ret.x;
}
};
})();
init();
var anim=dojo.lfx.propertyAnimation(node,{"top":{start:top,end:top+(_6eb.top||0)},"left":{start:left,end:left+(_6eb.left||0)}},_6ec,_6ed).connect("beforeBegin",init);
if(_6ee){
anim.connect("onEnd",function(){
_6ee(_6ea,anim);
});
}
_6ef.push(anim);
});
return dojo.lfx.combine(_6ef);
};
dojo.lfx.html.explode=function(_6f9,_6fa,_6fb,_6fc,_6fd){
var h=dojo.html;
_6f9=dojo.byId(_6f9);
_6fa=dojo.byId(_6fa);
var _6ff=h.toCoordinateObject(_6f9,true);
var _700=document.createElement("div");
h.copyStyle(_700,_6fa);
if(_6fa.explodeClassName){
_700.className=_6fa.explodeClassName;
}
with(_700.style){
position="absolute";
display="none";
var _701=h.getStyle(_6f9,"background-color");
backgroundColor=_701?_701.toLowerCase():"transparent";
backgroundColor=(backgroundColor=="transparent")?"rgb(221, 221, 221)":backgroundColor;
}
dojo.body().appendChild(_700);
with(_6fa.style){
visibility="hidden";
display="block";
}
var _702=h.toCoordinateObject(_6fa,true);
with(_6fa.style){
display="none";
visibility="visible";
}
var _703={opacity:{start:0.5,end:1}};
dojo.lang.forEach(["height","width","top","left"],function(type){
_703[type]={start:_6ff[type],end:_702[type]};
});
var anim=new dojo.lfx.propertyAnimation(_700,_703,_6fb,_6fc,{"beforeBegin":function(){
h.setDisplay(_700,"block");
},"onEnd":function(){
h.setDisplay(_6fa,"block");
_700.parentNode.removeChild(_700);
}});
if(_6fd){
anim.connect("onEnd",function(){
_6fd(_6fa,anim);
});
}
return anim;
};
dojo.lfx.html.implode=function(_706,end,_708,_709,_70a){
var h=dojo.html;
_706=dojo.byId(_706);
end=dojo.byId(end);
var _70c=dojo.html.toCoordinateObject(_706,true);
var _70d=dojo.html.toCoordinateObject(end,true);
var _70e=document.createElement("div");
dojo.html.copyStyle(_70e,_706);
if(_706.explodeClassName){
_70e.className=_706.explodeClassName;
}
dojo.html.setOpacity(_70e,0.3);
with(_70e.style){
position="absolute";
display="none";
backgroundColor=h.getStyle(_706,"background-color").toLowerCase();
}
dojo.body().appendChild(_70e);
var _70f={opacity:{start:1,end:0.5}};
dojo.lang.forEach(["height","width","top","left"],function(type){
_70f[type]={start:_70c[type],end:_70d[type]};
});
var anim=new dojo.lfx.propertyAnimation(_70e,_70f,_708,_709,{"beforeBegin":function(){
dojo.html.hide(_706);
dojo.html.show(_70e);
},"onEnd":function(){
_70e.parentNode.removeChild(_70e);
}});
if(_70a){
anim.connect("onEnd",function(){
_70a(_706,anim);
});
}
return anim;
};
dojo.lfx.html.highlight=function(_712,_713,_714,_715,_716){
_712=dojo.lfx.html._byId(_712);
var _717=[];
dojo.lang.forEach(_712,function(node){
var _719=dojo.html.getBackgroundColor(node);
var bg=dojo.html.getStyle(node,"background-color").toLowerCase();
var _71b=dojo.html.getStyle(node,"background-image");
var _71c=(bg=="transparent"||bg=="rgba(0, 0, 0, 0)");
while(_719.length>3){
_719.pop();
}
var rgb=new dojo.gfx.color.Color(_713);
var _71e=new dojo.gfx.color.Color(_719);
var anim=dojo.lfx.propertyAnimation(node,{"background-color":{start:rgb,end:_71e}},_714,_715,{"beforeBegin":function(){
if(_71b){
node.style.backgroundImage="none";
}
node.style.backgroundColor="rgb("+rgb.toRgb().join(",")+")";
},"onEnd":function(){
if(_71b){
node.style.backgroundImage=_71b;
}
if(_71c){
node.style.backgroundColor="transparent";
}
if(_716){
_716(node,anim);
}
}});
_717.push(anim);
});
return dojo.lfx.combine(_717);
};
dojo.lfx.html.unhighlight=function(_720,_721,_722,_723,_724){
_720=dojo.lfx.html._byId(_720);
var _725=[];
dojo.lang.forEach(_720,function(node){
var _727=new dojo.gfx.color.Color(dojo.html.getBackgroundColor(node));
var rgb=new dojo.gfx.color.Color(_721);
var _729=dojo.html.getStyle(node,"background-image");
var anim=dojo.lfx.propertyAnimation(node,{"background-color":{start:_727,end:rgb}},_722,_723,{"beforeBegin":function(){
if(_729){
node.style.backgroundImage="none";
}
node.style.backgroundColor="rgb("+_727.toRgb().join(",")+")";
},"onEnd":function(){
if(_724){
_724(node,anim);
}
}});
_725.push(anim);
});
return dojo.lfx.combine(_725);
};
dojo.lang.mixin(dojo.lfx,dojo.lfx.html);
dojo.provide("dojo.lfx.*");
dojo.provide("dojo.lfx.toggle");
dojo.lfx.toggle.plain={show:function(node,_72c,_72d,_72e){
dojo.html.show(node);
if(dojo.lang.isFunction(_72e)){
_72e();
}
},hide:function(node,_730,_731,_732){
dojo.html.hide(node);
if(dojo.lang.isFunction(_732)){
_732();
}
}};
dojo.lfx.toggle.fade={show:function(node,_734,_735,_736){
dojo.lfx.fadeShow(node,_734,_735,_736).play();
},hide:function(node,_738,_739,_73a){
dojo.lfx.fadeHide(node,_738,_739,_73a).play();
}};
dojo.lfx.toggle.wipe={show:function(node,_73c,_73d,_73e){
dojo.lfx.wipeIn(node,_73c,_73d,_73e).play();
},hide:function(node,_740,_741,_742){
dojo.lfx.wipeOut(node,_740,_741,_742).play();
}};
dojo.lfx.toggle.explode={show:function(node,_744,_745,_746,_747){
dojo.lfx.explode(_747||{x:0,y:0,width:0,height:0},node,_744,_745,_746).play();
},hide:function(node,_749,_74a,_74b,_74c){
dojo.lfx.implode(node,_74c||{x:0,y:0,width:0,height:0},_749,_74a,_74b).play();
}};
dojo.provide("dojo.widget.HtmlWidget");
dojo.declare("dojo.widget.HtmlWidget",dojo.widget.DomWidget,{templateCssPath:null,templatePath:null,lang:"",toggle:"plain",toggleDuration:150,initialize:function(args,frag){
},postMixInProperties:function(args,frag){
if(this.lang===""){
this.lang=null;
}
this.toggleObj=dojo.lfx.toggle[this.toggle.toLowerCase()]||dojo.lfx.toggle.plain;
},createNodesFromText:function(txt,wrap){
return dojo.html.createNodesFromText(txt,wrap);
},destroyRendering:function(_753){
try{
if(this.bgIframe){
this.bgIframe.remove();
delete this.bgIframe;
}
if(!_753&&this.domNode){
dojo.event.browser.clean(this.domNode);
}
dojo.widget.HtmlWidget.superclass.destroyRendering.call(this);
}
catch(e){
}
},isShowing:function(){
return dojo.html.isShowing(this.domNode);
},toggleShowing:function(){
if(this.isShowing()){
this.hide();
}else{
this.show();
}
},show:function(){
if(this.isShowing()){
return;
}
this.animationInProgress=true;
this.toggleObj.show(this.domNode,this.toggleDuration,null,dojo.lang.hitch(this,this.onShow),this.explodeSrc);
},onShow:function(){
this.animationInProgress=false;
this.checkSize();
},hide:function(){
if(!this.isShowing()){
return;
}
this.animationInProgress=true;
this.toggleObj.hide(this.domNode,this.toggleDuration,null,dojo.lang.hitch(this,this.onHide),this.explodeSrc);
},onHide:function(){
this.animationInProgress=false;
},_isResized:function(w,h){
if(!this.isShowing()){
return false;
}
var wh=dojo.html.getMarginBox(this.domNode);
var _757=w||wh.width;
var _758=h||wh.height;
if(this.width==_757&&this.height==_758){
return false;
}
this.width=_757;
this.height=_758;
return true;
},checkSize:function(){
if(!this._isResized()){
return;
}
this.onResized();
},resizeTo:function(w,h){
dojo.html.setMarginBox(this.domNode,{width:w,height:h});
if(this.isShowing()){
this.onResized();
}
},resizeSoon:function(){
if(this.isShowing()){
dojo.lang.setTimeout(this,this.onResized,0);
}
},onResized:function(){
dojo.lang.forEach(this.children,function(_75b){
if(_75b.checkSize){
_75b.checkSize();
}
});
}});
dojo.provide("dojo.widget.*");
dojo.provide("dojo.string.common");
dojo.string.trim=function(str,wh){
if(!str.replace){
return str;
}
if(!str.length){
return str;
}
var re=(wh>0)?(/^\s+/):(wh<0)?(/\s+$/):(/^\s+|\s+$/g);
return str.replace(re,"");
};
dojo.string.trimStart=function(str){
return dojo.string.trim(str,1);
};
dojo.string.trimEnd=function(str){
return dojo.string.trim(str,-1);
};
dojo.string.repeat=function(str,_762,_763){
var out="";
for(var i=0;i<_762;i++){
out+=str;
if(_763&&i<_762-1){
out+=_763;
}
}
return out;
};
dojo.string.pad=function(str,len,c,dir){
var out=String(str);
if(!c){
c="0";
}
if(!dir){
dir=1;
}
while(out.length<len){
if(dir>0){
out=c+out;
}else{
out+=c;
}
}
return out;
};
dojo.string.padLeft=function(str,len,c){
return dojo.string.pad(str,len,c,1);
};
dojo.string.padRight=function(str,len,c){
return dojo.string.pad(str,len,c,-1);
};
dojo.provide("dojo.string");
dojo.provide("dojo.io.common");
dojo.io.transports=[];
dojo.io.hdlrFuncNames=["load","error","timeout"];
dojo.io.Request=function(url,_772,_773,_774){
if((arguments.length==1)&&(arguments[0].constructor==Object)){
this.fromKwArgs(arguments[0]);
}else{
this.url=url;
if(_772){
this.mimetype=_772;
}
if(_773){
this.transport=_773;
}
if(arguments.length>=4){
this.changeUrl=_774;
}
}
};
dojo.lang.extend(dojo.io.Request,{url:"",mimetype:"text/plain",method:"GET",content:undefined,transport:undefined,changeUrl:undefined,formNode:undefined,sync:false,bindSuccess:false,useCache:false,preventCache:false,load:function(type,data,_777,_778){
},error:function(type,_77a,_77b,_77c){
},timeout:function(type,_77e,_77f,_780){
},handle:function(type,data,_783,_784){
},timeoutSeconds:0,abort:function(){
},fromKwArgs:function(_785){
if(_785["url"]){
_785.url=_785.url.toString();
}
if(_785["formNode"]){
_785.formNode=dojo.byId(_785.formNode);
}
if(!_785["method"]&&_785["formNode"]&&_785["formNode"].method){
_785.method=_785["formNode"].method;
}
if(!_785["handle"]&&_785["handler"]){
_785.handle=_785.handler;
}
if(!_785["load"]&&_785["loaded"]){
_785.load=_785.loaded;
}
if(!_785["changeUrl"]&&_785["changeURL"]){
_785.changeUrl=_785.changeURL;
}
_785.encoding=dojo.lang.firstValued(_785["encoding"],djConfig["bindEncoding"],"");
_785.sendTransport=dojo.lang.firstValued(_785["sendTransport"],djConfig["ioSendTransport"],false);
var _786=dojo.lang.isFunction;
for(var x=0;x<dojo.io.hdlrFuncNames.length;x++){
var fn=dojo.io.hdlrFuncNames[x];
if(_785[fn]&&_786(_785[fn])){
continue;
}
if(_785["handle"]&&_786(_785["handle"])){
_785[fn]=_785.handle;
}
}
dojo.lang.mixin(this,_785);
}});
dojo.io.Error=function(msg,type,num){
this.message=msg;
this.type=type||"unknown";
this.number=num||0;
};
dojo.io.transports.addTransport=function(name){
this.push(name);
this[name]=dojo.io[name];
};
dojo.io.bind=function(_78d){
if(!(_78d instanceof dojo.io.Request)){
try{
_78d=new dojo.io.Request(_78d);
}
catch(e){
dojo.debug(e);
}
}
var _78e="";
if(_78d["transport"]){
_78e=_78d["transport"];
if(!this[_78e]){
dojo.io.sendBindError(_78d,"No dojo.io.bind() transport with name '"+_78d["transport"]+"'.");
return _78d;
}
if(!this[_78e].canHandle(_78d)){
dojo.io.sendBindError(_78d,"dojo.io.bind() transport with name '"+_78d["transport"]+"' cannot handle this type of request.");
return _78d;
}
}else{
for(var x=0;x<dojo.io.transports.length;x++){
var tmp=dojo.io.transports[x];
if((this[tmp])&&(this[tmp].canHandle(_78d))){
_78e=tmp;
break;
}
}
if(_78e==""){
dojo.io.sendBindError(_78d,"None of the loaded transports for dojo.io.bind()"+" can handle the request.");
return _78d;
}
}
this[_78e].bind(_78d);
_78d.bindSuccess=true;
return _78d;
};
dojo.io.sendBindError=function(_791,_792){
if((typeof _791.error=="function"||typeof _791.handle=="function")&&(typeof setTimeout=="function"||typeof setTimeout=="object")){
var _793=new dojo.io.Error(_792);
setTimeout(function(){
_791[(typeof _791.error=="function")?"error":"handle"]("error",_793,null,_791);
},50);
}else{
dojo.raise(_792);
}
};
dojo.io.queueBind=function(_794){
if(!(_794 instanceof dojo.io.Request)){
try{
_794=new dojo.io.Request(_794);
}
catch(e){
dojo.debug(e);
}
}
var _795=_794.load;
_794.load=function(){
dojo.io._queueBindInFlight=false;
var ret=_795.apply(this,arguments);
dojo.io._dispatchNextQueueBind();
return ret;
};
var _797=_794.error;
_794.error=function(){
dojo.io._queueBindInFlight=false;
var ret=_797.apply(this,arguments);
dojo.io._dispatchNextQueueBind();
return ret;
};
dojo.io._bindQueue.push(_794);
dojo.io._dispatchNextQueueBind();
return _794;
};
dojo.io._dispatchNextQueueBind=function(){
if(!dojo.io._queueBindInFlight){
dojo.io._queueBindInFlight=true;
if(dojo.io._bindQueue.length>0){
dojo.io.bind(dojo.io._bindQueue.shift());
}else{
dojo.io._queueBindInFlight=false;
}
}
};
dojo.io._bindQueue=[];
dojo.io._queueBindInFlight=false;
dojo.io.argsFromMap=function(map,_79a,last){
var enc=/utf/i.test(_79a||"")?encodeURIComponent:dojo.string.encodeAscii;
var _79d=[];
var _79e=new Object();
for(var name in map){
var _7a0=function(elt){
var val=enc(name)+"="+enc(elt);
_79d[(last==name)?"push":"unshift"](val);
};
if(!_79e[name]){
var _7a3=map[name];
if(dojo.lang.isArray(_7a3)){
dojo.lang.forEach(_7a3,_7a0);
}else{
_7a0(_7a3);
}
}
}
return _79d.join("&");
};
dojo.io.setIFrameSrc=function(_7a4,src,_7a6){
try{
var r=dojo.render.html;
if(!_7a6){
if(r.safari){
_7a4.location=src;
}else{
frames[_7a4.name].location=src;
}
}else{
var idoc;
if(r.ie){
idoc=_7a4.contentWindow.document;
}else{
if(r.safari){
idoc=_7a4.document;
}else{
idoc=_7a4.contentWindow;
}
}
if(!idoc){
_7a4.location=src;
return;
}else{
idoc.location.replace(src);
}
}
}
catch(e){
dojo.debug(e);
dojo.debug("setIFrameSrc: "+e);
}
};
dojo.provide("dojo.string.extras");
dojo.string.substituteParams=function(_7a9,hash){
var map=(typeof hash=="object")?hash:dojo.lang.toArray(arguments,1);
return _7a9.replace(/\%\{(\w+)\}/g,function(_7ac,key){
if(typeof (map[key])!="undefined"&&map[key]!=null){
return map[key];
}
dojo.raise("Substitution not found: "+key);
});
};
dojo.string.capitalize=function(str){
if(!dojo.lang.isString(str)){
return "";
}
if(arguments.length==0){
str=this;
}
var _7af=str.split(" ");
for(var i=0;i<_7af.length;i++){
_7af[i]=_7af[i].charAt(0).toUpperCase()+_7af[i].substring(1);
}
return _7af.join(" ");
};
dojo.string.isBlank=function(str){
if(!dojo.lang.isString(str)){
return true;
}
return (dojo.string.trim(str).length==0);
};
dojo.string.encodeAscii=function(str){
if(!dojo.lang.isString(str)){
return str;
}
var ret="";
var _7b4=escape(str);
var _7b5,re=/%u([0-9A-F]{4})/i;
while((_7b5=_7b4.match(re))){
var num=Number("0x"+_7b5[1]);
var _7b8=escape("&#"+num+";");
ret+=_7b4.substring(0,_7b5.index)+_7b8;
_7b4=_7b4.substring(_7b5.index+_7b5[0].length);
}
ret+=_7b4.replace(/\+/g,"%2B");
return ret;
};
dojo.string.escape=function(type,str){
var args=dojo.lang.toArray(arguments,1);
switch(type.toLowerCase()){
case "xml":
case "html":
case "xhtml":
return dojo.string.escapeXml.apply(this,args);
case "sql":
return dojo.string.escapeSql.apply(this,args);
case "regexp":
case "regex":
return dojo.string.escapeRegExp.apply(this,args);
case "javascript":
case "jscript":
case "js":
return dojo.string.escapeJavaScript.apply(this,args);
case "ascii":
return dojo.string.encodeAscii.apply(this,args);
default:
return str;
}
};
dojo.string.escapeXml=function(str,_7bd){
str=str.replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
if(!_7bd){
str=str.replace(/'/gm,"&#39;");
}
return str;
};
dojo.string.escapeSql=function(str){
return str.replace(/'/gm,"''");
};
dojo.string.escapeRegExp=function(str){
return str.replace(/\\/gm,"\\\\").replace(/([\f\b\n\t\r[\^$|?*+(){}])/gm,"\\$1");
};
dojo.string.escapeJavaScript=function(str){
return str.replace(/(["'\f\b\n\t\r])/gm,"\\$1");
};
dojo.string.escapeString=function(str){
return ("\""+str.replace(/(["\\])/g,"\\$1")+"\"").replace(/[\f]/g,"\\f").replace(/[\b]/g,"\\b").replace(/[\n]/g,"\\n").replace(/[\t]/g,"\\t").replace(/[\r]/g,"\\r");
};
dojo.string.summary=function(str,len){
if(!len||str.length<=len){
return str;
}
return str.substring(0,len).replace(/\.+$/,"")+"...";
};
dojo.string.endsWith=function(str,end,_7c6){
if(_7c6){
str=str.toLowerCase();
end=end.toLowerCase();
}
if((str.length-end.length)<0){
return false;
}
return str.lastIndexOf(end)==str.length-end.length;
};
dojo.string.endsWithAny=function(str){
for(var i=1;i<arguments.length;i++){
if(dojo.string.endsWith(str,arguments[i])){
return true;
}
}
return false;
};
dojo.string.startsWith=function(str,_7ca,_7cb){
if(_7cb){
str=str.toLowerCase();
_7ca=_7ca.toLowerCase();
}
return str.indexOf(_7ca)==0;
};
dojo.string.startsWithAny=function(str){
for(var i=1;i<arguments.length;i++){
if(dojo.string.startsWith(str,arguments[i])){
return true;
}
}
return false;
};
dojo.string.has=function(str){
for(var i=1;i<arguments.length;i++){
if(str.indexOf(arguments[i])>-1){
return true;
}
}
return false;
};
dojo.string.normalizeNewlines=function(text,_7d1){
if(_7d1=="\n"){
text=text.replace(/\r\n/g,"\n");
text=text.replace(/\r/g,"\n");
}else{
if(_7d1=="\r"){
text=text.replace(/\r\n/g,"\r");
text=text.replace(/\n/g,"\r");
}else{
text=text.replace(/([^\r])\n/g,"$1\r\n").replace(/\r([^\n])/g,"\r\n$1");
}
}
return text;
};
dojo.string.splitEscaped=function(str,_7d3){
var _7d4=[];
for(var i=0,_7d6=0;i<str.length;i++){
if(str.charAt(i)=="\\"){
i++;
continue;
}
if(str.charAt(i)==_7d3){
_7d4.push(str.substring(_7d6,i));
_7d6=i+1;
}
}
_7d4.push(str.substr(_7d6));
return _7d4;
};
dojo.provide("dojo.undo.browser");
try{
if((!djConfig["preventBackButtonFix"])&&(!dojo.hostenv.post_load_)){
document.write("<iframe style='border: 0px; width: 1px; height: 1px; position: absolute; bottom: 0px; right: 0px; visibility: visible;' name='djhistory' id='djhistory' src='"+(dojo.hostenv.getBaseScriptUri()+"iframe_history.html")+"'></iframe>");
}
}
catch(e){
}
if(dojo.render.html.opera){
dojo.debug("Opera is not supported with dojo.undo.browser, so back/forward detection will not work.");
}
dojo.undo.browser={initialHref:(!dj_undef("window"))?window.location.href:"",initialHash:(!dj_undef("window"))?window.location.hash:"",moveForward:false,historyStack:[],forwardStack:[],historyIframe:null,bookmarkAnchor:null,locationTimer:null,setInitialState:function(args){
this.initialState=this._createState(this.initialHref,args,this.initialHash);
},addToHistory:function(args){
this.forwardStack=[];
var hash=null;
var url=null;
if(!this.historyIframe){
this.historyIframe=window.frames["djhistory"];
}
if(!this.bookmarkAnchor){
this.bookmarkAnchor=document.createElement("a");
dojo.body().appendChild(this.bookmarkAnchor);
this.bookmarkAnchor.style.display="none";
}
if(args["changeUrl"]){
hash="#"+((args["changeUrl"]!==true)?args["changeUrl"]:(new Date()).getTime());
if(this.historyStack.length==0&&this.initialState.urlHash==hash){
this.initialState=this._createState(url,args,hash);
return;
}else{
if(this.historyStack.length>0&&this.historyStack[this.historyStack.length-1].urlHash==hash){
this.historyStack[this.historyStack.length-1]=this._createState(url,args,hash);
return;
}
}
this.changingUrl=true;
setTimeout("window.location.href = '"+hash+"'; dojo.undo.browser.changingUrl = false;",1);
this.bookmarkAnchor.href=hash;
if(dojo.render.html.ie){
url=this._loadIframeHistory();
var _7db=args["back"]||args["backButton"]||args["handle"];
var tcb=function(_7dd){
if(window.location.hash!=""){
setTimeout("window.location.href = '"+hash+"';",1);
}
_7db.apply(this,[_7dd]);
};
if(args["back"]){
args.back=tcb;
}else{
if(args["backButton"]){
args.backButton=tcb;
}else{
if(args["handle"]){
args.handle=tcb;
}
}
}
var _7de=args["forward"]||args["forwardButton"]||args["handle"];
var tfw=function(_7e0){
if(window.location.hash!=""){
window.location.href=hash;
}
if(_7de){
_7de.apply(this,[_7e0]);
}
};
if(args["forward"]){
args.forward=tfw;
}else{
if(args["forwardButton"]){
args.forwardButton=tfw;
}else{
if(args["handle"]){
args.handle=tfw;
}
}
}
}else{
if(dojo.render.html.moz){
if(!this.locationTimer){
this.locationTimer=setInterval("dojo.undo.browser.checkLocation();",200);
}
}
}
}else{
url=this._loadIframeHistory();
}
this.historyStack.push(this._createState(url,args,hash));
},checkLocation:function(){
if(!this.changingUrl){
var hsl=this.historyStack.length;
if((window.location.hash==this.initialHash||window.location.href==this.initialHref)&&(hsl==1)){
this.handleBackButton();
return;
}
if(this.forwardStack.length>0){
if(this.forwardStack[this.forwardStack.length-1].urlHash==window.location.hash){
this.handleForwardButton();
return;
}
}
if((hsl>=2)&&(this.historyStack[hsl-2])){
if(this.historyStack[hsl-2].urlHash==window.location.hash){
this.handleBackButton();
return;
}
}
}
},iframeLoaded:function(evt,_7e3){
if(!dojo.render.html.opera){
var _7e4=this._getUrlQuery(_7e3.href);
if(_7e4==null){
if(this.historyStack.length==1){
this.handleBackButton();
}
return;
}
if(this.moveForward){
this.moveForward=false;
return;
}
if(this.historyStack.length>=2&&_7e4==this._getUrlQuery(this.historyStack[this.historyStack.length-2].url)){
this.handleBackButton();
}else{
if(this.forwardStack.length>0&&_7e4==this._getUrlQuery(this.forwardStack[this.forwardStack.length-1].url)){
this.handleForwardButton();
}
}
}
},handleBackButton:function(){
var _7e5=this.historyStack.pop();
if(!_7e5){
return;
}
var last=this.historyStack[this.historyStack.length-1];
if(!last&&this.historyStack.length==0){
last=this.initialState;
}
if(last){
if(last.kwArgs["back"]){
last.kwArgs["back"]();
}else{
if(last.kwArgs["backButton"]){
last.kwArgs["backButton"]();
}else{
if(last.kwArgs["handle"]){
last.kwArgs.handle("back");
}
}
}
}
this.forwardStack.push(_7e5);
},handleForwardButton:function(){
var last=this.forwardStack.pop();
if(!last){
return;
}
if(last.kwArgs["forward"]){
last.kwArgs.forward();
}else{
if(last.kwArgs["forwardButton"]){
last.kwArgs.forwardButton();
}else{
if(last.kwArgs["handle"]){
last.kwArgs.handle("forward");
}
}
}
this.historyStack.push(last);
},_createState:function(url,args,hash){
return {"url":url,"kwArgs":args,"urlHash":hash};
},_getUrlQuery:function(url){
var _7ec=url.split("?");
if(_7ec.length<2){
return null;
}else{
return _7ec[1];
}
},_loadIframeHistory:function(){
var url=dojo.hostenv.getBaseScriptUri()+"iframe_history.html?"+(new Date()).getTime();
this.moveForward=true;
dojo.io.setIFrameSrc(this.historyIframe,url,false);
return url;
}};
dojo.provide("dojo.io.BrowserIO");
if(!dj_undef("window")){
dojo.io.checkChildrenForFile=function(node){
var _7ef=false;
var _7f0=node.getElementsByTagName("input");
dojo.lang.forEach(_7f0,function(_7f1){
if(_7ef){
return;
}
if(_7f1.getAttribute("type")=="file"){
_7ef=true;
}
});
return _7ef;
};
dojo.io.formHasFile=function(_7f2){
return dojo.io.checkChildrenForFile(_7f2);
};
dojo.io.updateNode=function(node,_7f4){
node=dojo.byId(node);
var args=_7f4;
if(dojo.lang.isString(_7f4)){
args={url:_7f4};
}
args.mimetype="text/html";
args.load=function(t,d,e){
while(node.firstChild){
dojo.dom.destroyNode(node.firstChild);
}
node.innerHTML=d;
};
dojo.io.bind(args);
};
dojo.io.formFilter=function(node){
var type=(node.type||"").toLowerCase();
return !node.disabled&&node.name&&!dojo.lang.inArray(["file","submit","image","reset","button"],type);
};
dojo.io.encodeForm=function(_7fb,_7fc,_7fd){
if((!_7fb)||(!_7fb.tagName)||(!_7fb.tagName.toLowerCase()=="form")){
dojo.raise("Attempted to encode a non-form element.");
}
if(!_7fd){
_7fd=dojo.io.formFilter;
}
var enc=/utf/i.test(_7fc||"")?encodeURIComponent:dojo.string.encodeAscii;
var _7ff=[];
for(var i=0;i<_7fb.elements.length;i++){
var elm=_7fb.elements[i];
if(!elm||elm.tagName.toLowerCase()=="fieldset"||!_7fd(elm)){
continue;
}
var name=enc(elm.name);
var type=elm.type.toLowerCase();
if(type=="select-multiple"){
for(var j=0;j<elm.options.length;j++){
if(elm.options[j].selected){
_7ff.push(name+"="+enc(elm.options[j].value));
}
}
}else{
if(dojo.lang.inArray(["radio","checkbox"],type)){
if(elm.checked){
_7ff.push(name+"="+enc(elm.value));
}
}else{
_7ff.push(name+"="+enc(elm.value));
}
}
}
var _805=_7fb.getElementsByTagName("input");
for(var i=0;i<_805.length;i++){
var _806=_805[i];
if(_806.type.toLowerCase()=="image"&&_806.form==_7fb&&_7fd(_806)){
var name=enc(_806.name);
_7ff.push(name+"="+enc(_806.value));
_7ff.push(name+".x=0");
_7ff.push(name+".y=0");
}
}
return _7ff.join("&")+"&";
};
dojo.io.FormBind=function(args){
this.bindArgs={};
if(args&&args.formNode){
this.init(args);
}else{
if(args){
this.init({formNode:args});
}
}
};
dojo.lang.extend(dojo.io.FormBind,{form:null,bindArgs:null,clickedButton:null,init:function(args){
var form=dojo.byId(args.formNode);
if(!form||!form.tagName||form.tagName.toLowerCase()!="form"){
throw new Error("FormBind: Couldn't apply, invalid form");
}else{
if(this.form==form){
return;
}else{
if(this.form){
throw new Error("FormBind: Already applied to a form");
}
}
}
dojo.lang.mixin(this.bindArgs,args);
this.form=form;
this.connect(form,"onsubmit","submit");
for(var i=0;i<form.elements.length;i++){
var node=form.elements[i];
if(node&&node.type&&dojo.lang.inArray(["submit","button"],node.type.toLowerCase())){
this.connect(node,"onclick","click");
}
}
var _80c=form.getElementsByTagName("input");
for(var i=0;i<_80c.length;i++){
var _80d=_80c[i];
if(_80d.type.toLowerCase()=="image"&&_80d.form==form){
this.connect(_80d,"onclick","click");
}
}
},onSubmit:function(form){
return true;
},submit:function(e){
e.preventDefault();
if(this.onSubmit(this.form)){
dojo.io.bind(dojo.lang.mixin(this.bindArgs,{formFilter:dojo.lang.hitch(this,"formFilter")}));
}
},click:function(e){
var node=e.currentTarget;
if(node.disabled){
return;
}
this.clickedButton=node;
},formFilter:function(node){
var type=(node.type||"").toLowerCase();
var _814=false;
if(node.disabled||!node.name){
_814=false;
}else{
if(dojo.lang.inArray(["submit","button","image"],type)){
if(!this.clickedButton){
this.clickedButton=node;
}
_814=node==this.clickedButton;
}else{
_814=!dojo.lang.inArray(["file","submit","reset","button"],type);
}
}
return _814;
},connect:function(_815,_816,_817){
if(dojo.evalObjPath("dojo.event.connect")){
dojo.event.connect(_815,_816,this,_817);
}else{
var fcn=dojo.lang.hitch(this,_817);
_815[_816]=function(e){
if(!e){
e=window.event;
}
if(!e.currentTarget){
e.currentTarget=e.srcElement;
}
if(!e.preventDefault){
e.preventDefault=function(){
window.event.returnValue=false;
};
}
fcn(e);
};
}
}});
dojo.io.XMLHTTPTransport=new function(){
var _81a=this;
var _81b={};
this.useCache=false;
this.preventCache=false;
function getCacheKey(url,_81d,_81e){
return url+"|"+_81d+"|"+_81e.toLowerCase();
}
function addToCache(url,_820,_821,http){
_81b[getCacheKey(url,_820,_821)]=http;
}
function getFromCache(url,_824,_825){
return _81b[getCacheKey(url,_824,_825)];
}
this.clearCache=function(){
_81b={};
};
function doLoad(_826,http,url,_829,_82a){
if(((http.status>=200)&&(http.status<300))||(http.status==304)||(location.protocol=="file:"&&(http.status==0||http.status==undefined))||(location.protocol=="chrome:"&&(http.status==0||http.status==undefined))){
var ret;
if(_826.method.toLowerCase()=="head"){
var _82c=http.getAllResponseHeaders();
ret={};
ret.toString=function(){
return _82c;
};
var _82d=_82c.split(/[\r\n]+/g);
for(var i=0;i<_82d.length;i++){
var pair=_82d[i].match(/^([^:]+)\s*:\s*(.+)$/i);
if(pair){
ret[pair[1]]=pair[2];
}
}
}else{
if(_826.mimetype=="text/javascript"){
try{
ret=dj_eval(http.responseText);
}
catch(e){
dojo.debug(e);
dojo.debug(http.responseText);
ret=null;
}
}else{
if(_826.mimetype=="text/json"||_826.mimetype=="application/json"){
try{
ret=dj_eval("("+http.responseText+")");
}
catch(e){
dojo.debug(e);
dojo.debug(http.responseText);
ret=false;
}
}else{
if((_826.mimetype=="application/xml")||(_826.mimetype=="text/xml")){
ret=http.responseXML;
if(!ret||typeof ret=="string"||!http.getResponseHeader("Content-Type")){
ret=dojo.dom.createDocumentFromText(http.responseText);
}
}else{
ret=http.responseText;
}
}
}
}
if(_82a){
addToCache(url,_829,_826.method,http);
}
_826[(typeof _826.load=="function")?"load":"handle"]("load",ret,http,_826);
}else{
var _830=new dojo.io.Error("XMLHttpTransport Error: "+http.status+" "+http.statusText);
_826[(typeof _826.error=="function")?"error":"handle"]("error",_830,http,_826);
}
}
function setHeaders(http,_832){
if(_832["headers"]){
for(var _833 in _832["headers"]){
if(_833.toLowerCase()=="content-type"&&!_832["contentType"]){
_832["contentType"]=_832["headers"][_833];
}else{
http.setRequestHeader(_833,_832["headers"][_833]);
}
}
}
}
this.inFlight=[];
this.inFlightTimer=null;
this.startWatchingInFlight=function(){
if(!this.inFlightTimer){
this.inFlightTimer=setTimeout("dojo.io.XMLHTTPTransport.watchInFlight();",10);
}
};
this.watchInFlight=function(){
var now=null;
if(!dojo.hostenv._blockAsync&&!_81a._blockAsync){
for(var x=this.inFlight.length-1;x>=0;x--){
try{
var tif=this.inFlight[x];
if(!tif||tif.http._aborted||!tif.http.readyState){
this.inFlight.splice(x,1);
continue;
}
if(4==tif.http.readyState){
this.inFlight.splice(x,1);
doLoad(tif.req,tif.http,tif.url,tif.query,tif.useCache);
}else{
if(tif.startTime){
if(!now){
now=(new Date()).getTime();
}
if(tif.startTime+(tif.req.timeoutSeconds*1000)<now){
if(typeof tif.http.abort=="function"){
tif.http.abort();
}
this.inFlight.splice(x,1);
tif.req[(typeof tif.req.timeout=="function")?"timeout":"handle"]("timeout",null,tif.http,tif.req);
}
}
}
}
catch(e){
try{
var _837=new dojo.io.Error("XMLHttpTransport.watchInFlight Error: "+e);
tif.req[(typeof tif.req.error=="function")?"error":"handle"]("error",_837,tif.http,tif.req);
}
catch(e2){
dojo.debug("XMLHttpTransport error callback failed: "+e2);
}
}
}
}
clearTimeout(this.inFlightTimer);
if(this.inFlight.length==0){
this.inFlightTimer=null;
return;
}
this.inFlightTimer=setTimeout("dojo.io.XMLHTTPTransport.watchInFlight();",10);
};
var _838=dojo.hostenv.getXmlhttpObject()?true:false;
this.canHandle=function(_839){
return _838&&dojo.lang.inArray(["text/plain","text/html","application/xml","text/xml","text/javascript","text/json","application/json"],(_839["mimetype"].toLowerCase()||""))&&!(_839["formNode"]&&dojo.io.formHasFile(_839["formNode"]));
};
this.multipartBoundary="45309FFF-BD65-4d50-99C9-36986896A96F";
this.bind=function(_83a){
if(!_83a["url"]){
if(!_83a["formNode"]&&(_83a["backButton"]||_83a["back"]||_83a["changeUrl"]||_83a["watchForURL"])&&(!djConfig.preventBackButtonFix)){
dojo.deprecated("Using dojo.io.XMLHTTPTransport.bind() to add to browser history without doing an IO request","Use dojo.undo.browser.addToHistory() instead.","0.4");
dojo.undo.browser.addToHistory(_83a);
return true;
}
}
var url=_83a.url;
var _83c="";
if(_83a["formNode"]){
var ta=_83a.formNode.getAttribute("action");
if((ta)&&(!_83a["url"])){
url=ta;
}
var tp=_83a.formNode.getAttribute("method");
if((tp)&&(!_83a["method"])){
_83a.method=tp;
}
_83c+=dojo.io.encodeForm(_83a.formNode,_83a.encoding,_83a["formFilter"]);
}
if(url.indexOf("#")>-1){
dojo.debug("Warning: dojo.io.bind: stripping hash values from url:",url);
url=url.split("#")[0];
}
if(_83a["file"]){
_83a.method="post";
}
if(!_83a["method"]){
_83a.method="get";
}
if(_83a.method.toLowerCase()=="get"){
_83a.multipart=false;
}else{
if(_83a["file"]){
_83a.multipart=true;
}else{
if(!_83a["multipart"]){
_83a.multipart=false;
}
}
}
if(_83a["backButton"]||_83a["back"]||_83a["changeUrl"]){
dojo.undo.browser.addToHistory(_83a);
}
var _83f=_83a["content"]||{};
if(_83a.sendTransport){
_83f["dojo.transport"]="xmlhttp";
}
do{
if(_83a.postContent){
_83c=_83a.postContent;
break;
}
if(_83f){
_83c+=dojo.io.argsFromMap(_83f,_83a.encoding);
}
if(_83a.method.toLowerCase()=="get"||!_83a.multipart){
break;
}
var t=[];
if(_83c.length){
var q=_83c.split("&");
for(var i=0;i<q.length;++i){
if(q[i].length){
var p=q[i].split("=");
t.push("--"+this.multipartBoundary,"Content-Disposition: form-data; name=\""+p[0]+"\"","",p[1]);
}
}
}
if(_83a.file){
if(dojo.lang.isArray(_83a.file)){
for(var i=0;i<_83a.file.length;++i){
var o=_83a.file[i];
t.push("--"+this.multipartBoundary,"Content-Disposition: form-data; name=\""+o.name+"\"; filename=\""+("fileName" in o?o.fileName:o.name)+"\"","Content-Type: "+("contentType" in o?o.contentType:"application/octet-stream"),"",o.content);
}
}else{
var o=_83a.file;
t.push("--"+this.multipartBoundary,"Content-Disposition: form-data; name=\""+o.name+"\"; filename=\""+("fileName" in o?o.fileName:o.name)+"\"","Content-Type: "+("contentType" in o?o.contentType:"application/octet-stream"),"",o.content);
}
}
if(t.length){
t.push("--"+this.multipartBoundary+"--","");
_83c=t.join("\r\n");
}
}while(false);
var _845=_83a["sync"]?false:true;
var _846=_83a["preventCache"]||(this.preventCache==true&&_83a["preventCache"]!=false);
var _847=_83a["useCache"]==true||(this.useCache==true&&_83a["useCache"]!=false);
if(!_846&&_847){
var _848=getFromCache(url,_83c,_83a.method);
if(_848){
doLoad(_83a,_848,url,_83c,false);
return;
}
}
var http=dojo.hostenv.getXmlhttpObject(_83a);
var _84a=false;
if(_845){
var _84b=this.inFlight.push({"req":_83a,"http":http,"url":url,"query":_83c,"useCache":_847,"startTime":_83a.timeoutSeconds?(new Date()).getTime():0});
this.startWatchingInFlight();
}else{
_81a._blockAsync=true;
}
if(_83a.method.toLowerCase()=="post"){
if(!_83a.user){
http.open("POST",url,_845);
}else{
http.open("POST",url,_845,_83a.user,_83a.password);
}
setHeaders(http,_83a);
http.setRequestHeader("Content-Type",_83a.multipart?("multipart/form-data; boundary="+this.multipartBoundary):(_83a.contentType||"application/x-www-form-urlencoded"));
try{
http.send(_83c);
}
catch(e){
if(typeof http.abort=="function"){
http.abort();
}
doLoad(_83a,{status:404},url,_83c,_847);
}
}else{
var _84c=url;
if(_83c!=""){
_84c+=(_84c.indexOf("?")>-1?"&":"?")+_83c;
}
if(_846){
_84c+=(dojo.string.endsWithAny(_84c,"?","&")?"":(_84c.indexOf("?")>-1?"&":"?"))+"dojo.preventCache="+new Date().valueOf();
}
if(!_83a.user){
http.open(_83a.method.toUpperCase(),_84c,_845);
}else{
http.open(_83a.method.toUpperCase(),_84c,_845,_83a.user,_83a.password);
}
setHeaders(http,_83a);
try{
http.send(null);
}
catch(e){
if(typeof http.abort=="function"){
http.abort();
}
doLoad(_83a,{status:404},url,_83c,_847);
}
}
if(!_845){
doLoad(_83a,http,url,_83c,_847);
_81a._blockAsync=false;
}
_83a.abort=function(){
try{
http._aborted=true;
}
catch(e){
}
return http.abort();
};
return;
};
dojo.io.transports.addTransport("XMLHTTPTransport");
};
}
dojo.provide("dojo.io.cookie");
dojo.io.cookie.setCookie=function(name,_84e,days,path,_851,_852){
var _853=-1;
if((typeof days=="number")&&(days>=0)){
var d=new Date();
d.setTime(d.getTime()+(days*24*60*60*1000));
_853=d.toGMTString();
}
_84e=escape(_84e);
document.cookie=name+"="+_84e+";"+(_853!=-1?" expires="+_853+";":"")+(path?"path="+path:"")+(_851?"; domain="+_851:"")+(_852?"; secure":"");
};
dojo.io.cookie.set=dojo.io.cookie.setCookie;
dojo.io.cookie.getCookie=function(name){
var idx=document.cookie.lastIndexOf(name+"=");
if(idx==-1){
return null;
}
var _857=document.cookie.substring(idx+name.length+1);
var end=_857.indexOf(";");
if(end==-1){
end=_857.length;
}
_857=_857.substring(0,end);
_857=unescape(_857);
return _857;
};
dojo.io.cookie.get=dojo.io.cookie.getCookie;
dojo.io.cookie.deleteCookie=function(name){
dojo.io.cookie.setCookie(name,"-",0);
};
dojo.io.cookie.setObjectCookie=function(name,obj,days,path,_85e,_85f,_860){
if(arguments.length==5){
_860=_85e;
_85e=null;
_85f=null;
}
var _861=[],_862,_863="";
if(!_860){
_862=dojo.io.cookie.getObjectCookie(name);
}
if(days>=0){
if(!_862){
_862={};
}
for(var prop in obj){
if(obj[prop]==null){
delete _862[prop];
}else{
if((typeof obj[prop]=="string")||(typeof obj[prop]=="number")){
_862[prop]=obj[prop];
}
}
}
prop=null;
for(var prop in _862){
_861.push(escape(prop)+"="+escape(_862[prop]));
}
_863=_861.join("&");
}
dojo.io.cookie.setCookie(name,_863,days,path,_85e,_85f);
};
dojo.io.cookie.getObjectCookie=function(name){
var _866=null,_867=dojo.io.cookie.getCookie(name);
if(_867){
_866={};
var _868=_867.split("&");
for(var i=0;i<_868.length;i++){
var pair=_868[i].split("=");
var _86b=pair[1];
if(isNaN(_86b)){
_86b=unescape(pair[1]);
}
_866[unescape(pair[0])]=_86b;
}
}
return _866;
};
dojo.io.cookie.isSupported=function(){
if(typeof navigator.cookieEnabled!="boolean"){
dojo.io.cookie.setCookie("__TestingYourBrowserForCookieSupport__","CookiesAllowed",90,null);
var _86c=dojo.io.cookie.getCookie("__TestingYourBrowserForCookieSupport__");
navigator.cookieEnabled=(_86c=="CookiesAllowed");
if(navigator.cookieEnabled){
this.deleteCookie("__TestingYourBrowserForCookieSupport__");
}
}
return navigator.cookieEnabled;
};
if(!dojo.io.cookies){
dojo.io.cookies=dojo.io.cookie;
}
dojo.provide("dojo.io.*");
dojo.provide("dojo.widget.ContentPane");
dojo.widget.defineWidget("dojo.widget.ContentPane",dojo.widget.HtmlWidget,function(){
this._styleNodes=[];
this._onLoadStack=[];
this._onUnloadStack=[];
this._callOnUnload=false;
this._ioBindObj;
this.scriptScope;
this.bindArgs={};
},{isContainer:true,adjustPaths:true,href:"",extractContent:true,parseContent:true,cacheContent:true,preload:false,refreshOnShow:false,handler:"",executeScripts:false,scriptSeparation:true,loadingMessage:"Loading...",isLoaded:false,postCreate:function(args,frag,_86f){
if(this.handler!==""){
this.setHandler(this.handler);
}
if(this.isShowing()||this.preload){
this.loadContents();
}
},show:function(){
if(this.refreshOnShow){
this.refresh();
}else{
this.loadContents();
}
dojo.widget.ContentPane.superclass.show.call(this);
},refresh:function(){
this.isLoaded=false;
this.loadContents();
},loadContents:function(){
if(this.isLoaded){
return;
}
if(dojo.lang.isFunction(this.handler)){
this._runHandler();
}else{
if(this.href!=""){
this._downloadExternalContent(this.href,this.cacheContent&&!this.refreshOnShow);
}
}
},setUrl:function(url){
this.href=url;
this.isLoaded=false;
if(this.preload||this.isShowing()){
this.loadContents();
}
},abort:function(){
var bind=this._ioBindObj;
if(!bind||!bind.abort){
return;
}
bind.abort();
delete this._ioBindObj;
},_downloadExternalContent:function(url,_873){
this.abort();
this._handleDefaults(this.loadingMessage,"onDownloadStart");
var self=this;
this._ioBindObj=dojo.io.bind(this._cacheSetting({url:url,mimetype:"text/html",handler:function(type,data,xhr){
delete self._ioBindObj;
if(type=="load"){
self.onDownloadEnd.call(self,url,data);
}else{
var e={responseText:xhr.responseText,status:xhr.status,statusText:xhr.statusText,responseHeaders:xhr.getAllResponseHeaders(),text:"Error loading '"+url+"' ("+xhr.status+" "+xhr.statusText+")"};
self._handleDefaults.call(self,e,"onDownloadError");
self.onLoad();
}
}},_873));
},_cacheSetting:function(_879,_87a){
for(var x in this.bindArgs){
if(dojo.lang.isUndefined(_879[x])){
_879[x]=this.bindArgs[x];
}
}
if(dojo.lang.isUndefined(_879.useCache)){
_879.useCache=_87a;
}
if(dojo.lang.isUndefined(_879.preventCache)){
_879.preventCache=!_87a;
}
if(dojo.lang.isUndefined(_879.mimetype)){
_879.mimetype="text/html";
}
return _879;
},onLoad:function(e){
this._runStack("_onLoadStack");
this.isLoaded=true;
},onUnLoad:function(e){
dojo.deprecated(this.widgetType+".onUnLoad, use .onUnload (lowercased load)",0.5);
},onUnload:function(e){
this._runStack("_onUnloadStack");
delete this.scriptScope;
if(this.onUnLoad!==dojo.widget.ContentPane.prototype.onUnLoad){
this.onUnLoad.apply(this,arguments);
}
},_runStack:function(_87f){
var st=this[_87f];
var err="";
var _882=this.scriptScope||window;
for(var i=0;i<st.length;i++){
try{
st[i].call(_882);
}
catch(e){
err+="\n"+st[i]+" failed: "+e.description;
}
}
this[_87f]=[];
if(err.length){
var name=(_87f=="_onLoadStack")?"addOnLoad":"addOnUnLoad";
this._handleDefaults(name+" failure\n "+err,"onExecError","debug");
}
},addOnLoad:function(obj,func){
this._pushOnStack(this._onLoadStack,obj,func);
},addOnUnload:function(obj,func){
this._pushOnStack(this._onUnloadStack,obj,func);
},addOnUnLoad:function(){
dojo.deprecated(this.widgetType+".addOnUnLoad, use addOnUnload instead. (lowercased Load)",0.5);
this.addOnUnload.apply(this,arguments);
},_pushOnStack:function(_889,obj,func){
if(typeof func=="undefined"){
_889.push(obj);
}else{
_889.push(function(){
obj[func]();
});
}
},destroy:function(){
this.onUnload();
dojo.widget.ContentPane.superclass.destroy.call(this);
},onExecError:function(e){
},onContentError:function(e){
},onDownloadError:function(e){
},onDownloadStart:function(e){
},onDownloadEnd:function(url,data){
data=this.splitAndFixPaths(data,url);
this.setContent(data);
},_handleDefaults:function(e,_893,_894){
if(!_893){
_893="onContentError";
}
if(dojo.lang.isString(e)){
e={text:e};
}
if(!e.text){
e.text=e.toString();
}
e.toString=function(){
return this.text;
};
if(typeof e.returnValue!="boolean"){
e.returnValue=true;
}
if(typeof e.preventDefault!="function"){
e.preventDefault=function(){
this.returnValue=false;
};
}
this[_893](e);
if(e.returnValue){
switch(_894){
case true:
case "alert":
alert(e.toString());
break;
case "debug":
dojo.debug(e.toString());
break;
default:
if(this._callOnUnload){
this.onUnload();
}
this._callOnUnload=false;
if(arguments.callee._loopStop){
dojo.debug(e.toString());
}else{
arguments.callee._loopStop=true;
this._setContent(e.toString());
}
}
}
arguments.callee._loopStop=false;
},splitAndFixPaths:function(s,url){
var _897=[],_898=[],tmp=[];
var _89a=[],_89b=[],attr=[],_89d=[];
var str="",path="",fix="",_8a1="",tag="",_8a3="";
if(!url){
url="./";
}
if(s){
var _8a4=/<title[^>]*>([\s\S]*?)<\/title>/i;
while(_89a=_8a4.exec(s)){
_897.push(_89a[1]);
s=s.substring(0,_89a.index)+s.substr(_89a.index+_89a[0].length);
}
if(this.adjustPaths){
var _8a5=/<[a-z][a-z0-9]*[^>]*\s(?:(?:src|href|style)=[^>])+[^>]*>/i;
var _8a6=/\s(src|href|style)=(['"]?)([\w()\[\]\/.,\\'"-:;#=&?\s@]+?)\2/i;
var _8a7=/^(?:[#]|(?:(?:https?|ftps?|file|javascript|mailto|news):))/;
while(tag=_8a5.exec(s)){
str+=s.substring(0,tag.index);
s=s.substring((tag.index+tag[0].length),s.length);
tag=tag[0];
_8a1="";
while(attr=_8a6.exec(tag)){
path="";
_8a3=attr[3];
switch(attr[1].toLowerCase()){
case "src":
case "href":
if(_8a7.exec(_8a3)){
path=_8a3;
}else{
path=(new dojo.uri.Uri(url,_8a3).toString());
}
break;
case "style":
path=dojo.html.fixPathsInCssText(_8a3,url);
break;
default:
path=_8a3;
}
fix=" "+attr[1]+"="+attr[2]+path+attr[2];
_8a1+=tag.substring(0,attr.index)+fix;
tag=tag.substring((attr.index+attr[0].length),tag.length);
}
str+=_8a1+tag;
}
s=str+s;
}
_8a4=/(?:<(style)[^>]*>([\s\S]*?)<\/style>|<link ([^>]*rel=['"]?stylesheet['"]?[^>]*)>)/i;
while(_89a=_8a4.exec(s)){
if(_89a[1]&&_89a[1].toLowerCase()=="style"){
_89d.push(dojo.html.fixPathsInCssText(_89a[2],url));
}else{
if(attr=_89a[3].match(/href=(['"]?)([^'">]*)\1/i)){
_89d.push({path:attr[2]});
}
}
s=s.substring(0,_89a.index)+s.substr(_89a.index+_89a[0].length);
}
var _8a4=/<script([^>]*)>([\s\S]*?)<\/script>/i;
var _8a8=/src=(['"]?)([^"']*)\1/i;
var _8a9=/.*(\bdojo\b\.js(?:\.uncompressed\.js)?)$/;
var _8aa=/(?:var )?\bdjConfig\b(?:[\s]*=[\s]*\{[^}]+\}|\.[\w]*[\s]*=[\s]*[^;\n]*)?;?|dojo\.hostenv\.writeIncludes\(\s*\);?/g;
var _8ab=/dojo\.(?:(?:require(?:After)?(?:If)?)|(?:widget\.(?:manager\.)?registerWidgetPackage)|(?:(?:hostenv\.)?setModulePrefix|registerModulePath)|defineNamespace)\((['"]).*?\1\)\s*;?/;
while(_89a=_8a4.exec(s)){
if(this.executeScripts&&_89a[1]){
if(attr=_8a8.exec(_89a[1])){
if(_8a9.exec(attr[2])){
dojo.debug("Security note! inhibit:"+attr[2]+" from  being loaded again.");
}else{
_898.push({path:attr[2]});
}
}
}
if(_89a[2]){
var sc=_89a[2].replace(_8aa,"");
if(!sc){
continue;
}
while(tmp=_8ab.exec(sc)){
_89b.push(tmp[0]);
sc=sc.substring(0,tmp.index)+sc.substr(tmp.index+tmp[0].length);
}
if(this.executeScripts){
_898.push(sc);
}
}
s=s.substr(0,_89a.index)+s.substr(_89a.index+_89a[0].length);
}
if(this.extractContent){
_89a=s.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_89a){
s=_89a[1];
}
}
if(this.executeScripts&&this.scriptSeparation){
var _8a4=/(<[a-zA-Z][a-zA-Z0-9]*\s[^>]*?\S=)((['"])[^>]*scriptScope[^>]*>)/;
var _8ad=/([\s'";:\(])scriptScope(.*)/;
str="";
while(tag=_8a4.exec(s)){
tmp=((tag[3]=="'")?"\"":"'");
fix="";
str+=s.substring(0,tag.index)+tag[1];
while(attr=_8ad.exec(tag[2])){
tag[2]=tag[2].substring(0,attr.index)+attr[1]+"dojo.widget.byId("+tmp+this.widgetId+tmp+").scriptScope"+attr[2];
}
str+=tag[2];
s=s.substr(tag.index+tag[0].length);
}
s=str+s;
}
}
return {"xml":s,"styles":_89d,"titles":_897,"requires":_89b,"scripts":_898,"url":url};
},_setContent:function(cont){
this.destroyChildren();
for(var i=0;i<this._styleNodes.length;i++){
if(this._styleNodes[i]&&this._styleNodes[i].parentNode){
this._styleNodes[i].parentNode.removeChild(this._styleNodes[i]);
}
}
this._styleNodes=[];
try{
var node=this.containerNode||this.domNode;
while(node.firstChild){
dojo.html.destroyNode(node.firstChild);
}
if(typeof cont!="string"){
node.appendChild(cont);
}else{
node.innerHTML=cont;
}
}
catch(e){
e.text="Couldn't load content:"+e.description;
this._handleDefaults(e,"onContentError");
}
},setContent:function(data){
this.abort();
if(this._callOnUnload){
this.onUnload();
}
this._callOnUnload=true;
if(!data||dojo.html.isNode(data)){
this._setContent(data);
this.onResized();
this.onLoad();
}else{
if(typeof data.xml!="string"){
this.href="";
data=this.splitAndFixPaths(data);
}
this._setContent(data.xml);
for(var i=0;i<data.styles.length;i++){
if(data.styles[i].path){
this._styleNodes.push(dojo.html.insertCssFile(data.styles[i].path,dojo.doc(),false,true));
}else{
this._styleNodes.push(dojo.html.insertCssText(data.styles[i]));
}
}
if(this.parseContent){
for(var i=0;i<data.requires.length;i++){
try{
eval(data.requires[i]);
}
catch(e){
e.text="ContentPane: error in package loading calls, "+(e.description||e);
this._handleDefaults(e,"onContentError","debug");
}
}
}
var _8b3=this;
function asyncParse(){
if(_8b3.executeScripts){
_8b3._executeScripts(data.scripts);
}
if(_8b3.parseContent){
var node=_8b3.containerNode||_8b3.domNode;
var _8b5=new dojo.xml.Parse();
var frag=_8b5.parseElement(node,null,true);
dojo.widget.getParser().createSubComponents(frag,_8b3);
}
_8b3.onResized();
_8b3.onLoad();
}
if(dojo.hostenv.isXDomain&&data.requires.length){
dojo.addOnLoad(asyncParse);
}else{
asyncParse();
}
}
},setHandler:function(_8b7){
var fcn=dojo.lang.isFunction(_8b7)?_8b7:window[_8b7];
if(!dojo.lang.isFunction(fcn)){
this._handleDefaults("Unable to set handler, '"+_8b7+"' not a function.","onExecError",true);
return;
}
this.handler=function(){
return fcn.apply(this,arguments);
};
},_runHandler:function(){
var ret=true;
if(dojo.lang.isFunction(this.handler)){
this.handler(this,this.domNode);
ret=false;
}
this.onLoad();
return ret;
},_executeScripts:function(_8ba){
var self=this;
var tmp="",code="";
for(var i=0;i<_8ba.length;i++){
if(_8ba[i].path){
dojo.io.bind(this._cacheSetting({"url":_8ba[i].path,"load":function(type,_8c0){
dojo.lang.hitch(self,tmp=";"+_8c0);
},"error":function(type,_8c2){
_8c2.text=type+" downloading remote script";
self._handleDefaults.call(self,_8c2,"onExecError","debug");
},"mimetype":"text/plain","sync":true},this.cacheContent));
code+=tmp;
}else{
code+=_8ba[i];
}
}
try{
if(this.scriptSeparation){
delete this.scriptScope;
this.scriptScope=new (new Function("_container_",code+"; return this;"))(self);
}else{
var djg=dojo.global();
if(djg.execScript){
djg.execScript(code);
}else{
var djd=dojo.doc();
var sc=djd.createElement("script");
sc.appendChild(djd.createTextNode(code));
(this.containerNode||this.domNode).appendChild(sc);
}
}
}
catch(e){
e.text="Error running scripts from content:\n"+e.description;
this._handleDefaults(e,"onExecError","debug");
}
}});
dojo.provide("dojo.html.selection");
dojo.html.selectionType={NONE:0,TEXT:1,CONTROL:2};
dojo.html.clearSelection=function(){
var _8c6=dojo.global();
var _8c7=dojo.doc();
try{
if(_8c6["getSelection"]){
if(dojo.render.html.safari){
_8c6.getSelection().collapse();
}else{
_8c6.getSelection().removeAllRanges();
}
}else{
if(_8c7.selection){
if(_8c7.selection.empty){
_8c7.selection.empty();
}else{
if(_8c7.selection.clear){
_8c7.selection.clear();
}
}
}
}
return true;
}
catch(e){
dojo.debug(e);
return false;
}
};
dojo.html.disableSelection=function(_8c8){
_8c8=dojo.byId(_8c8)||dojo.body();
var h=dojo.render.html;
if(h.mozilla){
_8c8.style.MozUserSelect="none";
}else{
if(h.safari){
_8c8.style.KhtmlUserSelect="none";
}else{
if(h.ie){
_8c8.unselectable="on";
}else{
return false;
}
}
}
return true;
};
dojo.html.enableSelection=function(_8ca){
_8ca=dojo.byId(_8ca)||dojo.body();
var h=dojo.render.html;
if(h.mozilla){
_8ca.style.MozUserSelect="";
}else{
if(h.safari){
_8ca.style.KhtmlUserSelect="";
}else{
if(h.ie){
_8ca.unselectable="off";
}else{
return false;
}
}
}
return true;
};
dojo.html.selectElement=function(_8cc){
dojo.deprecated("dojo.html.selectElement","replaced by dojo.html.selection.selectElementChildren",0.5);
};
dojo.html.selectInputText=function(_8cd){
var _8ce=dojo.global();
var _8cf=dojo.doc();
_8cd=dojo.byId(_8cd);
if(_8cf["selection"]&&dojo.body()["createTextRange"]){
var _8d0=_8cd.createTextRange();
_8d0.moveStart("character",0);
_8d0.moveEnd("character",_8cd.value.length);
_8d0.select();
}else{
if(_8ce["getSelection"]){
var _8d1=_8ce.getSelection();
_8cd.setSelectionRange(0,_8cd.value.length);
}
}
_8cd.focus();
};
dojo.html.isSelectionCollapsed=function(){
dojo.deprecated("dojo.html.isSelectionCollapsed","replaced by dojo.html.selection.isCollapsed",0.5);
return dojo.html.selection.isCollapsed();
};
dojo.lang.mixin(dojo.html.selection,{getType:function(){
if(dojo.doc()["selection"]){
return dojo.html.selectionType[dojo.doc().selection.type.toUpperCase()];
}else{
var _8d2=dojo.html.selectionType.TEXT;
var oSel;
try{
oSel=dojo.global().getSelection();
}
catch(e){
}
if(oSel&&oSel.rangeCount==1){
var _8d4=oSel.getRangeAt(0);
if(_8d4.startContainer==_8d4.endContainer&&(_8d4.endOffset-_8d4.startOffset)==1&&_8d4.startContainer.nodeType!=dojo.dom.TEXT_NODE){
_8d2=dojo.html.selectionType.CONTROL;
}
}
return _8d2;
}
},isCollapsed:function(){
var _8d5=dojo.global();
var _8d6=dojo.doc();
if(_8d6["selection"]){
return _8d6.selection.createRange().text=="";
}else{
if(_8d5["getSelection"]){
var _8d7=_8d5.getSelection();
if(dojo.lang.isString(_8d7)){
return _8d7=="";
}else{
return _8d7.isCollapsed||_8d7.toString()=="";
}
}
}
},getSelectedElement:function(){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
if(dojo.doc()["selection"]){
var _8d8=dojo.doc().selection.createRange();
if(_8d8&&_8d8.item){
return dojo.doc().selection.createRange().item(0);
}
}else{
var _8d9=dojo.global().getSelection();
return _8d9.anchorNode.childNodes[_8d9.anchorOffset];
}
}
},getParentElement:function(){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
var p=dojo.html.selection.getSelectedElement();
if(p){
return p.parentNode;
}
}else{
if(dojo.doc()["selection"]){
return dojo.doc().selection.createRange().parentElement();
}else{
var _8db=dojo.global().getSelection();
if(_8db){
var node=_8db.anchorNode;
while(node&&node.nodeType!=dojo.dom.ELEMENT_NODE){
node=node.parentNode;
}
return node;
}
}
}
},getSelectedText:function(){
if(dojo.doc()["selection"]){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
return null;
}
return dojo.doc().selection.createRange().text;
}else{
var _8dd=dojo.global().getSelection();
if(_8dd){
return _8dd.toString();
}
}
},getSelectedHtml:function(){
if(dojo.doc()["selection"]){
if(dojo.html.selection.getType()==dojo.html.selectionType.CONTROL){
return null;
}
return dojo.doc().selection.createRange().htmlText;
}else{
var _8de=dojo.global().getSelection();
if(_8de&&_8de.rangeCount){
var frag=_8de.getRangeAt(0).cloneContents();
var div=document.createElement("div");
div.appendChild(frag);
return div.innerHTML;
}
return null;
}
},hasAncestorElement:function(_8e1){
return (dojo.html.selection.getAncestorElement.apply(this,arguments)!=null);
},getAncestorElement:function(_8e2){
var node=dojo.html.selection.getSelectedElement()||dojo.html.selection.getParentElement();
while(node){
if(dojo.html.selection.isTag(node,arguments).length>0){
return node;
}
node=node.parentNode;
}
return null;
},isTag:function(node,tags){
if(node&&node.tagName){
for(var i=0;i<tags.length;i++){
if(node.tagName.toLowerCase()==String(tags[i]).toLowerCase()){
return String(tags[i]).toLowerCase();
}
}
}
return "";
},selectElement:function(_8e7){
var _8e8=dojo.global();
var _8e9=dojo.doc();
_8e7=dojo.byId(_8e7);
if(_8e9.selection&&dojo.body().createTextRange){
try{
var _8ea=dojo.body().createControlRange();
_8ea.addElement(_8e7);
_8ea.select();
}
catch(e){
dojo.html.selection.selectElementChildren(_8e7);
}
}else{
if(_8e8["getSelection"]){
var _8eb=_8e8.getSelection();
if(_8eb["removeAllRanges"]){
var _8ea=_8e9.createRange();
_8ea.selectNode(_8e7);
_8eb.removeAllRanges();
_8eb.addRange(_8ea);
}
}
}
},selectElementChildren:function(_8ec){
var _8ed=dojo.global();
var _8ee=dojo.doc();
_8ec=dojo.byId(_8ec);
if(_8ee.selection&&dojo.body().createTextRange){
var _8ef=dojo.body().createTextRange();
_8ef.moveToElementText(_8ec);
_8ef.select();
}else{
if(_8ed["getSelection"]){
var _8f0=_8ed.getSelection();
if(_8f0["setBaseAndExtent"]){
_8f0.setBaseAndExtent(_8ec,0,_8ec,_8ec.innerText.length-1);
}else{
if(_8f0["selectAllChildren"]){
_8f0.selectAllChildren(_8ec);
}
}
}
}
},getBookmark:function(){
var _8f1;
var _8f2=dojo.doc();
if(_8f2["selection"]){
var _8f3=_8f2.selection.createRange();
_8f1=_8f3.getBookmark();
}else{
var _8f4;
try{
_8f4=dojo.global().getSelection();
}
catch(e){
}
if(_8f4){
var _8f3=_8f4.getRangeAt(0);
_8f1=_8f3.cloneRange();
}else{
dojo.debug("No idea how to store the current selection for this browser!");
}
}
return _8f1;
},moveToBookmark:function(_8f5){
var _8f6=dojo.doc();
if(_8f6["selection"]){
var _8f7=_8f6.selection.createRange();
_8f7.moveToBookmark(_8f5);
_8f7.select();
}else{
var _8f8;
try{
_8f8=dojo.global().getSelection();
}
catch(e){
}
if(_8f8&&_8f8["removeAllRanges"]){
_8f8.removeAllRanges();
_8f8.addRange(_8f5);
}else{
dojo.debug("No idea how to restore selection for this browser!");
}
}
},collapse:function(_8f9){
if(dojo.global()["getSelection"]){
var _8fa=dojo.global().getSelection();
if(_8fa.removeAllRanges){
if(_8f9){
_8fa.collapseToStart();
}else{
_8fa.collapseToEnd();
}
}else{
dojo.global().getSelection().collapse(_8f9);
}
}else{
if(dojo.doc().selection){
var _8fb=dojo.doc().selection.createRange();
_8fb.collapse(_8f9);
_8fb.select();
}
}
},remove:function(){
if(dojo.doc().selection){
var _8fc=dojo.doc().selection;
if(_8fc.type.toUpperCase()!="NONE"){
_8fc.clear();
}
return _8fc;
}else{
var _8fc=dojo.global().getSelection();
for(var i=0;i<_8fc.rangeCount;i++){
_8fc.getRangeAt(i).deleteContents();
}
return _8fc;
}
}});
dojo.provide("dojo.html.iframe");
dojo.html.iframeContentWindow=function(_8fe){
var win=dojo.html.getDocumentWindow(dojo.html.iframeContentDocument(_8fe))||dojo.html.iframeContentDocument(_8fe).__parent__||(_8fe.name&&document.frames[_8fe.name])||null;
return win;
};
dojo.html.iframeContentDocument=function(_900){
var doc=_900.contentDocument||((_900.contentWindow)&&(_900.contentWindow.document))||((_900.name)&&(document.frames[_900.name])&&(document.frames[_900.name].document))||null;
return doc;
};
dojo.html.BackgroundIframe=function(node){
if(dojo.render.html.ie55||dojo.render.html.ie60){
var html="<iframe src='javascript:false'"+" style='position: absolute; left: 0px; top: 0px; width: 100%; height: 100%;"+"z-index: -1; filter:Alpha(Opacity=\"0\");' "+">";
this.iframe=dojo.doc().createElement(html);
this.iframe.tabIndex=-1;
if(node){
node.appendChild(this.iframe);
this.domNode=node;
}else{
dojo.body().appendChild(this.iframe);
this.iframe.style.display="none";
}
}
};
dojo.lang.extend(dojo.html.BackgroundIframe,{iframe:null,onResized:function(){
if(this.iframe&&this.domNode&&this.domNode.parentNode){
var _904=dojo.html.getMarginBox(this.domNode);
if(_904.width==0||_904.height==0){
dojo.lang.setTimeout(this,this.onResized,100);
return;
}
this.iframe.style.width=_904.width+"px";
this.iframe.style.height=_904.height+"px";
}
},size:function(node){
if(!this.iframe){
return;
}
var _906=dojo.html.toCoordinateObject(node,true,dojo.html.boxSizing.BORDER_BOX);
with(this.iframe.style){
width=_906.width+"px";
height=_906.height+"px";
left=_906.left+"px";
top=_906.top+"px";
}
},setZIndex:function(node){
if(!this.iframe){
return;
}
if(dojo.dom.isNode(node)){
this.iframe.style.zIndex=dojo.html.getStyle(node,"z-index")-1;
}else{
if(!isNaN(node)){
this.iframe.style.zIndex=node;
}
}
},show:function(){
if(this.iframe){
this.iframe.style.display="block";
}
},hide:function(){
if(this.iframe){
this.iframe.style.display="none";
}
},remove:function(){
if(this.iframe){
dojo.html.removeNode(this.iframe,true);
delete this.iframe;
this.iframe=null;
}
}});
dojo.provide("dojo.widget.PopupContainer");
dojo.declare("dojo.widget.PopupContainerBase",null,function(){
this.queueOnAnimationFinish=[];
},{isContainer:true,templateString:"<div dojoAttachPoint=\"containerNode\" style=\"display:none;position:absolute;\" class=\"dojoPopupContainer\" ></div>",isShowingNow:false,currentSubpopup:null,beginZIndex:1000,parentPopup:null,parent:null,popupIndex:0,aroundBox:dojo.html.boxSizing.BORDER_BOX,openedForWindow:null,processKey:function(evt){
return false;
},applyPopupBasicStyle:function(){
with(this.domNode.style){
display="none";
position="absolute";
}
},aboutToShow:function(){
},open:function(x,y,_90b,_90c,_90d,_90e){
if(this.isShowingNow){
return;
}
if(this.animationInProgress){
this.queueOnAnimationFinish.push(this.open,arguments);
return;
}
this.aboutToShow();
var _90f=false,node,_911;
if(typeof x=="object"){
node=x;
_911=_90c;
_90c=_90b;
_90b=y;
_90f=true;
}
this.parent=_90b;
dojo.body().appendChild(this.domNode);
_90c=_90c||_90b["domNode"]||[];
var _912=null;
this.isTopLevel=true;
while(_90b){
if(_90b!==this&&(_90b.setOpenedSubpopup!=undefined&&_90b.applyPopupBasicStyle!=undefined)){
_912=_90b;
this.isTopLevel=false;
_912.setOpenedSubpopup(this);
break;
}
_90b=_90b.parent;
}
this.parentPopup=_912;
this.popupIndex=_912?_912.popupIndex+1:1;
if(this.isTopLevel){
var _913=dojo.html.isNode(_90c)?_90c:null;
dojo.widget.PopupManager.opened(this,_913);
}
if(this.isTopLevel&&!dojo.withGlobal(this.openedForWindow||dojo.global(),dojo.html.selection.isCollapsed)){
this._bookmark=dojo.withGlobal(this.openedForWindow||dojo.global(),dojo.html.selection.getBookmark);
}else{
this._bookmark=null;
}
if(_90c instanceof Array){
_90c={left:_90c[0],top:_90c[1],width:0,height:0};
}
with(this.domNode.style){
display="";
zIndex=this.beginZIndex+this.popupIndex;
}
if(_90f){
this.move(node,_90e,_911);
}else{
this.move(x,y,_90e,_90d);
}
this.domNode.style.display="none";
this.explodeSrc=_90c;
this.show();
this.isShowingNow=true;
},move:function(x,y,_916,_917){
var _918=(typeof x=="object");
if(_918){
var _919=_916;
var node=x;
_916=y;
if(!_919){
_919={"BL":"TL","TL":"BL"};
}
dojo.html.placeOnScreenAroundElement(this.domNode,node,_916,this.aroundBox,_919);
}else{
if(!_917){
_917="TL,TR,BL,BR";
}
dojo.html.placeOnScreen(this.domNode,x,y,_916,true,_917);
}
},close:function(_91b){
if(_91b){
this.domNode.style.display="none";
}
if(this.animationInProgress){
this.queueOnAnimationFinish.push(this.close,[]);
return;
}
this.closeSubpopup(_91b);
this.hide();
if(this.bgIframe){
this.bgIframe.hide();
this.bgIframe.size({left:0,top:0,width:0,height:0});
}
if(this.isTopLevel){
dojo.widget.PopupManager.closed(this);
}
this.isShowingNow=false;
if(this.parent){
setTimeout(dojo.lang.hitch(this,function(){
try{
if(this.parent["focus"]){
this.parent.focus();
}else{
this.parent.domNode.focus();
}
}
catch(e){
dojo.debug("No idea how to focus to parent",e);
}
}),10);
}
if(this._bookmark&&dojo.withGlobal(this.openedForWindow||dojo.global(),dojo.html.selection.isCollapsed)){
if(this.openedForWindow){
this.openedForWindow.focus();
}
try{
dojo.withGlobal(this.openedForWindow||dojo.global(),"moveToBookmark",dojo.html.selection,[this._bookmark]);
}
catch(e){
}
}
this._bookmark=null;
},closeAll:function(_91c){
if(this.parentPopup){
this.parentPopup.closeAll(_91c);
}else{
this.close(_91c);
}
},setOpenedSubpopup:function(_91d){
this.currentSubpopup=_91d;
},closeSubpopup:function(_91e){
if(this.currentSubpopup==null){
return;
}
this.currentSubpopup.close(_91e);
this.currentSubpopup=null;
},onShow:function(){
dojo.widget.PopupContainer.superclass.onShow.apply(this,arguments);
this.openedSize={w:this.domNode.style.width,h:this.domNode.style.height};
if(dojo.render.html.ie){
if(!this.bgIframe){
this.bgIframe=new dojo.html.BackgroundIframe();
this.bgIframe.setZIndex(this.domNode);
}
this.bgIframe.size(this.domNode);
this.bgIframe.show();
}
this.processQueue();
},processQueue:function(){
if(!this.queueOnAnimationFinish.length){
return;
}
var func=this.queueOnAnimationFinish.shift();
var args=this.queueOnAnimationFinish.shift();
func.apply(this,args);
},onHide:function(){
dojo.widget.HtmlWidget.prototype.onHide.call(this);
if(this.openedSize){
with(this.domNode.style){
width=this.openedSize.w;
height=this.openedSize.h;
}
}
this.processQueue();
}});
dojo.widget.defineWidget("dojo.widget.PopupContainer",[dojo.widget.HtmlWidget,dojo.widget.PopupContainerBase],{});
dojo.widget.PopupManager=new function(){
this.currentMenu=null;
this.currentButton=null;
this.currentFocusMenu=null;
this.focusNode=null;
this.registeredWindows=[];
this.registerWin=function(win){
if(!win.__PopupManagerRegistered){
dojo.event.connect(win.document,"onmousedown",this,"onClick");
dojo.event.connect(win,"onscroll",this,"onClick");
dojo.event.connect(win.document,"onkey",this,"onKey");
win.__PopupManagerRegistered=true;
this.registeredWindows.push(win);
}
};
this.registerAllWindows=function(_922){
if(!_922){
_922=dojo.html.getDocumentWindow(window.top&&window.top.document||window.document);
}
this.registerWin(_922);
for(var i=0;i<_922.frames.length;i++){
try{
var win=dojo.html.getDocumentWindow(_922.frames[i].document);
if(win){
this.registerAllWindows(win);
}
}
catch(e){
}
}
};
this.unRegisterWin=function(win){
try{
if(win.__PopupManagerRegistered){
dojo.event.disconnect(win.document,"onmousedown",this,"onClick");
dojo.event.disconnect(win,"onscroll",this,"onClick");
dojo.event.disconnect(win.document,"onkey",this,"onKey");
win.__PopupManagerRegistered=false;
}
}
catch(e){
}
};
this.unRegisterAllWindows=function(){
for(var i=0;i<this.registeredWindows.length;++i){
this.unRegisterWin(this.registeredWindows[i]);
}
this.registeredWindows=[];
};
dojo.addOnLoad(this,"registerAllWindows");
dojo.addOnUnload(this,"unRegisterAllWindows");
this.closed=function(menu){
if(this.currentMenu==menu){
this.currentMenu=null;
this.currentButton=null;
this.currentFocusMenu=null;
}
};
this.opened=function(menu,_929){
if(menu==this.currentMenu){
return;
}
if(this.currentMenu){
this.currentMenu.close();
}
this.currentMenu=menu;
this.currentFocusMenu=menu;
this.currentButton=_929;
};
this.setFocusedMenu=function(menu){
this.currentFocusMenu=menu;
};
this.onKey=function(e){
if(!e.key){
return;
}
if(!this.currentMenu||!this.currentMenu.isShowingNow){
return;
}
var m=this.currentFocusMenu;
while(m){
if(m.processKey(e)){
e.preventDefault();
e.stopPropagation();
break;
}
m=m.parentPopup;
}
},this.onClick=function(e){
if(!this.currentMenu){
return;
}
var _92e=dojo.html.getScroll().offset;
var m=this.currentMenu;
while(m){
if(dojo.html.overElement(m.domNode,e)||dojo.html.isDescendantOf(e.target,m.domNode)){
return;
}
m=m.currentSubpopup;
}
if(this.currentButton&&dojo.html.overElement(this.currentButton,e)){
return;
}
this.currentMenu.close();
};
};
dojo.provide("dojo.widget.Tooltip");
dojo.widget.defineWidget("dojo.widget.Tooltip",[dojo.widget.ContentPane,dojo.widget.PopupContainerBase],{caption:"",showDelay:500,hideDelay:100,connectId:"",templateCssPath:dojo.uri.dojoUri("src/widget/templates/TooltipTemplate.css"),fillInTemplate:function(args,frag){
if(this.caption!=""){
this.domNode.appendChild(document.createTextNode(this.caption));
}
this._connectNode=dojo.byId(this.connectId);
dojo.widget.Tooltip.superclass.fillInTemplate.call(this,args,frag);
this.addOnLoad(this,"_loadedContent");
dojo.html.addClass(this.domNode,"dojoTooltip");
var _932=this.getFragNodeRef(frag);
dojo.html.copyStyle(this.domNode,_932);
this.applyPopupBasicStyle();
},postCreate:function(args,frag){
dojo.event.connect(this._connectNode,"onmouseover",this,"_onMouseOver");
dojo.widget.Tooltip.superclass.postCreate.call(this,args,frag);
},_onMouseOver:function(e){
this._mouse={x:e.pageX,y:e.pageY};
if(!this._tracking){
dojo.event.connect(document.documentElement,"onmousemove",this,"_onMouseMove");
this._tracking=true;
}
this._onHover(e);
},_onMouseMove:function(e){
this._mouse={x:e.pageX,y:e.pageY};
if(dojo.html.overElement(this._connectNode,e)||dojo.html.overElement(this.domNode,e)){
this._onHover(e);
}else{
this._onUnHover(e);
}
},_onHover:function(e){
if(this._hover){
return;
}
this._hover=true;
if(this._hideTimer){
clearTimeout(this._hideTimer);
delete this._hideTimer;
}
if(!this.isShowingNow&&!this._showTimer){
this._showTimer=setTimeout(dojo.lang.hitch(this,"open"),this.showDelay);
}
},_onUnHover:function(e){
if(!this._hover){
return;
}
this._hover=false;
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
if(this.isShowingNow&&!this._hideTimer){
this._hideTimer=setTimeout(dojo.lang.hitch(this,"close"),this.hideDelay);
}
if(!this.isShowingNow){
dojo.event.disconnect(document.documentElement,"onmousemove",this,"_onMouseMove");
this._tracking=false;
}
},open:function(){
if(this.isShowingNow){
return;
}
dojo.widget.PopupContainerBase.prototype.open.call(this,this._mouse.x,this._mouse.y,null,[this._mouse.x,this._mouse.y],"TL,TR,BL,BR",[10,15]);
},close:function(){
if(this.isShowingNow){
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
if(this._hideTimer){
clearTimeout(this._hideTimer);
delete this._hideTimer;
}
dojo.event.disconnect(document.documentElement,"onmousemove",this,"_onMouseMove");
this._tracking=false;
dojo.widget.PopupContainerBase.prototype.close.call(this);
}
},_position:function(){
this.move(this._mouse.x,this._mouse.y,[10,15],"TL,TR,BL,BR");
},_loadedContent:function(){
if(this.isShowingNow){
this._position();
}
},checkSize:function(){
},uninitialize:function(){
this.close();
dojo.event.disconnect(this._connectNode,"onmouseover",this,"_onMouseOver");
}});
dojo.provide("dojo.date.common");
dojo.date.setDayOfYear=function(_939,_93a){
_939.setMonth(0);
_939.setDate(_93a);
return _939;
};
dojo.date.getDayOfYear=function(_93b){
var _93c=_93b.getFullYear();
var _93d=new Date(_93c-1,11,31);
return Math.floor((_93b.getTime()-_93d.getTime())/86400000);
};
dojo.date.setWeekOfYear=function(_93e,week,_940){
if(arguments.length==1){
_940=0;
}
dojo.unimplemented("dojo.date.setWeekOfYear");
};
dojo.date.getWeekOfYear=function(_941,_942){
if(arguments.length==1){
_942=0;
}
var _943=new Date(_941.getFullYear(),0,1);
var day=_943.getDay();
_943.setDate(_943.getDate()-day+_942-(day>_942?7:0));
return Math.floor((_941.getTime()-_943.getTime())/604800000);
};
dojo.date.setIsoWeekOfYear=function(_945,week,_947){
if(arguments.length==1){
_947=1;
}
dojo.unimplemented("dojo.date.setIsoWeekOfYear");
};
dojo.date.getIsoWeekOfYear=function(_948,_949){
if(arguments.length==1){
_949=1;
}
dojo.unimplemented("dojo.date.getIsoWeekOfYear");
};
dojo.date.shortTimezones=["IDLW","BET","HST","MART","AKST","PST","MST","CST","EST","AST","NFT","BST","FST","AT","GMT","CET","EET","MSK","IRT","GST","AFT","AGTT","IST","NPT","ALMT","MMT","JT","AWST","JST","ACST","AEST","LHST","VUT","NFT","NZT","CHAST","PHOT","LINT"];
dojo.date.timezoneOffsets=[-720,-660,-600,-570,-540,-480,-420,-360,-300,-240,-210,-180,-120,-60,0,60,120,180,210,240,270,300,330,345,360,390,420,480,540,570,600,630,660,690,720,765,780,840];
dojo.date.getDaysInMonth=function(_94a){
var _94b=_94a.getMonth();
var days=[31,28,31,30,31,30,31,31,30,31,30,31];
if(_94b==1&&dojo.date.isLeapYear(_94a)){
return 29;
}else{
return days[_94b];
}
};
dojo.date.isLeapYear=function(_94d){
var year=_94d.getFullYear();
return (year%400==0)?true:(year%100==0)?false:(year%4==0)?true:false;
};
dojo.date.getTimezoneName=function(_94f){
var str=_94f.toString();
var tz="";
var _952;
var pos=str.indexOf("(");
if(pos>-1){
pos++;
tz=str.substring(pos,str.indexOf(")"));
}else{
var pat=/([A-Z\/]+) \d{4}$/;
if((_952=str.match(pat))){
tz=_952[1];
}else{
str=_94f.toLocaleString();
pat=/ ([A-Z\/]+)$/;
if((_952=str.match(pat))){
tz=_952[1];
}
}
}
return tz=="AM"||tz=="PM"?"":tz;
};
dojo.date.getOrdinal=function(_955){
var date=_955.getDate();
if(date%100!=11&&date%10==1){
return "st";
}else{
if(date%100!=12&&date%10==2){
return "nd";
}else{
if(date%100!=13&&date%10==3){
return "rd";
}else{
return "th";
}
}
}
};
dojo.date.compareTypes={DATE:1,TIME:2};
dojo.date.compare=function(_957,_958,_959){
var dA=_957;
var dB=_958||new Date();
var now=new Date();
with(dojo.date.compareTypes){
var opt=_959||(DATE|TIME);
var d1=new Date((opt&DATE)?dA.getFullYear():now.getFullYear(),(opt&DATE)?dA.getMonth():now.getMonth(),(opt&DATE)?dA.getDate():now.getDate(),(opt&TIME)?dA.getHours():0,(opt&TIME)?dA.getMinutes():0,(opt&TIME)?dA.getSeconds():0);
var d2=new Date((opt&DATE)?dB.getFullYear():now.getFullYear(),(opt&DATE)?dB.getMonth():now.getMonth(),(opt&DATE)?dB.getDate():now.getDate(),(opt&TIME)?dB.getHours():0,(opt&TIME)?dB.getMinutes():0,(opt&TIME)?dB.getSeconds():0);
}
if(d1.valueOf()>d2.valueOf()){
return 1;
}
if(d1.valueOf()<d2.valueOf()){
return -1;
}
return 0;
};
dojo.date.dateParts={YEAR:0,MONTH:1,DAY:2,HOUR:3,MINUTE:4,SECOND:5,MILLISECOND:6,QUARTER:7,WEEK:8,WEEKDAY:9};
dojo.date.add=function(dt,_961,incr){
if(typeof dt=="number"){
dt=new Date(dt);
}
function fixOvershoot(){
if(sum.getDate()<dt.getDate()){
sum.setDate(0);
}
}
var sum=new Date(dt);
with(dojo.date.dateParts){
switch(_961){
case YEAR:
sum.setFullYear(dt.getFullYear()+incr);
fixOvershoot();
break;
case QUARTER:
incr*=3;
case MONTH:
sum.setMonth(dt.getMonth()+incr);
fixOvershoot();
break;
case WEEK:
incr*=7;
case DAY:
sum.setDate(dt.getDate()+incr);
break;
case WEEKDAY:
var dat=dt.getDate();
var _965=0;
var days=0;
var strt=0;
var trgt=0;
var adj=0;
var mod=incr%5;
if(mod==0){
days=(incr>0)?5:-5;
_965=(incr>0)?((incr-5)/5):((incr+5)/5);
}else{
days=mod;
_965=parseInt(incr/5);
}
strt=dt.getDay();
if(strt==6&&incr>0){
adj=1;
}else{
if(strt==0&&incr<0){
adj=-1;
}
}
trgt=(strt+days);
if(trgt==0||trgt==6){
adj=(incr>0)?2:-2;
}
sum.setDate(dat+(7*_965)+days+adj);
break;
case HOUR:
sum.setHours(sum.getHours()+incr);
break;
case MINUTE:
sum.setMinutes(sum.getMinutes()+incr);
break;
case SECOND:
sum.setSeconds(sum.getSeconds()+incr);
break;
case MILLISECOND:
sum.setMilliseconds(sum.getMilliseconds()+incr);
break;
default:
break;
}
}
return sum;
};
dojo.date.diff=function(dtA,dtB,_96d){
if(typeof dtA=="number"){
dtA=new Date(dtA);
}
if(typeof dtB=="number"){
dtB=new Date(dtB);
}
var _96e=dtB.getFullYear()-dtA.getFullYear();
var _96f=(dtB.getMonth()-dtA.getMonth())+(_96e*12);
var _970=dtB.getTime()-dtA.getTime();
var _971=_970/1000;
var _972=_971/60;
var _973=_972/60;
var _974=_973/24;
var _975=_974/7;
var _976=0;
with(dojo.date.dateParts){
switch(_96d){
case YEAR:
_976=_96e;
break;
case QUARTER:
var mA=dtA.getMonth();
var mB=dtB.getMonth();
var qA=Math.floor(mA/3)+1;
var qB=Math.floor(mB/3)+1;
qB+=(_96e*4);
_976=qB-qA;
break;
case MONTH:
_976=_96f;
break;
case WEEK:
_976=parseInt(_975);
break;
case DAY:
_976=_974;
break;
case WEEKDAY:
var days=Math.round(_974);
var _97c=parseInt(days/7);
var mod=days%7;
if(mod==0){
days=_97c*5;
}else{
var adj=0;
var aDay=dtA.getDay();
var bDay=dtB.getDay();
_97c=parseInt(days/7);
mod=days%7;
var _981=new Date(dtA);
_981.setDate(_981.getDate()+(_97c*7));
var _982=_981.getDay();
if(_974>0){
switch(true){
case aDay==6:
adj=-1;
break;
case aDay==0:
adj=0;
break;
case bDay==6:
adj=-1;
break;
case bDay==0:
adj=-2;
break;
case (_982+mod)>5:
adj=-2;
break;
default:
break;
}
}else{
if(_974<0){
switch(true){
case aDay==6:
adj=0;
break;
case aDay==0:
adj=1;
break;
case bDay==6:
adj=2;
break;
case bDay==0:
adj=1;
break;
case (_982+mod)<0:
adj=2;
break;
default:
break;
}
}
}
days+=adj;
days-=(_97c*2);
}
_976=days;
break;
case HOUR:
_976=_973;
break;
case MINUTE:
_976=_972;
break;
case SECOND:
_976=_971;
break;
case MILLISECOND:
_976=_970;
break;
default:
break;
}
}
return Math.round(_976);
};
dojo.provide("dojo.date.supplemental");
dojo.date.getFirstDayOfWeek=function(_983){
var _984={mv:5,ae:6,af:6,bh:6,dj:6,dz:6,eg:6,er:6,et:6,iq:6,ir:6,jo:6,ke:6,kw:6,lb:6,ly:6,ma:6,om:6,qa:6,sa:6,sd:6,so:6,tn:6,ye:6,as:0,au:0,az:0,bw:0,ca:0,cn:0,fo:0,ge:0,gl:0,gu:0,hk:0,ie:0,il:0,is:0,jm:0,jp:0,kg:0,kr:0,la:0,mh:0,mo:0,mp:0,mt:0,nz:0,ph:0,pk:0,sg:0,th:0,tt:0,tw:0,um:0,us:0,uz:0,vi:0,za:0,zw:0,et:0,mw:0,ng:0,tj:0,gb:0,sy:4};
_983=dojo.hostenv.normalizeLocale(_983);
var _985=_983.split("-")[1];
var dow=_984[_985];
return (typeof dow=="undefined")?1:dow;
};
dojo.date.getWeekend=function(_987){
var _988={eg:5,il:5,sy:5,"in":0,ae:4,bh:4,dz:4,iq:4,jo:4,kw:4,lb:4,ly:4,ma:4,om:4,qa:4,sa:4,sd:4,tn:4,ye:4};
var _989={ae:5,bh:5,dz:5,iq:5,jo:5,kw:5,lb:5,ly:5,ma:5,om:5,qa:5,sa:5,sd:5,tn:5,ye:5,af:5,ir:5,eg:6,il:6,sy:6};
_987=dojo.hostenv.normalizeLocale(_987);
var _98a=_987.split("-")[1];
var _98b=_988[_98a];
var end=_989[_98a];
if(typeof _98b=="undefined"){
_98b=6;
}
if(typeof end=="undefined"){
end=0;
}
return {start:_98b,end:end};
};
dojo.date.isWeekend=function(_98d,_98e){
var _98f=dojo.date.getWeekend(_98e);
var day=(_98d||new Date()).getDay();
if(_98f.end<_98f.start){
_98f.end+=7;
if(day<_98f.start){
day+=7;
}
}
return day>=_98f.start&&day<=_98f.end;
};
dojo.provide("dojo.i18n.common");
dojo.i18n.getLocalization=function(_991,_992,_993){
dojo.hostenv.preloadLocalizations();
_993=dojo.hostenv.normalizeLocale(_993);
var _994=_993.split("-");
var _995=[_991,"nls",_992].join(".");
var _996=dojo.hostenv.findModule(_995,true);
var _997;
for(var i=_994.length;i>0;i--){
var loc=_994.slice(0,i).join("_");
if(_996[loc]){
_997=_996[loc];
break;
}
}
if(!_997){
_997=_996.ROOT;
}
if(_997){
var _99a=function(){
};
_99a.prototype=_997;
return new _99a();
}
dojo.raise("Bundle not found: "+_992+" in "+_991+" , locale="+_993);
};
dojo.i18n.isLTR=function(_99b){
var lang=dojo.hostenv.normalizeLocale(_99b).split("-")[0];
var RTL={ar:true,fa:true,he:true,ur:true,yi:true};
return !RTL[lang];
};
dojo.provide("dojo.date.format");
(function(){
dojo.date.format=function(_99e,_99f){
if(typeof _99f=="string"){
dojo.deprecated("dojo.date.format","To format dates with POSIX-style strings, please use dojo.date.strftime instead","0.5");
return dojo.date.strftime(_99e,_99f);
}
function formatPattern(_9a0,_9a1){
return _9a1.replace(/([a-z])\1*/ig,function(_9a2){
var s;
var c=_9a2.charAt(0);
var l=_9a2.length;
var pad;
var _9a7=["abbr","wide","narrow"];
switch(c){
case "G":
if(l>3){
dojo.unimplemented("Era format not implemented");
}
s=info.eras[_9a0.getFullYear()<0?1:0];
break;
case "y":
s=_9a0.getFullYear();
switch(l){
case 1:
break;
case 2:
s=String(s).substr(-2);
break;
default:
pad=true;
}
break;
case "Q":
case "q":
s=Math.ceil((_9a0.getMonth()+1)/3);
switch(l){
case 1:
case 2:
pad=true;
break;
case 3:
case 4:
dojo.unimplemented("Quarter format not implemented");
}
break;
case "M":
case "L":
var m=_9a0.getMonth();
var _9aa;
switch(l){
case 1:
case 2:
s=m+1;
pad=true;
break;
case 3:
case 4:
case 5:
_9aa=_9a7[l-3];
break;
}
if(_9aa){
var type=(c=="L")?"standalone":"format";
var prop=["months",type,_9aa].join("-");
s=info[prop][m];
}
break;
case "w":
var _9ad=0;
s=dojo.date.getWeekOfYear(_9a0,_9ad);
pad=true;
break;
case "d":
s=_9a0.getDate();
pad=true;
break;
case "D":
s=dojo.date.getDayOfYear(_9a0);
pad=true;
break;
case "E":
case "e":
case "c":
var d=_9a0.getDay();
var _9aa;
switch(l){
case 1:
case 2:
if(c=="e"){
var _9af=dojo.date.getFirstDayOfWeek(_99f.locale);
d=(d-_9af+7)%7;
}
if(c!="c"){
s=d+1;
pad=true;
break;
}
case 3:
case 4:
case 5:
_9aa=_9a7[l-3];
break;
}
if(_9aa){
var type=(c=="c")?"standalone":"format";
var prop=["days",type,_9aa].join("-");
s=info[prop][d];
}
break;
case "a":
var _9b0=(_9a0.getHours()<12)?"am":"pm";
s=info[_9b0];
break;
case "h":
case "H":
case "K":
case "k":
var h=_9a0.getHours();
switch(c){
case "h":
s=(h%12)||12;
break;
case "H":
s=h;
break;
case "K":
s=(h%12);
break;
case "k":
s=h||24;
break;
}
pad=true;
break;
case "m":
s=_9a0.getMinutes();
pad=true;
break;
case "s":
s=_9a0.getSeconds();
pad=true;
break;
case "S":
s=Math.round(_9a0.getMilliseconds()*Math.pow(10,l-3));
break;
case "v":
case "z":
s=dojo.date.getTimezoneName(_9a0);
if(s){
break;
}
l=4;
case "Z":
var _9b2=_9a0.getTimezoneOffset();
var tz=[(_9b2<=0?"+":"-"),dojo.string.pad(Math.floor(Math.abs(_9b2)/60),2),dojo.string.pad(Math.abs(_9b2)%60,2)];
if(l==4){
tz.splice(0,0,"GMT");
tz.splice(3,0,":");
}
s=tz.join("");
break;
case "Y":
case "u":
case "W":
case "F":
case "g":
case "A":
dojo.debug(_9a2+" modifier not yet implemented");
s="?";
break;
default:
dojo.raise("dojo.date.format: invalid pattern char: "+_9a1);
}
if(pad){
s=dojo.string.pad(s,l);
}
return s;
});
}
_99f=_99f||{};
var _9b4=dojo.hostenv.normalizeLocale(_99f.locale);
var _9b5=_99f.formatLength||"full";
var info=dojo.date._getGregorianBundle(_9b4);
var str=[];
var _9b7=dojo.lang.curry(this,formatPattern,_99e);
if(_99f.selector!="timeOnly"){
var _9b8=_99f.datePattern||info["dateFormat-"+_9b5];
if(_9b8){
str.push(_processPattern(_9b8,_9b7));
}
}
if(_99f.selector!="dateOnly"){
var _9b9=_99f.timePattern||info["timeFormat-"+_9b5];
if(_9b9){
str.push(_processPattern(_9b9,_9b7));
}
}
var _9ba=str.join(" ");
return _9ba;
};
dojo.date.parse=function(_9bb,_9bc){
_9bc=_9bc||{};
var _9bd=dojo.hostenv.normalizeLocale(_9bc.locale);
var info=dojo.date._getGregorianBundle(_9bd);
var _9bf=_9bc.formatLength||"full";
if(!_9bc.selector){
_9bc.selector="dateOnly";
}
var _9c0=_9bc.datePattern||info["dateFormat-"+_9bf];
var _9c1=_9bc.timePattern||info["timeFormat-"+_9bf];
var _9c2;
if(_9bc.selector=="dateOnly"){
_9c2=_9c0;
}else{
if(_9bc.selector=="timeOnly"){
_9c2=_9c1;
}else{
if(_9bc.selector=="dateTime"){
_9c2=_9c0+" "+_9c1;
}else{
var msg="dojo.date.parse: Unknown selector param passed: '"+_9bc.selector+"'.";
msg+=" Defaulting to date pattern.";
dojo.debug(msg);
_9c2=_9c0;
}
}
}
var _9c4=[];
var _9c5=_processPattern(_9c2,dojo.lang.curry(this,_buildDateTimeRE,_9c4,info,_9bc));
var _9c6=new RegExp("^"+_9c5+"$");
var _9c7=_9c6.exec(_9bb);
if(!_9c7){
return null;
}
var _9c8=["abbr","wide","narrow"];
var _9c9=new Date(1972,0);
var _9ca={};
for(var i=1;i<_9c7.length;i++){
var grp=_9c4[i-1];
var l=grp.length;
var v=_9c7[i];
switch(grp.charAt(0)){
case "y":
if(l!=2){
_9c9.setFullYear(v);
_9ca.year=v;
}else{
if(v<100){
v=Number(v);
var year=""+new Date().getFullYear();
var _9d0=year.substring(0,2)*100;
var _9d1=Number(year.substring(2,4));
var _9d2=Math.min(_9d1+20,99);
var num=(v<_9d2)?_9d0+v:_9d0-100+v;
_9c9.setFullYear(num);
_9ca.year=num;
}else{
if(_9bc.strict){
return null;
}
_9c9.setFullYear(v);
_9ca.year=v;
}
}
break;
case "M":
if(l>2){
if(!_9bc.strict){
v=v.replace(/\./g,"");
v=v.toLowerCase();
}
var _9d4=info["months-format-"+_9c8[l-3]].concat();
for(var j=0;j<_9d4.length;j++){
if(!_9bc.strict){
_9d4[j]=_9d4[j].toLowerCase();
}
if(v==_9d4[j]){
_9c9.setMonth(j);
_9ca.month=j;
break;
}
}
if(j==_9d4.length){
dojo.debug("dojo.date.parse: Could not parse month name: '"+v+"'.");
return null;
}
}else{
_9c9.setMonth(v-1);
_9ca.month=v-1;
}
break;
case "E":
case "e":
if(!_9bc.strict){
v=v.toLowerCase();
}
var days=info["days-format-"+_9c8[l-3]].concat();
for(var j=0;j<days.length;j++){
if(!_9bc.strict){
days[j]=days[j].toLowerCase();
}
if(v==days[j]){
break;
}
}
if(j==days.length){
dojo.debug("dojo.date.parse: Could not parse weekday name: '"+v+"'.");
return null;
}
break;
case "d":
_9c9.setDate(v);
_9ca.date=v;
break;
case "a":
var am=_9bc.am||info.am;
var pm=_9bc.pm||info.pm;
if(!_9bc.strict){
v=v.replace(/\./g,"").toLowerCase();
am=am.replace(/\./g,"").toLowerCase();
pm=pm.replace(/\./g,"").toLowerCase();
}
if(_9bc.strict&&v!=am&&v!=pm){
dojo.debug("dojo.date.parse: Could not parse am/pm part.");
return null;
}
var _9d9=_9c9.getHours();
if(v==pm&&_9d9<12){
_9c9.setHours(_9d9+12);
}else{
if(v==am&&_9d9==12){
_9c9.setHours(0);
}
}
break;
case "K":
if(v==24){
v=0;
}
case "h":
case "H":
case "k":
if(v>23){
dojo.debug("dojo.date.parse: Illegal hours value");
return null;
}
_9c9.setHours(v);
break;
case "m":
_9c9.setMinutes(v);
break;
case "s":
_9c9.setSeconds(v);
break;
case "S":
_9c9.setMilliseconds(v);
break;
default:
dojo.unimplemented("dojo.date.parse: unsupported pattern char="+grp.charAt(0));
}
}
if(_9ca.year&&_9c9.getFullYear()!=_9ca.year){
dojo.debug("Parsed year: '"+_9c9.getFullYear()+"' did not match input year: '"+_9ca.year+"'.");
return null;
}
if(_9ca.month&&_9c9.getMonth()!=_9ca.month){
dojo.debug("Parsed month: '"+_9c9.getMonth()+"' did not match input month: '"+_9ca.month+"'.");
return null;
}
if(_9ca.date&&_9c9.getDate()!=_9ca.date){
dojo.debug("Parsed day of month: '"+_9c9.getDate()+"' did not match input day of month: '"+_9ca.date+"'.");
return null;
}
return _9c9;
};
function _processPattern(_9da,_9db,_9dc,_9dd){
var _9de=function(x){
return x;
};
_9db=_9db||_9de;
_9dc=_9dc||_9de;
_9dd=_9dd||_9de;
var _9e0=_9da.match(/(''|[^'])+/g);
var _9e1=false;
for(var i=0;i<_9e0.length;i++){
if(!_9e0[i]){
_9e0[i]="";
}else{
_9e0[i]=(_9e1?_9dc:_9db)(_9e0[i]);
_9e1=!_9e1;
}
}
return _9dd(_9e0.join(""));
}
function _buildDateTimeRE(_9e3,info,_9e5,_9e6){
return _9e6.replace(/([a-z])\1*/ig,function(_9e7){
var s;
var c=_9e7.charAt(0);
var l=_9e7.length;
switch(c){
case "y":
s="\\d"+((l==2)?"{2,4}":"+");
break;
case "M":
s=(l>2)?"\\S+":"\\d{1,2}";
break;
case "d":
s="\\d{1,2}";
break;
case "E":
s="\\S+";
break;
case "h":
case "H":
case "K":
case "k":
s="\\d{1,2}";
break;
case "m":
case "s":
s="[0-5]\\d";
break;
case "S":
s="\\d{1,3}";
break;
case "a":
var am=_9e5.am||info.am||"AM";
var pm=_9e5.pm||info.pm||"PM";
if(_9e5.strict){
s=am+"|"+pm;
}else{
s=am;
s+=(am!=am.toLowerCase())?"|"+am.toLowerCase():"";
s+="|";
s+=(pm!=pm.toLowerCase())?pm+"|"+pm.toLowerCase():pm;
}
break;
default:
dojo.unimplemented("parse of date format, pattern="+_9e6);
}
if(_9e3){
_9e3.push(_9e7);
}
return "\\s*("+s+")\\s*";
});
}
})();
dojo.date.strftime=function(_9ed,_9ee,_9ef){
var _9f0=null;
function _(s,n){
return dojo.string.pad(s,n||2,_9f0||"0");
}
var info=dojo.date._getGregorianBundle(_9ef);
function $(_9f4){
switch(_9f4){
case "a":
return dojo.date.getDayShortName(_9ed,_9ef);
case "A":
return dojo.date.getDayName(_9ed,_9ef);
case "b":
case "h":
return dojo.date.getMonthShortName(_9ed,_9ef);
case "B":
return dojo.date.getMonthName(_9ed,_9ef);
case "c":
return dojo.date.format(_9ed,{locale:_9ef});
case "C":
return _(Math.floor(_9ed.getFullYear()/100));
case "d":
return _(_9ed.getDate());
case "D":
return $("m")+"/"+$("d")+"/"+$("y");
case "e":
if(_9f0==null){
_9f0=" ";
}
return _(_9ed.getDate());
case "f":
if(_9f0==null){
_9f0=" ";
}
return _(_9ed.getMonth()+1);
case "g":
break;
case "G":
dojo.unimplemented("unimplemented modifier 'G'");
break;
case "F":
return $("Y")+"-"+$("m")+"-"+$("d");
case "H":
return _(_9ed.getHours());
case "I":
return _(_9ed.getHours()%12||12);
case "j":
return _(dojo.date.getDayOfYear(_9ed),3);
case "k":
if(_9f0==null){
_9f0=" ";
}
return _(_9ed.getHours());
case "l":
if(_9f0==null){
_9f0=" ";
}
return _(_9ed.getHours()%12||12);
case "m":
return _(_9ed.getMonth()+1);
case "M":
return _(_9ed.getMinutes());
case "n":
return "\n";
case "p":
return info[_9ed.getHours()<12?"am":"pm"];
case "r":
return $("I")+":"+$("M")+":"+$("S")+" "+$("p");
case "R":
return $("H")+":"+$("M");
case "S":
return _(_9ed.getSeconds());
case "t":
return "\t";
case "T":
return $("H")+":"+$("M")+":"+$("S");
case "u":
return String(_9ed.getDay()||7);
case "U":
return _(dojo.date.getWeekOfYear(_9ed));
case "V":
return _(dojo.date.getIsoWeekOfYear(_9ed));
case "W":
return _(dojo.date.getWeekOfYear(_9ed,1));
case "w":
return String(_9ed.getDay());
case "x":
return dojo.date.format(_9ed,{selector:"dateOnly",locale:_9ef});
case "X":
return dojo.date.format(_9ed,{selector:"timeOnly",locale:_9ef});
case "y":
return _(_9ed.getFullYear()%100);
case "Y":
return String(_9ed.getFullYear());
case "z":
var _9f5=_9ed.getTimezoneOffset();
return (_9f5>0?"-":"+")+_(Math.floor(Math.abs(_9f5)/60))+":"+_(Math.abs(_9f5)%60);
case "Z":
return dojo.date.getTimezoneName(_9ed);
case "%":
return "%";
}
}
var _9f6="";
var i=0;
var _9f8=0;
var _9f9=null;
while((_9f8=_9ee.indexOf("%",i))!=-1){
_9f6+=_9ee.substring(i,_9f8++);
switch(_9ee.charAt(_9f8++)){
case "_":
_9f0=" ";
break;
case "-":
_9f0="";
break;
case "0":
_9f0="0";
break;
case "^":
_9f9="upper";
break;
case "*":
_9f9="lower";
break;
case "#":
_9f9="swap";
break;
default:
_9f0=null;
_9f8--;
break;
}
var _9fa=$(_9ee.charAt(_9f8++));
switch(_9f9){
case "upper":
_9fa=_9fa.toUpperCase();
break;
case "lower":
_9fa=_9fa.toLowerCase();
break;
case "swap":
var _9fb=_9fa.toLowerCase();
var _9fc="";
var j=0;
var ch="";
while(j<_9fa.length){
ch=_9fa.charAt(j);
_9fc+=(ch==_9fb.charAt(j))?ch.toUpperCase():ch.toLowerCase();
j++;
}
_9fa=_9fc;
break;
default:
break;
}
_9f9=null;
_9f6+=_9fa;
i=_9f8;
}
_9f6+=_9ee.substring(i);
return _9f6;
};
(function(){
var _9ff=[];
dojo.date.addCustomFormats=function(_a00,_a01){
_9ff.push({pkg:_a00,name:_a01});
};
dojo.date._getGregorianBundle=function(_a02){
var _a03={};
dojo.lang.forEach(_9ff,function(desc){
var _a05=dojo.i18n.getLocalization(desc.pkg,desc.name,_a02);
_a03=dojo.lang.mixin(_a03,_a05);
},this);
return _a03;
};
})();
dojo.date.addCustomFormats("dojo.i18n.calendar","gregorian");
dojo.date.addCustomFormats("dojo.i18n.calendar","gregorianExtras");
dojo.date.getNames=function(item,type,use,_a09){
var _a0a;
var _a0b=dojo.date._getGregorianBundle(_a09);
var _a0c=[item,use,type];
if(use=="standAlone"){
_a0a=_a0b[_a0c.join("-")];
}
_a0c[1]="format";
return (_a0a||_a0b[_a0c.join("-")]).concat();
};
dojo.date.getDayName=function(_a0d,_a0e){
return dojo.date.getNames("days","wide","format",_a0e)[_a0d.getDay()];
};
dojo.date.getDayShortName=function(_a0f,_a10){
return dojo.date.getNames("days","abbr","format",_a10)[_a0f.getDay()];
};
dojo.date.getMonthName=function(_a11,_a12){
return dojo.date.getNames("months","wide","format",_a12)[_a11.getMonth()];
};
dojo.date.getMonthShortName=function(_a13,_a14){
return dojo.date.getNames("months","abbr","format",_a14)[_a13.getMonth()];
};
dojo.date.toRelativeString=function(_a15){
var now=new Date();
var diff=(now-_a15)/1000;
var end=" ago";
var _a19=false;
if(diff<0){
_a19=true;
end=" from now";
diff=-diff;
}
if(diff<60){
diff=Math.round(diff);
return diff+" second"+(diff==1?"":"s")+end;
}
if(diff<60*60){
diff=Math.round(diff/60);
return diff+" minute"+(diff==1?"":"s")+end;
}
if(diff<60*60*24){
diff=Math.round(diff/3600);
return diff+" hour"+(diff==1?"":"s")+end;
}
if(diff<60*60*24*7){
diff=Math.round(diff/(3600*24));
if(diff==1){
return _a19?"Tomorrow":"Yesterday";
}else{
return diff+" days"+end;
}
}
return dojo.date.format(_a15);
};
dojo.date.toSql=function(_a1a,_a1b){
return dojo.date.strftime(_a1a,"%F"+!_a1b?" %T":"");
};
dojo.date.fromSql=function(_a1c){
var _a1d=_a1c.split(/[\- :]/g);
while(_a1d.length<6){
_a1d.push(0);
}
return new Date(_a1d[0],(parseInt(_a1d[1],10)-1),_a1d[2],_a1d[3],_a1d[4],_a1d[5]);
};
dojo.provide("dojo.collections.Store");
dojo.collections.Store=function(_a1e){
var data=[];
this.keyField="Id";
this.get=function(){
return data;
};
this.getByKey=function(key){
for(var i=0;i<data.length;i++){
if(data[i].key==key){
return data[i];
}
}
return null;
};
this.getByIndex=function(idx){
return data[idx];
};
this.getData=function(){
var arr=[];
for(var i=0;i<data.length;i++){
arr.push(data[i].src);
}
return arr;
};
this.getDataByKey=function(key){
for(var i=0;i<data.length;i++){
if(data[i].key==key){
return data[i].src;
}
}
return null;
};
this.getDataByIndex=function(idx){
return data[idx].src;
};
this.update=function(obj,_a29,val){
var _a2b=_a29.split("."),i=0,o=obj,_a2e;
if(_a2b.length>1){
_a2e=_a2b.pop();
do{
if(_a2b[i].indexOf("()")>-1){
var temp=_a2b[i++].split("()")[0];
if(!o[temp]){
dojo.raise("dojo.collections.Store.getField(obj, '"+_a2e+"'): '"+temp+"' is not a property of the passed object.");
}else{
o=o[temp]();
}
}else{
o=o[_a2b[i++]];
}
}while(i<_a2b.length&&o!=null);
}else{
_a2e=_a2b[0];
}
obj[_a2e]=val;
this.onUpdateField(obj,_a29,val);
};
this.forEach=function(fn){
if(Array.forEach){
Array.forEach(data,fn,this);
}else{
for(var i=0;i<data.length;i++){
fn.call(this,data[i]);
}
}
};
this.forEachData=function(fn){
if(Array.forEach){
Array.forEach(this.getData(),fn,this);
}else{
var a=this.getData();
for(var i=0;i<a.length;i++){
fn.call(this,a[i]);
}
}
};
this.setData=function(arr){
data=[];
for(var i=0;i<arr.length;i++){
data.push({key:arr[i][this.keyField],src:arr[i]});
}
this.onSetData();
};
this.clearData=function(){
data=[];
this.onClearData();
};
this.addData=function(obj,key){
var k=key||obj[this.keyField];
if(this.getByKey(k)){
var o=this.getByKey(k);
o.src=obj;
}else{
var o={key:k,src:obj};
data.push(o);
}
this.onAddData(o);
};
this.addDataRange=function(arr){
var _a3c=[];
for(var i=0;i<arr.length;i++){
var k=arr[i][this.keyField];
if(this.getByKey(k)){
var o=this.getByKey(k);
o.src=obj;
}else{
var o={key:k,src:arr[i]};
data.push(o);
}
_a3c.push(o);
}
this.onAddDataRange(_a3c);
};
this.removeData=function(obj){
var idx=-1;
var o=null;
for(var i=0;i<data.length;i++){
if(data[i].src==obj){
idx=i;
o=data[i];
break;
}
}
this.onRemoveData(o);
if(idx>-1){
data.splice(idx,1);
}
};
this.removeDataByKey=function(key){
this.removeData(this.getDataByKey(key));
};
this.removeDataByIndex=function(idx){
this.removeData(this.getDataByIndex(idx));
};
if(_a1e&&_a1e.length&&_a1e[0]){
this.setData(_a1e);
}
};
dojo.extend(dojo.collections.Store,{getField:function(obj,_a47){
var _a48=_a47.split("."),i=0,o=obj;
do{
if(_a48[i].indexOf("()")>-1){
var temp=_a48[i++].split("()")[0];
if(!o[temp]){
dojo.raise("dojo.collections.Store.getField(obj, '"+_a47+"'): '"+temp+"' is not a property of the passed object.");
}else{
o=o[temp]();
}
}else{
o=o[_a48[i++]];
}
}while(i<_a48.length&&o!=null);
if(i<_a48.length){
dojo.raise("dojo.collections.Store.getField(obj, '"+_a47+"'): '"+_a47+"' is not a property of the passed object.");
}
return o;
},getFromHtml:function(meta,body,_a4e){
var rows=body.rows;
var ctor=function(row){
var obj={};
for(var i=0;i<meta.length;i++){
var o=obj;
var data=row.cells[i].innerHTML;
var p=meta[i].getField();
if(p.indexOf(".")>-1){
p=p.split(".");
while(p.length>1){
var pr=p.shift();
o[pr]={};
o=o[pr];
}
p=p[0];
}
var type=meta[i].getType();
if(type==String){
o[p]=data;
}else{
if(data){
o[p]=new type(data);
}else{
o[p]=new type();
}
}
}
return obj;
};
var arr=[];
for(var i=0;i<rows.length;i++){
var o=ctor(rows[i]);
if(_a4e){
_a4e(o,rows[i]);
}
arr.push(o);
}
return arr;
},onSetData:function(){
},onClearData:function(){
},onAddData:function(obj){
},onAddDataRange:function(arr){
},onRemoveData:function(obj){
},onUpdateField:function(obj,_a60,val){
}});
dojo.provide("dojo.html.*");
dojo.provide("dojo.widget.FilteringTable");
dojo.widget.defineWidget("dojo.widget.FilteringTable",dojo.widget.HtmlWidget,function(){
this.store=new dojo.collections.Store();
this.valueField="Id";
this.multiple=false;
this.maxSelect=0;
this.maxSortable=1;
this.minRows=0;
this.defaultDateFormat="%D";
this.isInitialized=false;
this.alternateRows=false;
this.columns=[];
this.sortInformation=[{index:0,direction:0}];
this.headClass="";
this.tbodyClass="";
this.headerClass="";
this.headerUpClass="selectedUp";
this.headerDownClass="selectedDown";
this.rowClass="";
this.rowAlternateClass="alt";
this.rowSelectedClass="selected";
this.columnSelected="sorted-column";
},{isContainer:false,templatePath:null,templateCssPath:null,getTypeFromString:function(s){
var _a63=s.split("."),i=0,obj=dj_global;
do{
obj=obj[_a63[i++]];
}while(i<_a63.length&&obj);
return (obj!=dj_global)?obj:null;
},getByRow:function(row){
return this.store.getByKey(dojo.html.getAttribute(row,"value"));
},getDataByRow:function(row){
return this.store.getDataByKey(dojo.html.getAttribute(row,"value"));
},getRow:function(obj){
var rows=this.domNode.tBodies[0].rows;
for(var i=0;i<rows.length;i++){
if(this.store.getDataByKey(dojo.html.getAttribute(rows[i],"value"))==obj){
return rows[i];
}
}
return null;
},getColumnIndex:function(_a6b){
for(var i=0;i<this.columns.length;i++){
if(this.columns[i].getField()==_a6b){
return i;
}
}
return -1;
},getSelectedData:function(){
var data=this.store.get();
var a=[];
for(var i=0;i<data.length;i++){
if(data[i].isSelected){
a.push(data[i].src);
}
}
if(this.multiple){
return a;
}else{
return a[0];
}
},isSelected:function(obj){
var data=this.store.get();
for(var i=0;i<data.length;i++){
if(data[i].src==obj){
return true;
}
}
return false;
},isValueSelected:function(val){
var v=this.store.getByKey(val);
if(v){
return v.isSelected;
}
return false;
},isIndexSelected:function(idx){
var v=this.store.getByIndex(idx);
if(v){
return v.isSelected;
}
return false;
},isRowSelected:function(row){
var v=this.getByRow(row);
if(v){
return v.isSelected;
}
return false;
},reset:function(){
this.store.clearData();
this.columns=[];
this.sortInformation=[{index:0,direction:0}];
this.resetSelections();
this.isInitialized=false;
this.onReset();
},resetSelections:function(){
this.store.forEach(function(_a79){
_a79.isSelected=false;
});
},onReset:function(){
},select:function(obj){
var data=this.store.get();
for(var i=0;i<data.length;i++){
if(data[i].src==obj){
data[i].isSelected=true;
break;
}
}
this.onDataSelect(obj);
},selectByValue:function(val){
this.select(this.store.getDataByKey(val));
},selectByIndex:function(idx){
this.select(this.store.getDataByIndex(idx));
},selectByRow:function(row){
this.select(this.getDataByRow(row));
},selectAll:function(){
this.store.forEach(function(_a80){
_a80.isSelected=true;
});
},onDataSelect:function(obj){
},toggleSelection:function(obj){
var data=this.store.get();
for(var i=0;i<data.length;i++){
if(data[i].src==obj){
data[i].isSelected=!data[i].isSelected;
break;
}
}
this.onDataToggle(obj);
},toggleSelectionByValue:function(val){
this.toggleSelection(this.store.getDataByKey(val));
},toggleSelectionByIndex:function(idx){
this.toggleSelection(this.store.getDataByIndex(idx));
},toggleSelectionByRow:function(row){
this.toggleSelection(this.getDataByRow(row));
},toggleAll:function(){
this.store.forEach(function(_a88){
_a88.isSelected=!_a88.isSelected;
});
},onDataToggle:function(obj){
},_meta:{field:null,format:null,filterer:null,noSort:false,sortType:"String",dataType:String,sortFunction:null,filterFunction:null,label:null,align:"left",valign:"middle",getField:function(){
return this.field||this.label;
},getType:function(){
return this.dataType;
}},createMetaData:function(obj){
for(var p in this._meta){
if(!obj[p]){
obj[p]=this._meta[p];
}
}
if(!obj.label){
obj.label=obj.field;
}
if(!obj.filterFunction){
obj.filterFunction=this._defaultFilter;
}
return obj;
},parseMetadata:function(head){
this.columns=[];
this.sortInformation=[];
var row=head.getElementsByTagName("tr")[0];
var _a8e=row.getElementsByTagName("td");
if(_a8e.length==0){
_a8e=row.getElementsByTagName("th");
}
for(var i=0;i<_a8e.length;i++){
var o=this.createMetaData({});
if(dojo.html.hasAttribute(_a8e[i],"align")){
o.align=dojo.html.getAttribute(_a8e[i],"align");
}
if(dojo.html.hasAttribute(_a8e[i],"valign")){
o.valign=dojo.html.getAttribute(_a8e[i],"valign");
}
if(dojo.html.hasAttribute(_a8e[i],"nosort")){
o.noSort=(dojo.html.getAttribute(_a8e[i],"nosort")=="true");
}
if(dojo.html.hasAttribute(_a8e[i],"sortusing")){
var _a91=dojo.html.getAttribute(_a8e[i],"sortusing");
var f=this.getTypeFromString(_a91);
if(f!=null&&f!=window&&typeof (f)=="function"){
o.sortFunction=f;
}
}
o.label=dojo.html.renderedTextContent(_a8e[i]);
if(dojo.html.hasAttribute(_a8e[i],"field")){
o.field=dojo.html.getAttribute(_a8e[i],"field");
}else{
if(o.label.length>0){
o.field=o.label;
}else{
o.field="field"+i;
}
}
if(dojo.html.hasAttribute(_a8e[i],"format")){
o.format=dojo.html.getAttribute(_a8e[i],"format");
}
if(dojo.html.hasAttribute(_a8e[i],"dataType")){
var _a93=dojo.html.getAttribute(_a8e[i],"dataType");
if(_a93.toLowerCase()=="html"||_a93.toLowerCase()=="markup"){
o.sortType="__markup__";
}else{
var type=this.getTypeFromString(_a93);
if(type){
o.sortType=_a93;
o.dataType=type;
}
}
}
if(dojo.html.hasAttribute(_a8e[i],"filterusing")){
var _a91=dojo.html.getAttribute(_a8e[i],"filterusing");
var f=this.getTypeFromString(_a91);
if(f!=null&&f!=window&&typeof (f)=="function"){
o.filterFunction=f;
}
}
this.columns.push(o);
if(dojo.html.hasAttribute(_a8e[i],"sort")){
var info={index:i,direction:0};
var dir=dojo.html.getAttribute(_a8e[i],"sort");
if(!isNaN(parseInt(dir))){
dir=parseInt(dir);
info.direction=(dir!=0)?1:0;
}else{
info.direction=(dir.toLowerCase()=="desc")?1:0;
}
this.sortInformation.push(info);
}
}
if(this.sortInformation.length==0){
this.sortInformation.push({index:0,direction:0});
}else{
if(this.sortInformation.length>this.maxSortable){
this.sortInformation.length=this.maxSortable;
}
}
},parseData:function(body){
if(body.rows.length==0&&this.columns.length==0){
return;
}
var self=this;
this["__selected__"]=[];
var arr=this.store.getFromHtml(this.columns,body,function(obj,row){
if(typeof (obj[self.valueField])=="undefined"||obj[self.valueField]==null){
obj[self.valueField]=dojo.html.getAttribute(row,"value");
}
if(dojo.html.getAttribute(row,"selected")=="true"){
self["__selected__"].push(obj);
}
});
this.store.setData(arr,true);
this.render();
for(var i=0;i<this["__selected__"].length;i++){
this.select(this["__selected__"][i]);
}
this.renderSelections();
delete this["__selected__"];
this.isInitialized=true;
},onSelect:function(e){
var row=dojo.html.getParentByType(e.target,"tr");
if(dojo.html.hasAttribute(row,"emptyRow")){
return;
}
var body=dojo.html.getParentByType(row,"tbody");
if(this.multiple){
if(e.shiftKey){
var _aa0;
var rows=body.rows;
for(var i=0;i<rows.length;i++){
if(rows[i]==row){
break;
}
if(this.isRowSelected(rows[i])){
_aa0=rows[i];
}
}
if(!_aa0){
_aa0=row;
for(;i<rows.length;i++){
if(this.isRowSelected(rows[i])){
row=rows[i];
break;
}
}
}
this.resetSelections();
if(_aa0==row){
this.toggleSelectionByRow(row);
}else{
var _aa3=false;
for(var i=0;i<rows.length;i++){
if(rows[i]==_aa0){
_aa3=true;
}
if(_aa3){
this.selectByRow(rows[i]);
}
if(rows[i]==row){
_aa3=false;
}
}
}
}else{
this.toggleSelectionByRow(row);
}
}else{
this.resetSelections();
this.toggleSelectionByRow(row);
}
this.renderSelections();
},onSort:function(e){
var _aa5=this.sortIndex;
var _aa6=this.sortDirection;
var _aa7=e.target;
var row=dojo.html.getParentByType(_aa7,"tr");
var _aa9="td";
if(row.getElementsByTagName(_aa9).length==0){
_aa9="th";
}
var _aaa=row.getElementsByTagName(_aa9);
var _aab=dojo.html.getParentByType(_aa7,_aa9);
for(var i=0;i<_aaa.length;i++){
dojo.html.setClass(_aaa[i],this.headerClass);
if(_aaa[i]==_aab){
if(this.sortInformation[0].index!=i){
this.sortInformation.unshift({index:i,direction:0});
}else{
this.sortInformation[0]={index:i,direction:(~this.sortInformation[0].direction)&1};
}
}
}
this.sortInformation.length=Math.min(this.sortInformation.length,this.maxSortable);
for(var i=0;i<this.sortInformation.length;i++){
var idx=this.sortInformation[i].index;
var dir=(~this.sortInformation[i].direction)&1;
dojo.html.setClass(_aaa[idx],dir==0?this.headerDownClass:this.headerUpClass);
}
this.render();
},onFilter:function(){
},_defaultFilter:function(obj){
return true;
},setFilter:function(_ab0,fn){
for(var i=0;i<this.columns.length;i++){
if(this.columns[i].getField()==_ab0){
this.columns[i].filterFunction=fn;
break;
}
}
this.applyFilters();
},setFilterByIndex:function(idx,fn){
this.columns[idx].filterFunction=fn;
this.applyFilters();
},clearFilter:function(_ab5){
for(var i=0;i<this.columns.length;i++){
if(this.columns[i].getField()==_ab5){
this.columns[i].filterFunction=this._defaultFilter;
break;
}
}
this.applyFilters();
},clearFilterByIndex:function(idx){
this.columns[idx].filterFunction=this._defaultFilter;
this.applyFilters();
},clearFilters:function(){
for(var i=0;i<this.columns.length;i++){
this.columns[i].filterFunction=this._defaultFilter;
}
var rows=this.domNode.tBodies[0].rows;
for(var i=0;i<rows.length;i++){
rows[i].style.display="";
if(this.alternateRows){
dojo.html[((i%2==1)?"addClass":"removeClass")](rows[i],this.rowAlternateClass);
}
}
this.onFilter();
},applyFilters:function(){
var alt=0;
var rows=this.domNode.tBodies[0].rows;
for(var i=0;i<rows.length;i++){
var b=true;
var row=rows[i];
for(var j=0;j<this.columns.length;j++){
var _ac0=this.store.getField(this.getDataByRow(row),this.columns[j].getField());
if(this.columns[j].getType()==Date&&_ac0!=null&&!_ac0.getYear){
_ac0=new Date(_ac0);
}
if(!this.columns[j].filterFunction(_ac0)){
b=false;
break;
}
}
row.style.display=(b?"":"none");
if(b&&this.alternateRows){
dojo.html[((alt++%2==1)?"addClass":"removeClass")](row,this.rowAlternateClass);
}
}
this.onFilter();
},createSorter:function(info){
var self=this;
var _ac3=[];
function createSortFunction(_ac4,dir){
var meta=self.columns[_ac4];
var _ac7=meta.getField();
return function(rowA,rowB){
if(dojo.html.hasAttribute(rowA,"emptyRow")){
return 1;
}
if(dojo.html.hasAttribute(rowB,"emptyRow")){
return -1;
}
var a=self.store.getField(self.getDataByRow(rowA),_ac7);
var b=self.store.getField(self.getDataByRow(rowB),_ac7);
var ret=0;
if(a>b){
ret=1;
}
if(a<b){
ret=-1;
}
return dir*ret;
};
}
var _acd=0;
var max=Math.min(info.length,this.maxSortable,this.columns.length);
while(_acd<max){
var _acf=(info[_acd].direction==0)?1:-1;
_ac3.push(createSortFunction(info[_acd].index,_acf));
_acd++;
}
return function(rowA,rowB){
var idx=0;
while(idx<_ac3.length){
var ret=_ac3[idx++](rowA,rowB);
if(ret!=0){
return ret;
}
}
return 0;
};
},createRow:function(obj){
var row=document.createElement("tr");
dojo.html.disableSelection(row);
if(obj.key!=null){
row.setAttribute("value",obj.key);
}
for(var j=0;j<this.columns.length;j++){
var cell=document.createElement("td");
cell.setAttribute("align",this.columns[j].align);
cell.setAttribute("valign",this.columns[j].valign);
dojo.html.disableSelection(cell);
var val=this.store.getField(obj.src,this.columns[j].getField());
if(typeof (val)=="undefined"){
val="";
}
this.fillCell(cell,this.columns[j],val);
row.appendChild(cell);
}
return row;
},fillCell:function(cell,meta,val){
if(meta.sortType=="__markup__"){
cell.innerHTML=val;
}else{
if(meta.getType()==Date){
val=new Date(val);
if(!isNaN(val)){
var _adc=this.defaultDateFormat;
if(meta.format){
_adc=meta.format;
}
cell.innerHTML=dojo.date.strftime(val,_adc);
}else{
cell.innerHTML=val;
}
}else{
if("Number number int Integer float Float".indexOf(meta.getType())>-1){
if(val.length==0){
val="0";
}
var n=parseFloat(val,10)+"";
if(n.indexOf(".")>-1){
n=dojo.math.round(parseFloat(val,10),2);
}
cell.innerHTML=n;
}else{
cell.innerHTML=val;
}
}
}
},prefill:function(){
this.isInitialized=false;
var body=this.domNode.tBodies[0];
while(body.childNodes.length>0){
body.removeChild(body.childNodes[0]);
}
if(this.minRows>0){
for(var i=0;i<this.minRows;i++){
var row=document.createElement("tr");
if(this.alternateRows){
dojo.html[((i%2==1)?"addClass":"removeClass")](row,this.rowAlternateClass);
}
row.setAttribute("emptyRow","true");
for(var j=0;j<this.columns.length;j++){
var cell=document.createElement("td");
cell.innerHTML="&nbsp;";
row.appendChild(cell);
}
body.appendChild(row);
}
}
},init:function(){
this.isInitialized=false;
var head=this.domNode.getElementsByTagName("thead")[0];
if(head.getElementsByTagName("tr").length==0){
var row=document.createElement("tr");
for(var i=0;i<this.columns.length;i++){
var cell=document.createElement("td");
cell.setAttribute("align",this.columns[i].align);
cell.setAttribute("valign",this.columns[i].valign);
dojo.html.disableSelection(cell);
cell.innerHTML=this.columns[i].label;
row.appendChild(cell);
if(!this.columns[i].noSort){
dojo.event.connect(cell,"onclick",this,"onSort");
}
}
dojo.html.prependChild(row,head);
}
if(this.store.get().length==0){
return false;
}
var idx=this.domNode.tBodies[0].rows.length;
if(!idx||idx==0||this.domNode.tBodies[0].rows[0].getAttribute("emptyRow")=="true"){
idx=0;
var body=this.domNode.tBodies[0];
while(body.childNodes.length>0){
body.removeChild(body.childNodes[0]);
}
var data=this.store.get();
for(var i=0;i<data.length;i++){
var row=this.createRow(data[i]);
body.appendChild(row);
idx++;
}
}
if(this.minRows>0&&idx<this.minRows){
idx=this.minRows-idx;
for(var i=0;i<idx;i++){
row=document.createElement("tr");
row.setAttribute("emptyRow","true");
for(var j=0;j<this.columns.length;j++){
cell=document.createElement("td");
cell.innerHTML="&nbsp;";
row.appendChild(cell);
}
body.appendChild(row);
}
}
var row=this.domNode.getElementsByTagName("thead")[0].rows[0];
var _aeb="td";
if(row.getElementsByTagName(_aeb).length==0){
_aeb="th";
}
var _aec=row.getElementsByTagName(_aeb);
for(var i=0;i<_aec.length;i++){
dojo.html.setClass(_aec[i],this.headerClass);
}
for(var i=0;i<this.sortInformation.length;i++){
var idx=this.sortInformation[i].index;
var dir=(~this.sortInformation[i].direction)&1;
dojo.html.setClass(_aec[idx],dir==0?this.headerDownClass:this.headerUpClass);
}
this.isInitialized=true;
return this.isInitialized;
},render:function(){
if(!this.isInitialized){
var b=this.init();
if(!b){
this.prefill();
return;
}
}
var rows=[];
var body=this.domNode.tBodies[0];
var _af1=-1;
for(var i=0;i<body.rows.length;i++){
rows.push(body.rows[i]);
}
var _af3=this.createSorter(this.sortInformation);
if(_af3){
rows.sort(_af3);
}
for(var i=0;i<rows.length;i++){
if(this.alternateRows){
dojo.html[((i%2==1)?"addClass":"removeClass")](rows[i],this.rowAlternateClass);
}
dojo.html[(this.isRowSelected(body.rows[i])?"addClass":"removeClass")](body.rows[i],this.rowSelectedClass);
body.appendChild(rows[i]);
}
},renderSelections:function(){
var body=this.domNode.tBodies[0];
for(var i=0;i<body.rows.length;i++){
dojo.html[(this.isRowSelected(body.rows[i])?"addClass":"removeClass")](body.rows[i],this.rowSelectedClass);
}
},initialize:function(){
var self=this;
dojo.event.connect(this.store,"onSetData",function(){
self.store.forEach(function(_af7){
_af7.isSelected=false;
});
self.isInitialized=false;
var body=self.domNode.tBodies[0];
if(body){
while(body.childNodes.length>0){
body.removeChild(body.childNodes[0]);
}
}
self.render();
});
dojo.event.connect(this.store,"onClearData",function(){
self.isInitialized=false;
self.render();
});
dojo.event.connect(this.store,"onAddData",function(_af9){
var row=self.createRow(_af9);
self.domNode.tBodies[0].appendChild(row);
self.render();
});
dojo.event.connect(this.store,"onAddDataRange",function(arr){
for(var i=0;i<arr.length;i++){
arr[i].isSelected=false;
var row=self.createRow(arr[i]);
self.domNode.tBodies[0].appendChild(row);
}
self.render();
});
dojo.event.connect(this.store,"onRemoveData",function(_afe){
var rows=self.domNode.tBodies[0].rows;
for(var i=0;i<rows.length;i++){
if(self.getDataByRow(rows[i])==_afe.src){
rows[i].parentNode.removeChild(rows[i]);
break;
}
}
self.render();
});
dojo.event.connect(this.store,"onUpdateField",function(obj,_b02,val){
var row=self.getRow(obj);
var idx=self.getColumnIndex(_b02);
if(row&&row.cells[idx]&&self.columns[idx]){
self.fillCell(row.cells[idx],self.columns[idx],val);
}
});
},postCreate:function(){
this.store.keyField=this.valueField;
if(this.domNode){
if(this.domNode.nodeName.toLowerCase()!="table"){
}
if(this.domNode.getElementsByTagName("thead")[0]){
var head=this.domNode.getElementsByTagName("thead")[0];
if(this.headClass.length>0){
head.className=this.headClass;
}
dojo.html.disableSelection(this.domNode);
this.parseMetadata(head);
var _b07="td";
if(head.getElementsByTagName(_b07).length==0){
_b07="th";
}
var _b08=head.getElementsByTagName(_b07);
for(var i=0;i<_b08.length;i++){
if(!this.columns[i].noSort){
dojo.event.connect(_b08[i],"onclick",this,"onSort");
}
}
}else{
this.domNode.appendChild(document.createElement("thead"));
}
if(this.domNode.tBodies.length<1){
var body=document.createElement("tbody");
this.domNode.appendChild(body);
}else{
var body=this.domNode.tBodies[0];
}
if(this.tbodyClass.length>0){
body.className=this.tbodyClass;
}
dojo.event.connect(body,"onclick",this,"onSelect");
this.parseData(body);
}
}});
dojo.provide("dojo.widget.Button");
dojo.widget.defineWidget("dojo.widget.Button",dojo.widget.HtmlWidget,{isContainer:true,caption:"",templatePath:dojo.uri.dojoUri("src/widget/templates/ButtonTemplate.html"),templateCssPath:dojo.uri.dojoUri("src/widget/templates/ButtonTemplate.css"),inactiveImg:"src/widget/templates/images/soriaButton-",activeImg:"src/widget/templates/images/soriaActive-",pressedImg:"src/widget/templates/images/soriaPressed-",disabledImg:"src/widget/templates/images/soriaDisabled-",width2height:1/3,fillInTemplate:function(){
if(this.caption){
this.containerNode.appendChild(document.createTextNode(this.caption));
}
dojo.html.disableSelection(this.containerNode);
},postCreate:function(){
this._sizeMyself();
},_sizeMyself:function(){
if(this.domNode.parentNode){
var _b0b=document.createElement("span");
dojo.html.insertBefore(_b0b,this.domNode);
}
dojo.body().appendChild(this.domNode);
this._sizeMyselfHelper();
if(_b0b){
dojo.html.insertBefore(this.domNode,_b0b);
dojo.html.removeNode(_b0b);
}
},_sizeMyselfHelper:function(){
var mb=dojo.html.getMarginBox(this.containerNode);
this.height=mb.height;
this.containerWidth=mb.width;
var _b0d=this.height*this.width2height;
this.containerNode.style.left=_b0d+"px";
this.leftImage.height=this.rightImage.height=this.centerImage.height=this.height;
this.leftImage.width=this.rightImage.width=_b0d+1;
this.centerImage.width=this.containerWidth;
this.centerImage.style.left=_b0d+"px";
this._setImage(this.disabled?this.disabledImg:this.inactiveImg);
if(this.disabled){
dojo.html.prependClass(this.domNode,"dojoButtonDisabled");
this.domNode.removeAttribute("tabIndex");
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",true);
}else{
dojo.html.removeClass(this.domNode,"dojoButtonDisabled");
this.domNode.setAttribute("tabIndex","0");
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",false);
}
this.domNode.style.height=this.height+"px";
this.domNode.style.width=(this.containerWidth+2*_b0d)+"px";
},onMouseOver:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.buttonNode,"dojoButtonHover");
this._setImage(this.activeImg);
},onMouseDown:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.buttonNode,"dojoButtonDepressed");
dojo.html.removeClass(this.buttonNode,"dojoButtonHover");
this._setImage(this.pressedImg);
},onMouseUp:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.buttonNode,"dojoButtonHover");
dojo.html.removeClass(this.buttonNode,"dojoButtonDepressed");
this._setImage(this.activeImg);
},onMouseOut:function(e){
if(this.disabled){
return;
}
if(e.toElement&&dojo.html.isDescendantOf(e.toElement,this.buttonNode)){
return;
}
dojo.html.removeClass(this.buttonNode,"dojoButtonHover");
dojo.html.removeClass(this.buttonNode,"dojoButtonDepressed");
this._setImage(this.inactiveImg);
},onKey:function(e){
if(!e.key){
return;
}
var menu=dojo.widget.getWidgetById(this.menuId);
if(e.key==e.KEY_ENTER||e.key==" "){
this.onMouseDown(e);
this.buttonClick(e);
dojo.lang.setTimeout(this,"onMouseUp",75,e);
dojo.event.browser.stopEvent(e);
}
if(menu&&menu.isShowingNow&&e.key==e.KEY_DOWN_ARROW){
dojo.event.disconnect(this.domNode,"onblur",this,"onBlur");
}
},onFocus:function(e){
var menu=dojo.widget.getWidgetById(this.menuId);
if(menu){
dojo.event.connectOnce(this.domNode,"onblur",this,"onBlur");
}
},onBlur:function(e){
var menu=dojo.widget.getWidgetById(this.menuId);
if(!menu){
return;
}
if(menu.close&&menu.isShowingNow){
menu.close();
}
},buttonClick:function(e){
if(!this.disabled){
try{
this.domNode.focus();
}
catch(e2){
}
this.onClick(e);
}
},onClick:function(e){
},_setImage:function(_b1a){
this.leftImage.src=dojo.uri.dojoUri(_b1a+"l.gif");
this.centerImage.src=dojo.uri.dojoUri(_b1a+"c.gif");
this.rightImage.src=dojo.uri.dojoUri(_b1a+"r.gif");
},_toggleMenu:function(_b1b){
var menu=dojo.widget.getWidgetById(_b1b);
if(!menu){
return;
}
if(menu.open&&!menu.isShowingNow){
var pos=dojo.html.getAbsolutePosition(this.domNode,false);
menu.open(pos.x,pos.y+this.height,this);
}else{
if(menu.close&&menu.isShowingNow){
menu.close();
}else{
menu.toggle();
}
}
},setCaption:function(_b1e){
this.caption=_b1e;
this.containerNode.innerHTML=_b1e;
this._sizeMyself();
},setDisabled:function(_b1f){
this.disabled=_b1f;
this._sizeMyself();
}});
dojo.widget.defineWidget("dojo.widget.DropDownButton",dojo.widget.Button,{menuId:"",downArrow:"src/widget/templates/images/whiteDownArrow.gif",disabledDownArrow:"src/widget/templates/images/whiteDownArrow.gif",fillInTemplate:function(){
dojo.widget.DropDownButton.superclass.fillInTemplate.apply(this,arguments);
this.arrow=document.createElement("img");
dojo.html.setClass(this.arrow,"downArrow");
dojo.widget.wai.setAttr(this.domNode,"waiState","haspopup",this.menuId);
},_sizeMyselfHelper:function(){
this.arrow.src=dojo.uri.dojoUri(this.disabled?this.disabledDownArrow:this.downArrow);
this.containerNode.appendChild(this.arrow);
dojo.widget.DropDownButton.superclass._sizeMyselfHelper.call(this);
},onClick:function(e){
this._toggleMenu(this.menuId);
}});
dojo.widget.defineWidget("dojo.widget.ComboButton",dojo.widget.Button,{menuId:"",templatePath:dojo.uri.dojoUri("src/widget/templates/ComboButtonTemplate.html"),splitWidth:2,arrowWidth:5,_sizeMyselfHelper:function(e){
var mb=dojo.html.getMarginBox(this.containerNode);
this.height=mb.height;
this.containerWidth=mb.width;
var _b23=this.height/3;
if(this.disabled){
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",true);
this.domNode.removeAttribute("tabIndex");
}else{
dojo.widget.wai.setAttr(this.domNode,"waiState","disabled",false);
this.domNode.setAttribute("tabIndex","0");
}
this.leftImage.height=this.rightImage.height=this.centerImage.height=this.arrowBackgroundImage.height=this.height;
this.leftImage.width=_b23+1;
this.centerImage.width=this.containerWidth;
this.buttonNode.style.height=this.height+"px";
this.buttonNode.style.width=_b23+this.containerWidth+"px";
this._setImage(this.disabled?this.disabledImg:this.inactiveImg);
this.arrowBackgroundImage.width=this.arrowWidth;
this.rightImage.width=_b23+1;
this.rightPart.style.height=this.height+"px";
this.rightPart.style.width=this.arrowWidth+_b23+"px";
this._setImageR(this.disabled?this.disabledImg:this.inactiveImg);
this.domNode.style.height=this.height+"px";
var _b24=this.containerWidth+this.splitWidth+this.arrowWidth+2*_b23;
this.domNode.style.width=_b24+"px";
},_setImage:function(_b25){
this.leftImage.src=dojo.uri.dojoUri(_b25+"l.gif");
this.centerImage.src=dojo.uri.dojoUri(_b25+"c.gif");
},rightOver:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.rightPart,"dojoButtonHover");
this._setImageR(this.activeImg);
},rightDown:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.rightPart,"dojoButtonDepressed");
dojo.html.removeClass(this.rightPart,"dojoButtonHover");
this._setImageR(this.pressedImg);
},rightUp:function(e){
if(this.disabled){
return;
}
dojo.html.prependClass(this.rightPart,"dojoButtonHover");
dojo.html.removeClass(this.rightPart,"dojoButtonDepressed");
this._setImageR(this.activeImg);
},rightOut:function(e){
if(this.disabled){
return;
}
dojo.html.removeClass(this.rightPart,"dojoButtonHover");
dojo.html.removeClass(this.rightPart,"dojoButtonDepressed");
this._setImageR(this.inactiveImg);
},rightClick:function(e){
if(this.disabled){
return;
}
try{
this.domNode.focus();
}
catch(e2){
}
this._toggleMenu(this.menuId);
},_setImageR:function(_b2b){
this.arrowBackgroundImage.src=dojo.uri.dojoUri(_b2b+"c.gif");
this.rightImage.src=dojo.uri.dojoUri(_b2b+"r.gif");
},onKey:function(e){
if(!e.key){
return;
}
var menu=dojo.widget.getWidgetById(this.menuId);
if(e.key==e.KEY_ENTER||e.key==" "){
this.onMouseDown(e);
this.buttonClick(e);
dojo.lang.setTimeout(this,"onMouseUp",75,e);
dojo.event.browser.stopEvent(e);
}else{
if(e.key==e.KEY_DOWN_ARROW&&e.altKey){
this.rightDown(e);
this.rightClick(e);
dojo.lang.setTimeout(this,"rightUp",75,e);
dojo.event.browser.stopEvent(e);
}else{
if(menu&&menu.isShowingNow&&e.key==e.KEY_DOWN_ARROW){
dojo.event.disconnect(this.domNode,"onblur",this,"onBlur");
}
}
}
}});
dojo.provide("dojo.widget.Dialog");
dojo.declare("dojo.widget.ModalDialogBase",null,{isContainer:true,focusElement:"",bgColor:"black",bgOpacity:0.4,followScroll:true,closeOnBackgroundClick:false,trapTabs:function(e){
if(e.target==this.tabStartOuter){
if(this._fromTrap){
this.tabStart.focus();
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabEnd.focus();
}
}else{
if(e.target==this.tabStart){
if(this._fromTrap){
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabEnd.focus();
}
}else{
if(e.target==this.tabEndOuter){
if(this._fromTrap){
this.tabEnd.focus();
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabStart.focus();
}
}else{
if(e.target==this.tabEnd){
if(this._fromTrap){
this._fromTrap=false;
}else{
this._fromTrap=true;
this.tabStart.focus();
}
}
}
}
}
},clearTrap:function(e){
var _b30=this;
setTimeout(function(){
_b30._fromTrap=false;
},100);
},postCreate:function(){
with(this.domNode.style){
position="absolute";
zIndex=999;
display="none";
overflow="visible";
}
var b=dojo.body();
b.appendChild(this.domNode);
this.bg=document.createElement("div");
this.bg.className="dialogUnderlay";
with(this.bg.style){
position="absolute";
left=top="0px";
zIndex=998;
display="none";
}
b.appendChild(this.bg);
this.setBackgroundColor(this.bgColor);
this.bgIframe=new dojo.html.BackgroundIframe();
if(this.bgIframe.iframe){
with(this.bgIframe.iframe.style){
position="absolute";
left=top="0px";
zIndex=90;
display="none";
}
}
if(this.closeOnBackgroundClick){
dojo.event.kwConnect({srcObj:this.bg,srcFunc:"onclick",adviceObj:this,adviceFunc:"onBackgroundClick",once:true});
}
},uninitialize:function(){
this.bgIframe.remove();
dojo.html.removeNode(this.bg,true);
},setBackgroundColor:function(_b32){
if(arguments.length>=3){
_b32=new dojo.gfx.color.Color(arguments[0],arguments[1],arguments[2]);
}else{
_b32=new dojo.gfx.color.Color(_b32);
}
this.bg.style.backgroundColor=_b32.toString();
return this.bgColor=_b32;
},setBackgroundOpacity:function(op){
if(arguments.length==0){
op=this.bgOpacity;
}
dojo.html.setOpacity(this.bg,op);
try{
this.bgOpacity=dojo.html.getOpacity(this.bg);
}
catch(e){
this.bgOpacity=op;
}
return this.bgOpacity;
},_sizeBackground:function(){
if(this.bgOpacity>0){
var _b34=dojo.html.getViewport();
var h=_b34.height;
var w=_b34.width;
with(this.bg.style){
width=w+"px";
height=h+"px";
}
var _b37=dojo.html.getScroll().offset;
this.bg.style.top=_b37.y+"px";
this.bg.style.left=_b37.x+"px";
var _b34=dojo.html.getViewport();
if(_b34.width!=w){
this.bg.style.width=_b34.width+"px";
}
if(_b34.height!=h){
this.bg.style.height=_b34.height+"px";
}
}
this.bgIframe.size(this.bg);
},_showBackground:function(){
if(this.bgOpacity>0){
this.bg.style.display="block";
}
if(this.bgIframe.iframe){
this.bgIframe.iframe.style.display="block";
}
},placeModalDialog:function(){
var _b38=dojo.html.getScroll().offset;
var _b39=dojo.html.getViewport();
var mb;
if(this.isShowing()){
mb=dojo.html.getMarginBox(this.domNode);
}else{
dojo.html.setVisibility(this.domNode,false);
dojo.html.show(this.domNode);
mb=dojo.html.getMarginBox(this.domNode);
dojo.html.hide(this.domNode);
dojo.html.setVisibility(this.domNode,true);
}
var x=_b38.x+(_b39.width-mb.width)/2;
var y=_b38.y+(_b39.height-mb.height)/2;
with(this.domNode.style){
left=x+"px";
top=y+"px";
}
},_onKey:function(evt){
if(evt.key){
var node=evt.target;
while(node!=null){
if(node==this.domNode){
return;
}
node=node.parentNode;
}
if(evt.key!=evt.KEY_TAB){
dojo.event.browser.stopEvent(evt);
}else{
if(!dojo.render.html.opera){
try{
this.tabStart.focus();
}
catch(e){
}
}
}
}
},showModalDialog:function(){
if(this.followScroll&&!this._scrollConnected){
this._scrollConnected=true;
dojo.event.connect(window,"onscroll",this,"_onScroll");
}
dojo.event.connect(document.documentElement,"onkey",this,"_onKey");
this.placeModalDialog();
this.setBackgroundOpacity();
this._sizeBackground();
this._showBackground();
this._fromTrap=true;
setTimeout(dojo.lang.hitch(this,function(){
try{
this.tabStart.focus();
}
catch(e){
}
}),50);
},hideModalDialog:function(){
if(this.focusElement){
dojo.byId(this.focusElement).focus();
dojo.byId(this.focusElement).blur();
}
this.bg.style.display="none";
this.bg.style.width=this.bg.style.height="1px";
if(this.bgIframe.iframe){
this.bgIframe.iframe.style.display="none";
}
dojo.event.disconnect(document.documentElement,"onkey",this,"_onKey");
if(this._scrollConnected){
this._scrollConnected=false;
dojo.event.disconnect(window,"onscroll",this,"_onScroll");
}
},_onScroll:function(){
var _b3f=dojo.html.getScroll().offset;
this.bg.style.top=_b3f.y+"px";
this.bg.style.left=_b3f.x+"px";
this.placeModalDialog();
},checkSize:function(){
if(this.isShowing()){
this._sizeBackground();
this.placeModalDialog();
this.onResized();
}
},onBackgroundClick:function(){
if(this.lifetime-this.timeRemaining>=this.blockDuration){
return;
}
this.hide();
}});
dojo.widget.defineWidget("dojo.widget.Dialog",[dojo.widget.ContentPane,dojo.widget.ModalDialogBase],{templatePath:dojo.uri.dojoUri("src/widget/templates/Dialog.html"),blockDuration:0,lifetime:0,closeNode:"",postMixInProperties:function(){
dojo.widget.Dialog.superclass.postMixInProperties.apply(this,arguments);
if(this.closeNode){
this.setCloseControl(this.closeNode);
}
},postCreate:function(){
dojo.widget.Dialog.superclass.postCreate.apply(this,arguments);
dojo.widget.ModalDialogBase.prototype.postCreate.apply(this,arguments);
},show:function(){
if(this.lifetime){
this.timeRemaining=this.lifetime;
if(this.timerNode){
this.timerNode.innerHTML=Math.ceil(this.timeRemaining/1000);
}
if(this.blockDuration&&this.closeNode){
if(this.lifetime>this.blockDuration){
this.closeNode.style.visibility="hidden";
}else{
this.closeNode.style.display="none";
}
}
if(this.timer){
clearInterval(this.timer);
}
this.timer=setInterval(dojo.lang.hitch(this,"_onTick"),100);
}
this.showModalDialog();
dojo.widget.Dialog.superclass.show.call(this);
},onLoad:function(){
this.placeModalDialog();
dojo.widget.Dialog.superclass.onLoad.call(this);
},fillInTemplate:function(){
},hide:function(){
this.hideModalDialog();
dojo.widget.Dialog.superclass.hide.call(this);
if(this.timer){
clearInterval(this.timer);
}
},setTimerNode:function(node){
this.timerNode=node;
},setCloseControl:function(node){
this.closeNode=dojo.byId(node);
dojo.event.connect(this.closeNode,"onclick",this,"hide");
},setShowControl:function(node){
node=dojo.byId(node);
dojo.event.connect(node,"onclick",this,"show");
},_onTick:function(){
if(this.timer){
this.timeRemaining-=100;
if(this.lifetime-this.timeRemaining>=this.blockDuration){
if(this.closeNode){
this.closeNode.style.visibility="visible";
}
}
if(!this.timeRemaining){
clearInterval(this.timer);
this.hide();
}else{
if(this.timerNode){
this.timerNode.innerHTML=Math.ceil(this.timeRemaining/1000);
}
}
}
}});
dojo.provide("dojo.widget.Menu2");
dojo.widget.defineWidget("dojo.widget.PopupMenu2",dojo.widget.PopupContainer,function(){
this.targetNodeIds=[];
this.eventNames={open:""};
},{snarfChildDomOutput:true,eventNaming:"default",templateString:"<table class=\"dojoPopupMenu2\" border=0 cellspacing=0 cellpadding=0 style=\"display: none;\"><tbody dojoAttachPoint=\"containerNode\"></tbody></table>",templateCssPath:dojo.uri.dojoUri("src/widget/templates/Menu2.css"),templateCssString:"",submenuDelay:500,submenuOverlap:5,contextMenuForWindow:false,initialize:function(args,frag){
if(this.eventNaming=="default"){
for(var _b45 in this.eventNames){
this.eventNames[_b45]=this.widgetId+"/"+_b45;
}
}
},postCreate:function(){
if(this.contextMenuForWindow){
var doc=dojo.body();
this.bindDomNode(doc);
}else{
if(this.targetNodeIds.length>0){
dojo.lang.forEach(this.targetNodeIds,this.bindDomNode,this);
}
}
this._subscribeSubitemsOnOpen();
},_subscribeSubitemsOnOpen:function(){
var _b47=this.getChildrenOfType(dojo.widget.MenuItem2);
for(var i=0;i<_b47.length;i++){
dojo.event.topic.subscribe(this.eventNames.open,_b47[i],"menuOpen");
}
},getTopOpenEvent:function(){
var menu=this;
while(menu.parentPopup){
menu=menu.parentPopup;
}
return menu.openEvent;
},bindDomNode:function(node){
node=dojo.byId(node);
var win=dojo.html.getElementWindow(node);
if(dojo.html.isTag(node,"iframe")=="iframe"){
win=dojo.html.iframeContentWindow(node);
node=dojo.withGlobal(win,dojo.body);
}
dojo.widget.Menu2.OperaAndKonqFixer.fixNode(node);
dojo.event.kwConnect({srcObj:node,srcFunc:"oncontextmenu",targetObj:this,targetFunc:"onOpen",once:true});
if(dojo.render.html.moz&&win.document.designMode.toLowerCase()=="on"){
dojo.event.browser.addListener(node,"contextmenu",dojo.lang.hitch(this,"onOpen"));
}
dojo.widget.PopupManager.registerWin(win);
},unBindDomNode:function(_b4c){
var node=dojo.byId(_b4c);
dojo.event.kwDisconnect({srcObj:node,srcFunc:"oncontextmenu",targetObj:this,targetFunc:"onOpen",once:true});
dojo.widget.Menu2.OperaAndKonqFixer.cleanNode(node);
},_moveToNext:function(evt){
this._highlightOption(1);
return true;
},_moveToPrevious:function(evt){
this._highlightOption(-1);
return true;
},_moveToParentMenu:function(evt){
if(this._highlighted_option&&this.parentPopup){
if(evt._menu2UpKeyProcessed){
return true;
}else{
this._highlighted_option.onUnhover();
this.closeSubpopup();
evt._menu2UpKeyProcessed=true;
}
}
return false;
},_moveToChildMenu:function(evt){
if(this._highlighted_option&&this._highlighted_option.submenuId){
this._highlighted_option._onClick(true);
return true;
}
return false;
},_selectCurrentItem:function(evt){
if(this._highlighted_option){
this._highlighted_option._onClick();
return true;
}
return false;
},processKey:function(evt){
if(evt.ctrlKey||evt.altKey||!evt.key){
return false;
}
var rval=false;
switch(evt.key){
case evt.KEY_DOWN_ARROW:
rval=this._moveToNext(evt);
break;
case evt.KEY_UP_ARROW:
rval=this._moveToPrevious(evt);
break;
case evt.KEY_RIGHT_ARROW:
rval=this._moveToChildMenu(evt);
break;
case evt.KEY_LEFT_ARROW:
rval=this._moveToParentMenu(evt);
break;
case " ":
case evt.KEY_ENTER:
if(rval=this._selectCurrentItem(evt)){
break;
}
case evt.KEY_ESCAPE:
dojo.widget.PopupManager.currentMenu.close();
rval=true;
break;
}
return rval;
},_findValidItem:function(dir,_b56){
if(_b56){
_b56=dir>0?_b56.getNextSibling():_b56.getPreviousSibling();
}
for(var i=0;i<this.children.length;++i){
if(!_b56){
_b56=dir>0?this.children[0]:this.children[this.children.length-1];
}
if(_b56.onHover&&_b56.isShowing()){
return _b56;
}
_b56=dir>0?_b56.getNextSibling():_b56.getPreviousSibling();
}
},_highlightOption:function(dir){
var item;
if((!this._highlighted_option)){
item=this._findValidItem(dir);
}else{
item=this._findValidItem(dir,this._highlighted_option);
}
if(item){
if(this._highlighted_option){
this._highlighted_option.onUnhover();
}
item.onHover();
dojo.html.scrollIntoView(item.domNode);
try{
var node=dojo.html.getElementsByClass("dojoMenuItem2Label",item.domNode)[0];
node.focus();
}
catch(e){
}
}
},onItemClick:function(item){
},close:function(_b5c){
if(this.animationInProgress){
dojo.widget.PopupMenu2.superclass.close.apply(this,arguments);
return;
}
if(this._highlighted_option){
this._highlighted_option.onUnhover();
}
dojo.widget.PopupMenu2.superclass.close.apply(this,arguments);
},closeSubpopup:function(_b5d){
if(this.currentSubpopup==null){
return;
}
this.currentSubpopup.close(_b5d);
this.currentSubpopup=null;
this.currentSubmenuTrigger.is_open=false;
this.currentSubmenuTrigger._closedSubmenu(_b5d);
this.currentSubmenuTrigger=null;
},_openSubmenu:function(_b5e,_b5f){
var _b60=dojo.html.getAbsolutePosition(_b5f.domNode,true);
var _b61=dojo.html.getMarginBox(this.domNode).width;
var x=_b60.x+_b61-this.submenuOverlap;
var y=_b60.y;
_b5e.open(x,y,this,_b5f.domNode);
this.currentSubmenuTrigger=_b5f;
this.currentSubmenuTrigger.is_open=true;
},onOpen:function(e){
this.openEvent=e;
if(e["target"]){
this.openedForWindow=dojo.html.getElementWindow(e.target);
}else{
this.openedForWindow=null;
}
var x=e.pageX,y=e.pageY;
var win=dojo.html.getElementWindow(e.target);
var _b68=win._frameElement||win.frameElement;
this.open(x,y,null,[x,y]);
e.preventDefault();
e.stopPropagation();
}});
dojo.widget.defineWidget("dojo.widget.MenuItem2",dojo.widget.HtmlWidget,function(){
this.eventNames={engage:""};
},{templateString:"<tr class=\"dojoMenuItem2\" dojoAttachEvent=\"onMouseOver: onHover; onMouseOut: onUnhover; onClick: _onClick; onKey:onKey;\">"+"<td><div class=\"${this.iconClass}\" style=\"${this.iconStyle}\"></div></td>"+"<td tabIndex=\"-1\" class=\"dojoMenuItem2Label\">${this.caption}</td>"+"<td class=\"dojoMenuItem2Accel\">${this.accelKey}</td>"+"<td><div class=\"dojoMenuItem2Submenu\" style=\"display:${this.arrowDisplay};\"></div></td>"+"</tr>",is_hovering:false,hover_timer:null,is_open:false,topPosition:0,caption:"Untitled",accelKey:"",iconSrc:"",disabledClass:"dojoMenuItem2Disabled",iconClass:"dojoMenuItem2Icon",submenuId:"",eventNaming:"default",highlightClass:"dojoMenuItem2Hover",postMixInProperties:function(){
this.iconStyle="";
if(this.iconSrc){
if((this.iconSrc.toLowerCase().substring(this.iconSrc.length-4)==".png")&&(dojo.render.html.ie55||dojo.render.html.ie60)){
this.iconStyle="filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+this.iconSrc+"', sizingMethod='image')";
}else{
this.iconStyle="background-image: url("+this.iconSrc+")";
}
}
this.arrowDisplay=this.submenuId?"block":"none";
dojo.widget.MenuItem2.superclass.postMixInProperties.apply(this,arguments);
},fillInTemplate:function(){
dojo.html.disableSelection(this.domNode);
if(this.disabled){
this.setDisabled(true);
}
if(this.eventNaming=="default"){
for(var _b69 in this.eventNames){
this.eventNames[_b69]=this.widgetId+"/"+_b69;
}
}
},onHover:function(){
this.onUnhover();
if(this.is_hovering){
return;
}
if(this.is_open){
return;
}
if(this.parent._highlighted_option){
this.parent._highlighted_option.onUnhover();
}
this.parent.closeSubpopup();
this.parent._highlighted_option=this;
dojo.widget.PopupManager.setFocusedMenu(this.parent);
this._highlightItem();
if(this.is_hovering){
this._stopSubmenuTimer();
}
this.is_hovering=true;
this._startSubmenuTimer();
},onUnhover:function(){
if(!this.is_open){
this._unhighlightItem();
}
this.is_hovering=false;
this.parent._highlighted_option=null;
if(this.parent.parentPopup){
dojo.widget.PopupManager.setFocusedMenu(this.parent.parentPopup);
}
this._stopSubmenuTimer();
},_onClick:function(_b6a){
var _b6b=false;
if(this.disabled){
return false;
}
if(this.submenuId){
if(!this.is_open){
this._stopSubmenuTimer();
this._openSubmenu();
}
_b6b=true;
}else{
this.onUnhover();
this.parent.closeAll(true);
}
this.onClick();
dojo.event.topic.publish(this.eventNames.engage,this);
if(_b6b&&_b6a){
dojo.widget.getWidgetById(this.submenuId)._highlightOption(1);
}
return;
},onClick:function(){
this.parent.onItemClick(this);
},_highlightItem:function(){
dojo.html.addClass(this.domNode,this.highlightClass);
},_unhighlightItem:function(){
dojo.html.removeClass(this.domNode,this.highlightClass);
},_startSubmenuTimer:function(){
this._stopSubmenuTimer();
if(this.disabled){
return;
}
var self=this;
var _b6d=function(){
return function(){
self._openSubmenu();
};
}();
this.hover_timer=dojo.lang.setTimeout(_b6d,this.parent.submenuDelay);
},_stopSubmenuTimer:function(){
if(this.hover_timer){
dojo.lang.clearTimeout(this.hover_timer);
this.hover_timer=null;
}
},_openSubmenu:function(){
if(this.disabled){
return;
}
this.parent.closeSubpopup();
var _b6e=dojo.widget.getWidgetById(this.submenuId);
if(_b6e){
this.parent._openSubmenu(_b6e,this);
}
},_closedSubmenu:function(){
this.onUnhover();
},setDisabled:function(_b6f){
this.disabled=_b6f;
if(this.disabled){
dojo.html.addClass(this.domNode,this.disabledClass);
}else{
dojo.html.removeClass(this.domNode,this.disabledClass);
}
},enable:function(){
this.setDisabled(false);
},disable:function(){
this.setDisabled(true);
},menuOpen:function(_b70){
}});
dojo.widget.defineWidget("dojo.widget.MenuSeparator2",dojo.widget.HtmlWidget,{templateString:"<tr class=\"dojoMenuSeparator2\"><td colspan=4>"+"<div class=\"dojoMenuSeparator2Top\"></div>"+"<div class=\"dojoMenuSeparator2Bottom\"></div>"+"</td></tr>",postCreate:function(){
dojo.html.disableSelection(this.domNode);
}});
dojo.widget.defineWidget("dojo.widget.MenuBar2",dojo.widget.PopupMenu2,{menuOverlap:2,templateString:"<div class=\"dojoMenuBar2\" tabIndex=\"0\"><table class=\"dojoMenuBar2Client\"><tr dojoAttachPoint=\"containerNode\"></tr></table></div>",close:function(_b71){
if(this._highlighted_option){
this._highlighted_option.onUnhover();
}
this.closeSubpopup(_b71);
},processKey:function(evt){
if(evt.ctrlKey||evt.altKey){
return false;
}
if(!dojo.html.hasClass(evt.target,"dojoMenuBar2")){
return false;
}
var rval=false;
switch(evt.key){
case evt.KEY_DOWN_ARROW:
rval=this._moveToChildMenu(evt);
break;
case evt.KEY_UP_ARROW:
rval=this._moveToParentMenu(evt);
break;
case evt.KEY_RIGHT_ARROW:
rval=this._moveToNext(evt);
break;
case evt.KEY_LEFT_ARROW:
rval=this._moveToPrevious(evt);
break;
default:
rval=dojo.widget.MenuBar2.superclass.processKey.apply(this,arguments);
break;
}
return rval;
},postCreate:function(){
dojo.widget.MenuBar2.superclass.postCreate.apply(this,arguments);
dojo.widget.PopupManager.opened(this);
this.isShowingNow=true;
},_openSubmenu:function(_b74,_b75){
var _b76=dojo.html.getAbsolutePosition(_b75.domNode,true);
var _b77=dojo.html.getAbsolutePosition(this.domNode,true);
var _b78=dojo.html.getBorderBox(this.domNode).height;
var x=_b76.x;
var y=_b77.y+_b78-this.menuOverlap;
_b74.open(x,y,this,_b75.domNode);
this.currentSubmenuTrigger=_b75;
this.currentSubmenuTrigger.is_open=true;
}});
dojo.widget.defineWidget("dojo.widget.MenuBarItem2",dojo.widget.MenuItem2,{templateString:"<td class=\"dojoMenuBarItem2\" dojoAttachEvent=\"onMouseOver: onHover; onMouseOut: onUnhover; onClick: _onClick;\">"+"<span>${this.caption}</span>"+"</td>",highlightClass:"dojoMenuBarItem2Hover",setDisabled:function(_b7b){
this.disabled=_b7b;
if(this.disabled){
dojo.html.addClass(this.domNode,"dojoMenuBarItem2Disabled");
}else{
dojo.html.removeClass(this.domNode,"dojoMenuBarItem2Disabled");
}
}});
dojo.widget.Menu2.OperaAndKonqFixer=new function(){
var _b7c=true;
var _b7d=false;
if(!dojo.lang.isFunction(dojo.doc().oncontextmenu)){
dojo.doc().oncontextmenu=function(){
_b7c=false;
_b7d=true;
};
}
if(dojo.doc().createEvent){
try{
var e=dojo.doc().createEvent("MouseEvents");
e.initMouseEvent("contextmenu",1,1,dojo.global(),1,0,0,0,0,0,0,0,0,0,null);
dojo.doc().dispatchEvent(e);
}
catch(e){
}
}else{
_b7c=false;
}
if(_b7d){
delete dojo.doc().oncontextmenu;
}
this.fixNode=function(node){
if(_b7c){
if(!dojo.lang.isFunction(node.oncontextmenu)){
node.oncontextmenu=function(e){
};
}
if(dojo.render.html.opera){
node._menufixer_opera=function(e){
if(e.ctrlKey){
this.oncontextmenu(e);
}
};
dojo.event.connect(node,"onclick",node,"_menufixer_opera");
}else{
node._menufixer_konq=function(e){
if(e.button==2){
e.preventDefault();
this.oncontextmenu(e);
}
};
dojo.event.connect(node,"onmousedown",node,"_menufixer_konq");
}
}
};
this.cleanNode=function(node){
if(_b7c){
if(node._menufixer_opera){
dojo.event.disconnect(node,"onclick",node,"_menufixer_opera");
delete node._menufixer_opera;
}else{
if(node._menufixer_konq){
dojo.event.disconnect(node,"onmousedown",node,"_menufixer_konq");
delete node._menufixer_konq;
}
}
if(node.oncontextmenu){
delete node.oncontextmenu;
}
}
};
};
dojo.provide("dojo.dnd.DragAndDrop");
dojo.declare("dojo.dnd.DragSource",null,{type:"",onDragEnd:function(evt){
},onDragStart:function(evt){
},onSelected:function(evt){
},unregister:function(){
dojo.dnd.dragManager.unregisterDragSource(this);
},reregister:function(){
dojo.dnd.dragManager.registerDragSource(this);
}});
dojo.declare("dojo.dnd.DragObject",null,{type:"",register:function(){
var dm=dojo.dnd.dragManager;
if(dm["registerDragObject"]){
dm.registerDragObject(this);
}
},onDragStart:function(evt){
},onDragMove:function(evt){
},onDragOver:function(evt){
},onDragOut:function(evt){
},onDragEnd:function(evt){
},onDragLeave:dojo.lang.forward("onDragOut"),onDragEnter:dojo.lang.forward("onDragOver"),ondragout:dojo.lang.forward("onDragOut"),ondragover:dojo.lang.forward("onDragOver")});
dojo.declare("dojo.dnd.DropTarget",null,{acceptsType:function(type){
if(!dojo.lang.inArray(this.acceptedTypes,"*")){
if(!dojo.lang.inArray(this.acceptedTypes,type)){
return false;
}
}
return true;
},accepts:function(_b8e){
if(!dojo.lang.inArray(this.acceptedTypes,"*")){
for(var i=0;i<_b8e.length;i++){
if(!dojo.lang.inArray(this.acceptedTypes,_b8e[i].type)){
return false;
}
}
}
return true;
},unregister:function(){
dojo.dnd.dragManager.unregisterDropTarget(this);
},onDragOver:function(evt){
},onDragOut:function(evt){
},onDragMove:function(evt){
},onDropStart:function(evt){
},onDrop:function(evt){
},onDropEnd:function(){
}},function(){
this.acceptedTypes=[];
});
dojo.dnd.DragEvent=function(){
this.dragSource=null;
this.dragObject=null;
this.target=null;
this.eventStatus="success";
};
dojo.declare("dojo.dnd.DragManager",null,{selectedSources:[],dragObjects:[],dragSources:[],registerDragSource:function(_b95){
},dropTargets:[],registerDropTarget:function(_b96){
},lastDragTarget:null,currentDragTarget:null,onKeyDown:function(){
},onMouseOut:function(){
},onMouseMove:function(){
},onMouseUp:function(){
}});
dojo.provide("dojo.dnd.HtmlDragManager");
dojo.declare("dojo.dnd.HtmlDragManager",dojo.dnd.DragManager,{disabled:false,nestedTargets:false,mouseDownTimer:null,dsCounter:0,dsPrefix:"dojoDragSource",dropTargetDimensions:[],currentDropTarget:null,previousDropTarget:null,_dragTriggered:false,selectedSources:[],dragObjects:[],dragSources:[],currentX:null,currentY:null,lastX:null,lastY:null,mouseDownX:null,mouseDownY:null,threshold:7,dropAcceptable:false,cancelEvent:function(e){
e.stopPropagation();
e.preventDefault();
},registerDragSource:function(ds){
if(ds["domNode"]){
var dp=this.dsPrefix;
var _b9a=dp+"Idx_"+(this.dsCounter++);
ds.dragSourceId=_b9a;
this.dragSources[_b9a]=ds;
ds.domNode.setAttribute(dp,_b9a);
if(dojo.render.html.ie){
dojo.event.browser.addListener(ds.domNode,"ondragstart",this.cancelEvent);
}
}
},unregisterDragSource:function(ds){
if(ds["domNode"]){
var dp=this.dsPrefix;
var _b9d=ds.dragSourceId;
delete ds.dragSourceId;
delete this.dragSources[_b9d];
ds.domNode.setAttribute(dp,null);
if(dojo.render.html.ie){
dojo.event.browser.removeListener(ds.domNode,"ondragstart",this.cancelEvent);
}
}
},registerDropTarget:function(dt){
this.dropTargets.push(dt);
},unregisterDropTarget:function(dt){
var _ba0=dojo.lang.find(this.dropTargets,dt,true);
if(_ba0>=0){
this.dropTargets.splice(_ba0,1);
}
},getDragSource:function(e){
var tn=e.target;
if(tn===dojo.body()){
return;
}
var ta=dojo.html.getAttribute(tn,this.dsPrefix);
while((!ta)&&(tn)){
tn=tn.parentNode;
if((!tn)||(tn===dojo.body())){
return;
}
ta=dojo.html.getAttribute(tn,this.dsPrefix);
}
return this.dragSources[ta];
},onKeyDown:function(e){
},onMouseDown:function(e){
if(this.disabled){
return;
}
if(dojo.render.html.ie){
if(e.button!=1){
return;
}
}else{
if(e.which!=1){
return;
}
}
var _ba6=e.target.nodeType==dojo.html.TEXT_NODE?e.target.parentNode:e.target;
if(dojo.html.isTag(_ba6,"button","textarea","input","select","option")){
return;
}
var ds=this.getDragSource(e);
if(!ds){
return;
}
if(!dojo.lang.inArray(this.selectedSources,ds)){
this.selectedSources.push(ds);
ds.onSelected();
}
this.mouseDownX=e.pageX;
this.mouseDownY=e.pageY;
e.preventDefault();
dojo.event.connect(document,"onmousemove",this,"onMouseMove");
},onMouseUp:function(e,_ba9){
if(this.selectedSources.length==0){
return;
}
this.mouseDownX=null;
this.mouseDownY=null;
this._dragTriggered=false;
e.dragSource=this.dragSource;
if((!e.shiftKey)&&(!e.ctrlKey)){
if(this.currentDropTarget){
this.currentDropTarget.onDropStart();
}
dojo.lang.forEach(this.dragObjects,function(_baa){
var ret=null;
if(!_baa){
return;
}
if(this.currentDropTarget){
e.dragObject=_baa;
var ce=this.currentDropTarget.domNode.childNodes;
if(ce.length>0){
e.dropTarget=ce[0];
while(e.dropTarget==_baa.domNode){
e.dropTarget=e.dropTarget.nextSibling;
}
}else{
e.dropTarget=this.currentDropTarget.domNode;
}
if(this.dropAcceptable){
ret=this.currentDropTarget.onDrop(e);
}else{
this.currentDropTarget.onDragOut(e);
}
}
e.dragStatus=this.dropAcceptable&&ret?"dropSuccess":"dropFailure";
dojo.lang.delayThese([function(){
try{
_baa.dragSource.onDragEnd(e);
}
catch(err){
var _bad={};
for(var i in e){
if(i=="type"){
_bad.type="mouseup";
continue;
}
_bad[i]=e[i];
}
_baa.dragSource.onDragEnd(_bad);
}
},function(){
_baa.onDragEnd(e);
}]);
},this);
this.selectedSources=[];
this.dragObjects=[];
this.dragSource=null;
if(this.currentDropTarget){
this.currentDropTarget.onDropEnd();
}
}else{
}
dojo.event.disconnect(document,"onmousemove",this,"onMouseMove");
this.currentDropTarget=null;
},onScroll:function(){
for(var i=0;i<this.dragObjects.length;i++){
if(this.dragObjects[i].updateDragOffset){
this.dragObjects[i].updateDragOffset();
}
}
if(this.dragObjects.length){
this.cacheTargetLocations();
}
},_dragStartDistance:function(x,y){
if((!this.mouseDownX)||(!this.mouseDownX)){
return;
}
var dx=Math.abs(x-this.mouseDownX);
var dx2=dx*dx;
var dy=Math.abs(y-this.mouseDownY);
var dy2=dy*dy;
return parseInt(Math.sqrt(dx2+dy2),10);
},cacheTargetLocations:function(){
dojo.profile.start("cacheTargetLocations");
this.dropTargetDimensions=[];
dojo.lang.forEach(this.dropTargets,function(_bb6){
var tn=_bb6.domNode;
if(!tn||!_bb6.accepts([this.dragSource])){
return;
}
var abs=dojo.html.getAbsolutePosition(tn,true);
var bb=dojo.html.getBorderBox(tn);
this.dropTargetDimensions.push([[abs.x,abs.y],[abs.x+bb.width,abs.y+bb.height],_bb6]);
},this);
dojo.profile.end("cacheTargetLocations");
},onMouseMove:function(e){
if((dojo.render.html.ie)&&(e.button!=1)){
this.currentDropTarget=null;
this.onMouseUp(e,true);
return;
}
if((this.selectedSources.length)&&(!this.dragObjects.length)){
var dx;
var dy;
if(!this._dragTriggered){
this._dragTriggered=(this._dragStartDistance(e.pageX,e.pageY)>this.threshold);
if(!this._dragTriggered){
return;
}
dx=e.pageX-this.mouseDownX;
dy=e.pageY-this.mouseDownY;
}
this.dragSource=this.selectedSources[0];
dojo.lang.forEach(this.selectedSources,function(_bbd){
if(!_bbd){
return;
}
var tdo=_bbd.onDragStart(e);
if(tdo){
tdo.onDragStart(e);
tdo.dragOffset.y+=dy;
tdo.dragOffset.x+=dx;
tdo.dragSource=_bbd;
this.dragObjects.push(tdo);
}
},this);
this.previousDropTarget=null;
this.cacheTargetLocations();
}
dojo.lang.forEach(this.dragObjects,function(_bbf){
if(_bbf){
_bbf.onDragMove(e);
}
});
if(this.currentDropTarget){
var c=dojo.html.toCoordinateObject(this.currentDropTarget.domNode,true);
var dtp=[[c.x,c.y],[c.x+c.width,c.y+c.height]];
}
if((!this.nestedTargets)&&(dtp)&&(this.isInsideBox(e,dtp))){
if(this.dropAcceptable){
this.currentDropTarget.onDragMove(e,this.dragObjects);
}
}else{
var _bc2=this.findBestTarget(e);
if(_bc2.target===null){
if(this.currentDropTarget){
this.currentDropTarget.onDragOut(e);
this.previousDropTarget=this.currentDropTarget;
this.currentDropTarget=null;
}
this.dropAcceptable=false;
return;
}
if(this.currentDropTarget!==_bc2.target){
if(this.currentDropTarget){
this.previousDropTarget=this.currentDropTarget;
this.currentDropTarget.onDragOut(e);
}
this.currentDropTarget=_bc2.target;
e.dragObjects=this.dragObjects;
this.dropAcceptable=this.currentDropTarget.onDragOver(e);
}else{
if(this.dropAcceptable){
this.currentDropTarget.onDragMove(e,this.dragObjects);
}
}
}
},findBestTarget:function(e){
var _bc4=this;
var _bc5=new Object();
_bc5.target=null;
_bc5.points=null;
dojo.lang.every(this.dropTargetDimensions,function(_bc6){
if(!_bc4.isInsideBox(e,_bc6)){
return true;
}
_bc5.target=_bc6[2];
_bc5.points=_bc6;
return Boolean(_bc4.nestedTargets);
});
return _bc5;
},isInsideBox:function(e,_bc8){
if((e.pageX>_bc8[0][0])&&(e.pageX<_bc8[1][0])&&(e.pageY>_bc8[0][1])&&(e.pageY<_bc8[1][1])){
return true;
}
return false;
},onMouseOver:function(e){
},onMouseOut:function(e){
}});
dojo.dnd.dragManager=new dojo.dnd.HtmlDragManager();
(function(){
var d=document;
var dm=dojo.dnd.dragManager;
dojo.event.connect(d,"onkeydown",dm,"onKeyDown");
dojo.event.connect(d,"onmouseover",dm,"onMouseOver");
dojo.event.connect(d,"onmouseout",dm,"onMouseOut");
dojo.event.connect(d,"onmousedown",dm,"onMouseDown");
dojo.event.connect(d,"onmouseup",dm,"onMouseUp");
dojo.event.connect(window,"onscroll",dm,"onScroll");
})();
dojo.provide("dojo.dnd.HtmlDragAndDrop");
dojo.declare("dojo.dnd.HtmlDragSource",dojo.dnd.DragSource,{dragClass:"",onDragStart:function(){
var _bcd=new dojo.dnd.HtmlDragObject(this.dragObject,this.type);
if(this.dragClass){
_bcd.dragClass=this.dragClass;
}
if(this.constrainToContainer){
_bcd.constrainTo(this.constrainingContainer||this.domNode.parentNode);
}
return _bcd;
},setDragHandle:function(node){
node=dojo.byId(node);
dojo.dnd.dragManager.unregisterDragSource(this);
this.domNode=node;
dojo.dnd.dragManager.registerDragSource(this);
},setDragTarget:function(node){
this.dragObject=node;
},constrainTo:function(_bd0){
this.constrainToContainer=true;
if(_bd0){
this.constrainingContainer=_bd0;
}
},onSelected:function(){
for(var i=0;i<this.dragObjects.length;i++){
dojo.dnd.dragManager.selectedSources.push(new dojo.dnd.HtmlDragSource(this.dragObjects[i]));
}
},addDragObjects:function(el){
for(var i=0;i<arguments.length;i++){
this.dragObjects.push(dojo.byId(arguments[i]));
}
}},function(node,type){
node=dojo.byId(node);
this.dragObjects=[];
this.constrainToContainer=false;
if(node){
this.domNode=node;
this.dragObject=node;
this.type=(type)||(this.domNode.nodeName.toLowerCase());
dojo.dnd.DragSource.prototype.reregister.call(this);
}
});
dojo.declare("dojo.dnd.HtmlDragObject",dojo.dnd.DragObject,{dragClass:"",opacity:0.5,createIframe:true,disableX:false,disableY:false,createDragNode:function(){
var node=this.domNode.cloneNode(true);
if(this.dragClass){
dojo.html.addClass(node,this.dragClass);
}
if(this.opacity<1){
dojo.html.setOpacity(node,this.opacity);
}
var ltn=node.tagName.toLowerCase();
var isTr=(ltn=="tr");
if((isTr)||(ltn=="tbody")){
var doc=this.domNode.ownerDocument;
var _bda=doc.createElement("table");
if(isTr){
var _bdb=doc.createElement("tbody");
_bda.appendChild(_bdb);
_bdb.appendChild(node);
}else{
_bda.appendChild(node);
}
var _bdc=((isTr)?this.domNode:this.domNode.firstChild);
var _bdd=((isTr)?node:node.firstChild);
var _bde=tdp.childNodes;
var _bdf=_bdd.childNodes;
for(var i=0;i<_bde.length;i++){
if((_bdf[i])&&(_bdf[i].style)){
_bdf[i].style.width=dojo.html.getContentBox(_bde[i]).width+"px";
}
}
node=_bda;
}
if((dojo.render.html.ie55||dojo.render.html.ie60)&&this.createIframe){
with(node.style){
top="0px";
left="0px";
}
var _be1=document.createElement("div");
_be1.appendChild(node);
this.bgIframe=new dojo.html.BackgroundIframe(_be1);
_be1.appendChild(this.bgIframe.iframe);
node=_be1;
}
node.style.zIndex=999;
return node;
},onDragStart:function(e){
dojo.html.clearSelection();
this.scrollOffset=dojo.html.getScroll().offset;
this.dragStartPosition=dojo.html.getAbsolutePosition(this.domNode,true);
this.dragOffset={y:this.dragStartPosition.y-e.pageY,x:this.dragStartPosition.x-e.pageX};
this.dragClone=this.createDragNode();
this.containingBlockPosition=this.domNode.offsetParent?dojo.html.getAbsolutePosition(this.domNode.offsetParent,true):{x:0,y:0};
if(this.constrainToContainer){
this.constraints=this.getConstraints();
}
with(this.dragClone.style){
position="absolute";
top=this.dragOffset.y+e.pageY+"px";
left=this.dragOffset.x+e.pageX+"px";
}
dojo.body().appendChild(this.dragClone);
dojo.event.topic.publish("dragStart",{source:this});
},getConstraints:function(){
if(this.constrainingContainer.nodeName.toLowerCase()=="body"){
var _be3=dojo.html.getViewport();
var _be4=_be3.width;
var _be5=_be3.height;
var _be6=dojo.html.getScroll().offset;
var x=_be6.x;
var y=_be6.y;
}else{
var _be9=dojo.html.getContentBox(this.constrainingContainer);
_be4=_be9.width;
_be5=_be9.height;
x=this.containingBlockPosition.x+dojo.html.getPixelValue(this.constrainingContainer,"padding-left",true)+dojo.html.getBorderExtent(this.constrainingContainer,"left");
y=this.containingBlockPosition.y+dojo.html.getPixelValue(this.constrainingContainer,"padding-top",true)+dojo.html.getBorderExtent(this.constrainingContainer,"top");
}
var mb=dojo.html.getMarginBox(this.domNode);
return {minX:x,minY:y,maxX:x+_be4-mb.width,maxY:y+_be5-mb.height};
},updateDragOffset:function(){
var _beb=dojo.html.getScroll().offset;
if(_beb.y!=this.scrollOffset.y){
var diff=_beb.y-this.scrollOffset.y;
this.dragOffset.y+=diff;
this.scrollOffset.y=_beb.y;
}
if(_beb.x!=this.scrollOffset.x){
var diff=_beb.x-this.scrollOffset.x;
this.dragOffset.x+=diff;
this.scrollOffset.x=_beb.x;
}
},onDragMove:function(e){
this.updateDragOffset();
var x=this.dragOffset.x+e.pageX;
var y=this.dragOffset.y+e.pageY;
if(this.constrainToContainer){
if(x<this.constraints.minX){
x=this.constraints.minX;
}
if(y<this.constraints.minY){
y=this.constraints.minY;
}
if(x>this.constraints.maxX){
x=this.constraints.maxX;
}
if(y>this.constraints.maxY){
y=this.constraints.maxY;
}
}
this.setAbsolutePosition(x,y);
dojo.event.topic.publish("dragMove",{source:this});
},setAbsolutePosition:function(x,y){
if(!this.disableY){
this.dragClone.style.top=y+"px";
}
if(!this.disableX){
this.dragClone.style.left=x+"px";
}
},onDragEnd:function(e){
switch(e.dragStatus){
case "dropSuccess":
dojo.html.removeNode(this.dragClone);
this.dragClone=null;
break;
case "dropFailure":
var _bf3=dojo.html.getAbsolutePosition(this.dragClone,true);
var _bf4={left:this.dragStartPosition.x+1,top:this.dragStartPosition.y+1};
var anim=dojo.lfx.slideTo(this.dragClone,_bf4,300);
var _bf6=this;
dojo.event.connect(anim,"onEnd",function(e){
dojo.html.removeNode(_bf6.dragClone);
_bf6.dragClone=null;
});
anim.play();
break;
}
dojo.event.topic.publish("dragEnd",{source:this});
},constrainTo:function(_bf8){
this.constrainToContainer=true;
if(_bf8){
this.constrainingContainer=_bf8;
}else{
this.constrainingContainer=this.domNode.parentNode;
}
}},function(node,type){
this.domNode=dojo.byId(node);
this.type=type;
this.constrainToContainer=false;
this.dragSource=null;
dojo.dnd.DragObject.prototype.register.call(this);
});
dojo.declare("dojo.dnd.HtmlDropTarget",dojo.dnd.DropTarget,{vertical:false,onDragOver:function(e){
if(!this.accepts(e.dragObjects)){
return false;
}
this.childBoxes=[];
for(var i=0,_bfd;i<this.domNode.childNodes.length;i++){
_bfd=this.domNode.childNodes[i];
if(_bfd.nodeType!=dojo.html.ELEMENT_NODE){
continue;
}
var pos=dojo.html.getAbsolutePosition(_bfd,true);
var _bff=dojo.html.getBorderBox(_bfd);
this.childBoxes.push({top:pos.y,bottom:pos.y+_bff.height,left:pos.x,right:pos.x+_bff.width,height:_bff.height,width:_bff.width,node:_bfd});
}
return true;
},_getNodeUnderMouse:function(e){
for(var i=0,_c02;i<this.childBoxes.length;i++){
with(this.childBoxes[i]){
if(e.pageX>=left&&e.pageX<=right&&e.pageY>=top&&e.pageY<=bottom){
return i;
}
}
}
return -1;
},createDropIndicator:function(){
this.dropIndicator=document.createElement("div");
with(this.dropIndicator.style){
position="absolute";
zIndex=999;
if(this.vertical){
borderLeftWidth="1px";
borderLeftColor="black";
borderLeftStyle="solid";
height=dojo.html.getBorderBox(this.domNode).height+"px";
top=dojo.html.getAbsolutePosition(this.domNode,true).y+"px";
}else{
borderTopWidth="1px";
borderTopColor="black";
borderTopStyle="solid";
width=dojo.html.getBorderBox(this.domNode).width+"px";
left=dojo.html.getAbsolutePosition(this.domNode,true).x+"px";
}
}
},onDragMove:function(e,_c04){
var i=this._getNodeUnderMouse(e);
if(!this.dropIndicator){
this.createDropIndicator();
}
var _c06=this.vertical?dojo.html.gravity.WEST:dojo.html.gravity.NORTH;
var hide=false;
if(i<0){
if(this.childBoxes.length){
var _c08=(dojo.html.gravity(this.childBoxes[0].node,e)&_c06);
if(_c08){
hide=true;
}
}else{
var _c08=true;
}
}else{
var _c09=this.childBoxes[i];
var _c08=(dojo.html.gravity(_c09.node,e)&_c06);
if(_c09.node===_c04[0].dragSource.domNode){
hide=true;
}else{
var _c0a=_c08?(i>0?this.childBoxes[i-1]:_c09):(i<this.childBoxes.length-1?this.childBoxes[i+1]:_c09);
if(_c0a.node===_c04[0].dragSource.domNode){
hide=true;
}
}
}
if(hide){
this.dropIndicator.style.display="none";
return;
}else{
this.dropIndicator.style.display="";
}
this.placeIndicator(e,_c04,i,_c08);
if(!dojo.html.hasParent(this.dropIndicator)){
dojo.body().appendChild(this.dropIndicator);
}
},placeIndicator:function(e,_c0c,_c0d,_c0e){
var _c0f=this.vertical?"left":"top";
var _c10;
if(_c0d<0){
if(this.childBoxes.length){
_c10=_c0e?this.childBoxes[0]:this.childBoxes[this.childBoxes.length-1];
}else{
this.dropIndicator.style[_c0f]=dojo.html.getAbsolutePosition(this.domNode,true)[this.vertical?"x":"y"]+"px";
}
}else{
_c10=this.childBoxes[_c0d];
}
if(_c10){
this.dropIndicator.style[_c0f]=(_c0e?_c10[_c0f]:_c10[this.vertical?"right":"bottom"])+"px";
if(this.vertical){
this.dropIndicator.style.height=_c10.height+"px";
this.dropIndicator.style.top=_c10.top+"px";
}else{
this.dropIndicator.style.width=_c10.width+"px";
this.dropIndicator.style.left=_c10.left+"px";
}
}
},onDragOut:function(e){
if(this.dropIndicator){
dojo.html.removeNode(this.dropIndicator);
delete this.dropIndicator;
}
},onDrop:function(e){
this.onDragOut(e);
var i=this._getNodeUnderMouse(e);
var _c14=this.vertical?dojo.html.gravity.WEST:dojo.html.gravity.NORTH;
if(i<0){
if(this.childBoxes.length){
if(dojo.html.gravity(this.childBoxes[0].node,e)&_c14){
return this.insert(e,this.childBoxes[0].node,"before");
}else{
return this.insert(e,this.childBoxes[this.childBoxes.length-1].node,"after");
}
}
return this.insert(e,this.domNode,"append");
}
var _c15=this.childBoxes[i];
if(dojo.html.gravity(_c15.node,e)&_c14){
return this.insert(e,_c15.node,"before");
}else{
return this.insert(e,_c15.node,"after");
}
},insert:function(e,_c17,_c18){
var node=e.dragObject.domNode;
if(_c18=="before"){
return dojo.html.insertBefore(node,_c17);
}else{
if(_c18=="after"){
return dojo.html.insertAfter(node,_c17);
}else{
if(_c18=="append"){
_c17.appendChild(node);
return true;
}
}
}
return false;
}},function(node,_c1b){
if(arguments.length==0){
return;
}
this.domNode=dojo.byId(node);
dojo.dnd.DropTarget.call(this);
if(_c1b&&dojo.lang.isString(_c1b)){
_c1b=[_c1b];
}
this.acceptedTypes=_c1b||[];
dojo.dnd.dragManager.registerDropTarget(this);
});


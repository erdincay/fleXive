

This is a jetty specific implementation of the Bayeux protocol for the cometd.org
project of the Dojo Foundation.

A servlet-3.0 implementation is under development and will soon be available 
in the cometd project.


// $Id: BlockEvent.java,v 1.2 2005/07/17 11:38:05 chrislott Exp $

package org.jgroups;

/**
 * Trivial object that represents a block event.
 */
public class BlockEvent {
    public String toString() {return "BlockEvent";}
}
